import subprocess
import os
import shutil
import json
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import logging

agent_bp = Blueprint('agent', __name__)

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 허용된 명령어 리스트 (보안을 위한 화이트리스트)
ALLOWED_COMMANDS = [
    'ls', 'pwd', 'whoami', 'date', 'uptime', 'df', 'free', 'ps',
    'cat', 'head', 'tail', 'grep', 'find', 'wc', 'sort', 'uniq',
    'systemctl', 'service', 'nginx', 'apache2', 'docker', 'git'
]

def is_command_allowed(command):
    """명령어가 허용된 명령어인지 확인"""
    if not command:
        return False
    
    cmd_parts = command.strip().split()
    if not cmd_parts:
        return False
    
    base_command = cmd_parts[0]
    return base_command in ALLOWED_COMMANDS

def execute_command_safe(command):
    """안전한 명령어 실행"""
    try:
        if not is_command_allowed(command):
            return {
                "success": False,
                "output": "",
                "error": f"명령어 '{command.split()[0] if command.split() else command}'는 허용되지 않습니다."
            }
        
        # 명령어 실행
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30  # 30초 타임아웃
        )
        
        logger.info(f"Command executed: {command}")
        
        return {
            "success": result.returncode == 0,
            "output": result.stdout,
            "error": result.stderr,
            "return_code": result.returncode
        }
        
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "output": "",
            "error": "명령어 실행 시간이 초과되었습니다."
        }
    except Exception as e:
        logger.error(f"Command execution error: {str(e)}")
        return {
            "success": False,
            "output": "",
            "error": f"명령어 실행 중 오류가 발생했습니다: {str(e)}"
        }

@agent_bp.route('/command', methods=['POST'])
@cross_origin()
def execute_command():
    """서버 명령어 실행"""
    try:
        data = request.get_json()
        if not data or 'command' not in data:
            return jsonify({
                "success": False,
                "error": "명령어가 제공되지 않았습니다."
            }), 400
        
        command = data['command'].strip()
        if not command:
            return jsonify({
                "success": False,
                "error": "빈 명령어는 실행할 수 없습니다."
            }), 400
        
        result = execute_command_safe(command)
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"API error: {str(e)}")
        return jsonify({
            "success": False,
            "error": "서버 오류가 발생했습니다."
        }), 500

@agent_bp.route('/file/read', methods=['POST'])
@cross_origin()
def read_file():
    """파일 내용 읽기"""
    try:
        data = request.get_json()
        if not data or 'path' not in data:
            return jsonify({
                "success": False,
                "error": "파일 경로가 제공되지 않았습니다."
            }), 400
        
        file_path = data['path']
        
        # 보안을 위한 경로 검증
        if '..' in file_path or file_path.startswith('/'):
            # 상대 경로만 허용하고, 루트 디렉토리 접근 제한
            if not file_path.startswith('/home/ubuntu/') and not file_path.startswith('/tmp/'):
                return jsonify({
                    "success": False,
                    "error": "허용되지 않은 경로입니다."
                }), 403
        
        if not os.path.exists(file_path):
            return jsonify({
                "success": False,
                "error": "파일을 찾을 수 없습니다."
            }), 404
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        logger.info(f"File read: {file_path}")
        
        return jsonify({
            "success": True,
            "content": content,
            "path": file_path
        })
        
    except UnicodeDecodeError:
        return jsonify({
            "success": False,
            "error": "파일을 텍스트로 읽을 수 없습니다. (바이너리 파일일 수 있습니다)"
        }), 400
    except Exception as e:
        logger.error(f"File read error: {str(e)}")
        return jsonify({
            "success": False,
            "error": f"파일 읽기 중 오류가 발생했습니다: {str(e)}"
        }), 500

@agent_bp.route('/file/write', methods=['POST'])
@cross_origin()
def write_file():
    """파일 내용 쓰기"""
    try:
        data = request.get_json()
        if not data or 'path' not in data or 'content' not in data:
            return jsonify({
                "success": False,
                "error": "파일 경로와 내용이 모두 제공되어야 합니다."
            }), 400
        
        file_path = data['path']
        content = data['content']
        
        # 보안을 위한 경로 검증
        if '..' in file_path or file_path.startswith('/'):
            if not file_path.startswith('/home/ubuntu/') and not file_path.startswith('/tmp/'):
                return jsonify({
                    "success": False,
                    "error": "허용되지 않은 경로입니다."
                }), 403
        
        # 디렉토리가 존재하지 않으면 생성
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        logger.info(f"File written: {file_path}")
        
        return jsonify({
            "success": True,
            "message": "파일이 성공적으로 저장되었습니다.",
            "path": file_path
        })
        
    except Exception as e:
        logger.error(f"File write error: {str(e)}")
        return jsonify({
            "success": False,
            "error": f"파일 쓰기 중 오류가 발생했습니다: {str(e)}"
        }), 500

@agent_bp.route('/system/status', methods=['GET'])
@cross_origin()
def get_system_status():
    """시스템 상태 조회"""
    try:
        # CPU 사용률
        cpu_result = execute_command_safe("top -bn1 | grep 'Cpu(s)' | awk '{print $2}' | cut -d'%' -f1")
        
        # 메모리 사용량
        memory_result = execute_command_safe("free -h | grep Mem | awk '{print $3}'")
        
        # 디스크 사용량
        disk_result = execute_command_safe("df -h / | tail -1 | awk '{print $5}'")
        
        # 업타임
        uptime_result = execute_command_safe("uptime -p")
        
        return jsonify({
            "success": True,
            "status": {
                "cpu_usage": cpu_result.get("output", "N/A").strip(),
                "memory_usage": memory_result.get("output", "N/A").strip(),
                "disk_usage": disk_result.get("output", "N/A").strip(),
                "uptime": uptime_result.get("output", "N/A").strip()
            }
        })
        
    except Exception as e:
        logger.error(f"System status error: {str(e)}")
        return jsonify({
            "success": False,
            "error": "시스템 상태를 조회할 수 없습니다."
        }), 500

@agent_bp.route('/server/config', methods=['POST'])
@cross_origin()
def server_config():
    """서버 환경 설정 변경"""
    try:
        data = request.get_json()
        if not data or 'action' not in data:
            return jsonify({
                "success": False,
                "error": "작업이 지정되지 않았습니다."
            }), 400
        
        action = data['action']
        
        # 허용된 서버 설정 작업들
        if action == 'restart_nginx':
            result = execute_command_safe("sudo systemctl restart nginx")
        elif action == 'status_nginx':
            result = execute_command_safe("sudo systemctl status nginx")
        elif action == 'reload_nginx':
            result = execute_command_safe("sudo systemctl reload nginx")
        else:
            return jsonify({
                "success": False,
                "error": f"허용되지 않은 작업입니다: {action}"
            }), 400
        
        return jsonify({
            "success": result["success"],
            "message": f"작업 '{action}' 완료",
            "output": result["output"],
            "error": result["error"]
        })
        
    except Exception as e:
        logger.error(f"Server config error: {str(e)}")
        return jsonify({
            "success": False,
            "error": "서버 설정 변경 중 오류가 발생했습니다."
        }), 500

