import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Mic, MicOff, Send, Terminal, FileText, Settings, Smartphone, Volume2, VolumeX } from 'lucide-react'
import './App.css'

const API_BASE_URL = 'http://localhost:5000/api/agent'

function App() {
  const [messages, setMessages] = useState([
    { id: 1, type: 'system', content: 'Chavion AI Agent Computer에 오신 것을 환영합니다. 음성 명령이나 텍스트로 서버를 제어할 수 있습니다.', timestamp: new Date() }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [serverStatus, setServerStatus] = useState('disconnected')
  const [systemInfo, setSystemInfo] = useState({
    cpu_usage: 'N/A',
    memory_usage: 'N/A',
    disk_usage: 'N/A'
  })
  const messagesEndRef = useRef(null)
  const recognitionRef = useRef(null)
  const synthRef = useRef(window.speechSynthesis)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    // Speech Recognition API 초기화
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = false
      recognitionRef.current.interimResults = false
      recognitionRef.current.lang = 'ko-KR'

      recognitionRef.current.onstart = () => {
        setIsListening(true)
        console.log('음성 인식 시작')
      }

      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript
        setInputMessage(transcript)
        console.log('음성 인식 결과:', transcript)
        setIsListening(false)
      }

      recognitionRef.current.onerror = (event) => {
        console.error('음성 인식 오류:', event.error)
        setIsListening(false)
      }

      recognitionRef.current.onend = () => {
        setIsListening(false)
        console.log('음성 인식 종료')
      }
    } else {
      console.warn('Web Speech API (SpeechRecognition)를 지원하지 않는 브라우저입니다.')
    }

    // Speech Synthesis API 초기화
    if (!synthRef.current) {
      console.warn('Web Speech API (SpeechSynthesis)를 지원하지 않는 브라우저입니다.')
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [])

  // 시스템 상태 조회
  const fetchSystemStatus = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/system/status`)
      const data = await response.json()
      if (data.success) {
        setSystemInfo(data.status)
      }
    } catch (error) {
      console.error('시스템 상태 조회 실패:', error)
    }
  }

  useEffect(() => {
    if (isConnected) {
      fetchSystemStatus()
      const interval = setInterval(fetchSystemStatus, 10000) // 10초마다 업데이트
      return () => clearInterval(interval)
    }
  }, [isConnected])

  const executeCommand = async (command) => {
    try {
      const response = await fetch(`${API_BASE_URL}/command`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ command })
      })
      
      const data = await response.json()
      return data
    } catch (error) {
      return {
        success: false,
        error: `네트워크 오류: ${error.message}`
      }
    }
  }

  const speakText = (text) => {
    if (synthRef.current && isSpeaking) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = 'ko-KR'
      synthRef.current.speak(utterance)
    }
  }

  const handleSendMessage = async () => {
    if (inputMessage.trim()) {
      const newMessage = {
        id: messages.length + 1,
        type: 'user',
        content: inputMessage,
        timestamp: new Date()
      }
      setMessages([...messages, newMessage])
      
      const command = inputMessage
      setInputMessage('')
      
      if (isConnected) {
        // 실제 서버 명령 실행
        const result = await executeCommand(command)
        
        const aiResponseContent = result.success 
            ? `명령어 실행 완료:\n${result.output}${result.error ? `\n오류: ${result.error}` : ''}`
            : `명령어 실행 실패: ${result.error}`

        const aiResponse = {
          id: messages.length + 2,
          type: 'agent',
          content: aiResponseContent,
          timestamp: new Date()
        }
        setMessages(prev => [...prev, aiResponse])
        speakText(aiResponseContent)

      } else {
        // 연결되지 않은 경우 시뮬레이션
        const simulatedResponse = `서버에 연결되지 않았습니다. 먼저 "서버 연결" 버튼을 클릭하세요.`
        setTimeout(() => {
          const aiResponse = {
            id: messages.length + 2,
            type: 'agent',
            content: simulatedResponse,
            timestamp: new Date()
          }
          setMessages(prev => [...prev, aiResponse])
          speakText(simulatedResponse)
        }, 1000)
      }
    }
  }

  const toggleListening = () => {
    if (recognitionRef.current) {
      if (isListening) {
        recognitionRef.current.stop()
      } else {
        recognitionRef.current.start()
      }
    }
  }

  const toggleSpeaking = () => {
    setIsSpeaking(!isSpeaking)
    if (synthRef.current) {
      if (isSpeaking) {
        synthRef.current.cancel() // 음성 출력 중지
      }
    }
  }

  const connectToServer = async () => {
    if (!isConnected) {
      // 서버 연결 시도
      try {
        const response = await fetch(`${API_BASE_URL}/system/status`)
        if (response.ok) {
          setIsConnected(true)
          setServerStatus('connected')
          
          const connectMessageContent = '서버에 성공적으로 연결되었습니다. 이제 명령어를 실행할 수 있습니다.'
          const connectMessage = {
            id: messages.length + 1,
            type: 'system',
            content: connectMessageContent,
            timestamp: new Date()
          }
          setMessages(prev => [...prev, connectMessage])
          speakText(connectMessageContent)

        } else {
          throw new Error('서버 응답 오류')
        }
      } catch (error) {
        const errorMessageContent = `서버 연결에 실패했습니다: ${error.message}`
        const errorMessage = {
          id: messages.length + 1,
          type: 'system',
          content: errorMessageContent,
          timestamp: new Date()
        }
        setMessages(prev => [...prev, errorMessage])
        speakText(errorMessageContent)
      }
    } else {
      setIsConnected(false)
      setServerStatus('disconnected')
      
      const disconnectMessageContent = '서버 연결이 해제되었습니다.'
      const disconnectMessage = {
        id: messages.length + 1,
        type: 'system',
        content: disconnectMessageContent,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, disconnectMessage])
      speakText(disconnectMessageContent)
    }
  }

  const executeQuickAction = async (action) => {
    if (!isConnected) {
      const errorMessageContent = '서버에 연결되지 않았습니다.'
      const errorMessage = {
        id: messages.length + 1,
        type: 'system',
        content: errorMessageContent,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
      speakText(errorMessageContent)
      return
    }

    let command = ''
    switch (action) {
      case 'system_status':
        command = 'uptime && free -h && df -h'
        break
      case 'view_logs':
        command = 'tail -20 /var/log/syslog'
        break
      case 'restart_server':
        command = 'sudo systemctl status nginx' // 실제 재시작은 위험하므로 상태 확인으로 대체
        break
      default:
        return
    }

    const result = await executeCommand(command)
    const responseContent = result.success 
      ? `${action} 실행 완료:\n${result.output}${result.error ? `\n오류: ${result.error}` : ''}`
      : `${action} 실행 실패: ${result.error}`

    const response = {
      id: messages.length + 1,
      type: 'agent',
      content: responseContent,
      timestamp: new Date()
    }
    setMessages(prev => [...prev, response])
    speakText(responseContent)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                <Terminal className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-white">Chavion</h1>
              <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                AI Agent Computer
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge 
                variant={serverStatus === 'connected' ? 'default' : 'destructive'}
                className={serverStatus === 'connected' ? 'bg-green-500/20 text-green-300 border-green-500/30' : ''}
              >
                {serverStatus === 'connected' ? '서버 연결됨' : '서버 연결 안됨'}
              </Badge>
              <Button 
                variant="outline" 
                size="sm"
                onClick={connectToServer}
                className="border-white/20 text-white hover:bg-white/10"
              >
                <Settings className="w-4 h-4 mr-2" />
                {isConnected ? '연결 해제' : '서버 연결'}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Chat Area */}
          <div className="lg:col-span-3">
            <Card className="h-[calc(100vh-200px)] bg-black/40 border-white/10 backdrop-blur-sm">
              <CardHeader className="border-b border-white/10">
                <CardTitle className="text-white flex items-center">
                  <Terminal className="w-5 h-5 mr-2" />
                  AI Agent Terminal
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0 h-full flex flex-col">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          message.type === 'user'
                            ? 'bg-purple-600 text-white'
                            : message.type === 'agent'
                            ? 'bg-blue-600/80 text-white'
                            : 'bg-gray-600/80 text-gray-200'
                        }`}
                      >
                        <pre className="text-sm whitespace-pre-wrap font-mono">{message.content}</pre>
                        <p className="text-xs opacity-70 mt-1">
                          {message.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <div className="border-t border-white/10 p-4">
                  <div className="flex space-x-2">
                    <div className="flex-1 relative">
                      <Input
                        value={inputMessage}
                        onChange={(e) => setInputMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        placeholder="명령어를 입력하거나 음성으로 말하세요..."
                        className="bg-white/10 border-white/20 text-white placeholder-gray-400 pr-12"
                      />
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={toggleListening}
                        className={`absolute right-2 top-1/2 transform -translate-y-1/2 ${
                          isListening ? 'text-red-400 animate-pulse' : 'text-gray-400'
                        }`}
                      >
                        {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                      </Button>
                    </div>
                    <Button 
                      onClick={handleSendMessage}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  {/* Voice Controls */}
                  <div className="flex items-center justify-between mt-3 text-sm text-gray-400">
                    <div className="flex items-center space-x-4">
                      <span className={isListening ? 'text-red-400 animate-pulse' : ''}>
                        {isListening ? '음성 인식 중...' : '음성 명령 대기'}
                      </span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={toggleSpeaking}
                        className={`${isSpeaking ? 'text-green-400' : 'text-gray-400'}`}
                      >
                        {isSpeaking ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                        {isSpeaking ? '음성 응답 켜짐' : '음성 응답 꺼짐'}
                      </Button>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Smartphone className="w-4 h-4" />
                      <span>모바일 최적화</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Server Status */}
            <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white text-lg">서버 상태</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">CPU 사용률</span>
                  <Badge variant="outline" className="border-green-500/30 text-green-300">
                    {systemInfo.cpu_usage}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">메모리</span>
                  <Badge variant="outline" className="border-blue-500/30 text-blue-300">
                    {systemInfo.memory_usage}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">디스크</span>
                  <Badge variant="outline" className="border-yellow-500/30 text-yellow-300">
                    {systemInfo.disk_usage}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white text-lg">빠른 작업</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start border-white/20 text-white hover:bg-white/10"
                  onClick={() => executeQuickAction('system_status')}
                >
                  <Terminal className="w-4 h-4 mr-2" />
                  시스템 상태 확인
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start border-white/20 text-white hover:bg-white/10"
                  onClick={() => executeQuickAction('view_logs')}
                >
                  <FileText className="w-4 h-4 mr-2" />
                  로그 파일 보기
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start border-white/20 text-white hover:bg-white/10"
                  onClick={() => executeQuickAction('restart_server')}
                >
                  <Settings className="w-4 h-4 mr-2" />
                  서버 상태 확인
                </Button>
              </CardContent>
            </Card>

            {/* Features */}
            <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white text-lg">기능</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  <span className="text-gray-300 text-sm">서버 직접 제어</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-300 text-sm">음성 명령 인식</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-300 text-sm">음성 응답</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-300 text-sm">모바일 호환</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-300 text-sm">실시간 채팅</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App

