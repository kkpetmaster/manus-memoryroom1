from flask import Blueprint, request, jsonify
from datetime import datetime

aiin_bp = Blueprint('aiin', __name__)

# AIIN으로부터 메시지를 수신하는 엔드포인트
@aiin_bp.route('/from-aiin', methods=['POST'])
def receive_from_aiin():
    try:
        data = request.get_json()
        
        # 요청 로깅
        print(f"[{datetime.now()}] AIIN으로부터 메시지 수신:")
        print(f"Headers: {dict(request.headers)}")
        print(f"Data: {data}")
        
        # 기본 응답
        response = {
            "status": "success",
            "message": "새로운 마누스 계정에서 메시지를 성공적으로 수신했습니다.",
            "timestamp": datetime.now().isoformat(),
            "received_data": data
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        error_response = {
            "status": "error",
            "message": f"메시지 처리 중 오류 발생: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }
        return jsonify(error_response), 500

# 연결 상태 확인 엔드포인트
@aiin_bp.route('/status', methods=['GET'])
def status():
    return jsonify({
        "status": "active",
        "message": "새로운 마누스 계정이 AIIN 연결을 위해 대기 중입니다.",
        "endpoints": {
            "receive_messages": "/api/aiin/from-aiin",
            "status_check": "/api/aiin/status"
        },
        "timestamp": datetime.now().isoformat()
    }), 200

# AIIN에게 응답을 보내는 엔드포인트 (필요시 사용)
@aiin_bp.route('/to-aiin', methods=['POST'])
def send_to_aiin():
    try:
        data = request.get_json()
        
        # 여기에 AIIN으로 메시지를 보내는 로직을 추가할 수 있습니다
        print(f"[{datetime.now()}] AIIN으로 메시지 전송 요청:")
        print(f"Data: {data}")
        
        response = {
            "status": "success",
            "message": "AIIN으로 메시지 전송 완료",
            "timestamp": datetime.now().isoformat(),
            "sent_data": data
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        error_response = {
            "status": "error",
            "message": f"메시지 전송 중 오류 발생: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }
        return jsonify(error_response), 500

