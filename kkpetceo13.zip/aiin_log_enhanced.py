#!/usr/bin/env python3
import os
import sys
import json
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS

# 로그 파일 경로
LOG_FILE = "/tmp/aiin_messages.log"

app = Flask(__name__)
CORS(app)

def log_message(data, source="unknown"):
    """메시지를 로그 파일에 저장"""
    timestamp = datetime.now().isoformat()
    log_entry = {
        "timestamp": timestamp,
        "source": source,
        "data": data,
        "headers": dict(request.headers) if request else {}
    }
    
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
    except Exception as e:
        print(f"로그 저장 오류: {e}")

@app.route('/api/aiin/from-aiin', methods=['POST'])
def receive_from_aiin():
    """AIIN으로부터 메시지를 수신하는 엔드포인트"""
    try:
        data = request.get_json()
        
        # 콘솔에 출력
        print(f"[{datetime.now()}] AIIN으로부터 메시지 수신:")
        print(f"Headers: {dict(request.headers)}")
        print(f"Data: {data}")
        
        # 로그 파일에 저장
        log_message(data, "aiin")
        
        # 기본 응답
        response = {
            "status": "success",
            "message": "새로운 마누스 계정에서 메시지를 성공적으로 수신했습니다.",
            "timestamp": datetime.now().isoformat(),
            "received_data": data
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        error_response = {
            "status": "error",
            "message": f"메시지 처리 중 오류 발생: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }
        log_message({"error": str(e)}, "error")
        return jsonify(error_response), 500

@app.route('/api/aiin/status', methods=['GET'])
def status():
    """연결 상태 확인 엔드포인트"""
    return jsonify({
        "status": "active",
        "message": "새로운 마누스 계정이 AIIN 연결을 위해 대기 중입니다.",
        "endpoints": {
            "receive_messages": "/api/aiin/from-aiin",
            "status_check": "/api/aiin/status",
            "logs": "/api/aiin/logs"
        },
        "timestamp": datetime.now().isoformat()
    }), 200

@app.route('/api/aiin/logs', methods=['GET'])
def get_logs():
    """저장된 AIIN 메시지 로그를 반환"""
    try:
        if not os.path.exists(LOG_FILE):
            return jsonify({
                "status": "success",
                "message": "아직 수신된 메시지가 없습니다.",
                "logs": [],
                "count": 0
            }), 200
        
        logs = []
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    log_entry = json.loads(line.strip())
                    logs.append(log_entry)
                except json.JSONDecodeError:
                    continue
        
        # 최신 메시지부터 정렬
        logs.reverse()
        
        return jsonify({
            "status": "success",
            "message": f"총 {len(logs)}개의 메시지 로그를 찾았습니다.",
            "logs": logs,
            "count": len(logs),
            "timestamp": datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"로그 조회 중 오류 발생: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }), 500

@app.route('/api/aiin/logs/latest', methods=['GET'])
def get_latest_log():
    """가장 최근 수신된 AIIN 메시지를 반환"""
    try:
        if not os.path.exists(LOG_FILE):
            return jsonify({
                "status": "success",
                "message": "아직 수신된 메시지가 없습니다.",
                "latest_message": None
            }), 200
        
        latest_log = None
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    log_entry = json.loads(line.strip())
                    if log_entry.get("source") == "aiin":
                        latest_log = log_entry
                except json.JSONDecodeError:
                    continue
        
        if latest_log:
            return jsonify({
                "status": "success",
                "message": "가장 최근 AIIN 메시지를 찾았습니다.",
                "latest_message": latest_log,
                "timestamp": datetime.now().isoformat()
            }), 200
        else:
            return jsonify({
                "status": "success",
                "message": "AIIN으로부터 수신된 메시지가 없습니다.",
                "latest_message": None,
                "timestamp": datetime.now().isoformat()
            }), 200
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"최신 로그 조회 중 오류 발생: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }), 500

if __name__ == '__main__':
    print(f"AIIN 메시지 로그 서버 시작...")
    print(f"로그 파일: {LOG_FILE}")
    app.run(host='0.0.0.0', port=8000, debug=True)

