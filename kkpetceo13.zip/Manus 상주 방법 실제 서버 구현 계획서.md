# Manus 상주 방법 실제 서버 구현 계획서

## 개요

사용자님의 채팅 웹에 Manus가 독립적으로 상주하여 AIIN(GPTs)과 협력하면서 자동 수익화 작업을 수행할 수 있는 환경을 실제 서버(aiin-server, Ubuntu 22.04.5 LTS, GCP)에 구현하기 위한 상세 계획서입니다.

## 1. 구현 아키텍처

### 1.1 전체 시스템 구조
```
[AIIN (GPTs)] ←→ [채팅 웹 Flask 백엔드] ←→ [Manus Docker 컨테이너]
                                                    ↓
                                            [실제 서버 명령 실행]
                                                    ↓
                                            [자동 수익화 작업 수행]
```

### 1.2 주요 구성 요소
1. **Manus Agent Container**: Manus의 핵심 로직이 실행되는 Docker 컨테이너
2. **Command Executor**: 터미널 명령어 실행 및 결과 반환 모듈
3. **Revenue Automation Engine**: 다양한 수익화 작업을 자동화하는 엔진
4. **Communication Bridge**: 채팅 웹 백엔드와의 통신 인터페이스

## 2. Manus Docker 컨테이너 설계

### 2.1 Dockerfile 구성
```dockerfile
FROM python:3.11-slim

# 시스템 패키지 설치
RUN apt-get update && apt-get install -y \
    curl \
    wget \
    git \
    vim \
    nodejs \
    npm \
    chromium-browser \
    && rm -rf /var/lib/apt/lists/*

# Python 패키지 설치
COPY requirements.txt .
RUN pip install -r requirements.txt

# 작업 디렉토리 설정
WORKDIR /app

# Manus 에이전트 코드 복사
COPY manus_agent/ .

# 포트 노출
EXPOSE 8080

# 실행 명령
CMD ["python", "manus_main.py"]
```

### 2.2 필요한 Python 패키지 (requirements.txt)
```
flask==3.0.0
flask-cors==4.0.0
flask-socketio==5.3.6
requests==2.31.0
selenium==4.15.0
beautifulsoup4==4.12.2
pandas==2.1.3
numpy==1.25.2
openai==1.3.0
google-api-python-client==2.108.0
youtube-dl==2021.12.17
yt-dlp==2023.11.16
paramiko==3.3.1
celery==5.3.4
redis==5.0.1
schedule==1.2.0
python-dotenv==1.0.0
```

## 3. Manus Agent 핵심 모듈

### 3.1 메인 애플리케이션 (manus_main.py)```python
#!/usr/bin/env python3
"""
Manus Agent Main Application
사용자 채팅 웹에 상주하여 자동 수익화 작업을 수행하는 Manus 에이전트
"""

import os
import json
import logging
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import subprocess
import threading
import time

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, origins="*")
socketio = SocketIO(app, cors_allowed_origins="*")

class ManusAgent:    def __init__(self):
        self.is_running = True
        self.active_tasks = {}
        self.revenue_engines = {}
        
    def execute_command(self, command, working_dir="/app"):
        """터미널 명령어 실행"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=working_dir,
                capture_output=True,
                text=True,
                timeout=300  # 5분 타임아웃
            )
            
            return {
                "success": True,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode,
                "timestamp": datetime.now().isoformat()
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Command timeout (5 minutes)",
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def start_revenue_automation(self, task_type, config):
        """수익화 자동화 작업 시작"""
        task_id = f"{task_type}_{int(time.time())}"
        
        if task_type == "youtube":
            return self.start_youtube_automation(task_id, config)
        elif task_type == "blog":
            return self.start_blog_automation(task_id, config)
        elif task_type == "general":
            return self.start_general_automation(task_id, config)
        else:
            return {
                "success": False,
                "error": f"Unknown task type: {task_type}"
            }
    
    def start_youtube_automation(self, task_id, config):
        """YouTube 수익화 자동화"""
        # YouTube 자동화 로직 구현
        logger.info(f"Starting YouTube automation task: {task_id}")
        # 실제 구현은 여기에...
        return {"success": True, "task_id": task_id, "type": "youtube"}
    
    def start_blog_automation(self, task_id, config):
        """블로그 수익화 자동화"""
        # 블로그 자동화 로직 구현
        logger.info(f"Starting blog automation task: {task_id}")
        # 실제 구현은 여기에...
        return {"success": True, "task_id": task_id, "type": "blog"}
    
    def start_general_automation(self, task_id, config):
        """일반 수익화 자동화"""
        # 일반 자동화 로직 구현
        logger.info(f"Starting general automation task: {task_id}")
        # 실제 구현은 여기에...
        return {"success": True, "task_id": task_id, "type": "general"}

# Manus Agent 인스턴스 생성
manus = ManusAgent()

@app.route("/api/manus/status", methods=["GET"])
def status():
    """Gemini Agent 상태 확인"""
    return jsonify({
        "status": "active",
        "message": "Manus Agent가 사용자 서버에서 상주 중입니다.",
        "timestamp": datetime.now().isoformat(),
        "active_tasks": len(manus.active_tasks),
        "endpoints": {
            "execute_command": "/api/manus/execute",
            "start_automation": "/api/manus/automate",
            "get_tasks": "/api/manus/tasks"
        }
    })

@app.route("/api/manus/execute", methods=["POST"])
def execute_command():
    """명령어 실행 엔드포인트"""
    try:
        data = request.get_json()
        command = data.get('command')
        working_dir = data.get('working_dir', '/app')
        
        if not command:
            return jsonify({
                "success": False,
                "error": "Command is required"
            }), 400
        
        logger.info(f"Executing command: {command}")
        result = manus.execute_command(command, working_dir)
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error executing command: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route("/api/manus/automate", methods=["POST"])
def start_automation():
    """자동화 작업 시작 엔드포인트"""
    try:
        data = request.get_json()
        task_type = data.get('type')
        config = data.get('config', {})
        
        if not task_type:
            return jsonify({
                "success": False,
                "error": "Task type is required"
            }), 400
        
        logger.info(f"Starting automation: {task_type}")
        result = manus.start_revenue_automation(task_type, config)
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error starting automation: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/api/gemini/tasks', methods=['GET'])
def get_tasks():
    """활성 작업 목록 조회"""
    return jsonify({
        "active_tasks": manus.active_tasks,
        "count": len(manus.active_tasks),
        "timestamp": datetime.now().isoformat()
    })

@socketio.on('connect')
def handle_connect():
    """WebSocket 연결 처리"""
    logger.info("Client connected to Manus Agent")
    emit("status", {"message": "Connected to Manus Agent"})

@socketio.on('command')
def handle_command(data):
    """WebSocket을 통한 명령어 처리"""
    command = data.get('command')
    if command:
        result = gemini.execute_command(command)
        emit('command_result', result)

if __name__ == '__main__':
    logger.info("Starting Gemini Agent...")
    socketio.run(app, host='0.0.0.0', port=8080, debug=False)
```

## 4. Docker Compose 통합

### 4.1 기존 docker-compose.yml 업데이트
```yaml
version: '3.8'

services:
  chat-web:
    build: .
    ports:
      - "5000:5000"
    environment:
      - FLASK_ENV=production
    volumes:
      - ./data:/app/data
    depends_on:
      - gemini-agent
      - redis
    networks:
      - chat-network

  gemini-agent:
    build:
      context: ./gemini-agent
      dockerfile: Dockerfile
    ports:
      - "8080:8080"
    environment:
      - GEMINI_ENV=production
      - REDIS_URL=redis://redis:6379
    volumes:
      - ./gemini-data:/app/data
      - ./logs:/app/logs
    depends_on:
      - redis
    networks:
      - chat-network
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    networks:
      - chat-network
    restart: unless-stopped

volumes:
  redis-data:
  gemini-data:

networks:
  chat-network:
    driver: bridge
```

## 5. 채팅 웹 백엔드 통합

### 5.1 Flask 백엔드에 Gemini 통신 모듈 추가
```python
# gemini_bridge.py
import requests
import json
from datetime import datetime

class GeminiBridge:
    def __init__(self, gemini_url="http://gemini-agent:8080"):
        self.gemini_url = gemini_url
    
    def send_command_to_gemini(self, command, working_dir="/app"):
        """Gemini에게 명령어 전송"""
        try:
            response = requests.post(
                f"{self.gemini_url}/api/gemini/execute",
                json={
                    "command": command,
                    "working_dir": working_dir
                },
                timeout=30
            )
            return response.json()
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to communicate with Gemini: {str(e)}"
            }
    
    def start_automation_task(self, task_type, config):
        """Gemini에게 자동화 작업 시작 요청"""
        try:
            response = requests.post(
                f"{self.gemini_url}/api/gemini/automate",
                json={
                    "type": task_type,
                    "config": config
                },
                timeout=30
            )
            return response.json()
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to start automation: {str(e)}"
            }
```

## 6. 보안 및 권한 설정

### 6.1 컨테이너 보안 설정
- 최소 권한 원칙 적용
- 민감한 환경 변수는 Docker secrets 사용
- 컨테이너 간 통신 암호화
- 정기적인 보안 업데이트

### 6.2 접근 제어
- API 키 기반 인증
- IP 화이트리스트
- 요청 속도 제한

## 7. 배포 및 실행 계획

### 7.1 사용자 서버에서 실행할 명령어 순서
1. 프로젝트 디렉토리 생성 및 파일 복사
2. Docker 이미지 빌드
3. Docker Compose로 서비스 시작
4. 연결 테스트

### 7.2 실행 스크립트
```bash
#!/bin/bash
# deploy_gemini.sh

echo "Gemini Agent 배포 시작..."

# 1. 프로젝트 디렉토리 생성
mkdir -p /home/aiinmaster25/gemini-residency
cd /home/aiinmaster25/gemini-residency

# 2. 필요한 디렉토리 생성
mkdir -p gemini-agent logs gemini-data

# 3. Docker Compose 파일 생성
cat > docker-compose.yml << 'EOF'
# Docker Compose 내용 (위에서 정의한 내용)
EOF

# 4. Gemini Agent 코드 생성
cat > gemini-agent/gemini_main.py << 'EOF'
# Gemini Main 코드 (위에서 정의한 내용)
EOF

# 5. Dockerfile 생성
cat > gemini-agent/Dockerfile << 'EOF'
# Dockerfile 내용 (위에서 정의한 내용)
EOF

# 6. requirements.txt 생성
cat > gemini-agent/requirements.txt << 'EOF'
# Requirements 내용 (위에서 정의한 내용)
EOF

# 7. Docker Compose 실행
docker-compose up -d

echo "Gemini Agent 배포 완료!"
echo "상태 확인: curl http://localhost:8080/api/gemini/status"
```

## 8. 테스트 및 검증 계획

### 8.1 기본 기능 테스트
- Gemini Agent 컨테이너 실행 확인
- API 엔드포인트 응답 테스트
- 명령어 실행 기능 테스트

### 8.2 통합 테스트
- 채팅 웹과 Gemini Agent 간 통신 테스트
- AIIN으로부터 명령 수신 및 처리 테스트
- 자동화 작업 시작 및 모니터링 테스트

## 9. 모니터링 및 로깅

### 9.1 로그 관리
- 모든 명령어 실행 로그 기록
- 자동화 작업 진행 상황 로그
- 오류 및 예외 상황 로그

### 9.2 성능 모니터링
- 컨테이너 리소스 사용량 모니터링
- API 응답 시간 측정
- 자동화 작업 성공률 추적

이 구현 계획서를 바탕으로 사용자님의 실제 서버에 Gemini Agent를 배포하고 테스트할 준비가 되었습니다.

