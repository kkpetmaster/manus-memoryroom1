#!/usr/bin/env python3
import requests
import json
from datetime import datetime

def check_aiin_status():
    """AIIN API 상태를 확인하고 메시지 수신 여부를 체크"""
    
    base_url = "https://e5h6i7cn6wlo.manus.space"
    status_endpoint = f"{base_url}/api/aiin/status"
    
    try:
        print(f"[{datetime.now()}] AIIN API 상태 확인 중...")
        print(f"URL: {status_endpoint}")
        
        # 상태 확인 요청
        response = requests.get(status_endpoint, timeout=10)
        
        print(f"응답 상태 코드: {response.status_code}")
        print(f"응답 헤더: {dict(response.headers)}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                print("✅ API 상태 확인 성공!")
                print(f"응답 데이터: {json.dumps(data, indent=2, ensure_ascii=False)}")
                
                # 메시지 수신 여부 확인을 위한 테스트 메시지 전송
                test_message_endpoint = f"{base_url}/api/aiin/from-aiin"
                test_data = {
                    "type": "status_check",
                    "message": "AIIN 연결 상태 확인 테스트",
                    "timestamp": datetime.now().isoformat(),
                    "source": "manual_check"
                }
                
                print(f"\n[{datetime.now()}] 테스트 메시지 전송 중...")
                test_response = requests.post(test_message_endpoint, 
                                            json=test_data, 
                                            headers={'Content-Type': 'application/json'},
                                            timeout=10)
                
                print(f"테스트 메시지 응답 상태: {test_response.status_code}")
                if test_response.status_code == 200:
                    test_result = test_response.json()
                    print("✅ 테스트 메시지 전송 성공!")
                    print(f"테스트 응답: {json.dumps(test_result, indent=2, ensure_ascii=False)}")
                else:
                    print(f"❌ 테스트 메시지 전송 실패: {test_response.text}")
                
            except json.JSONDecodeError:
                print(f"❌ JSON 파싱 실패. 응답 내용: {response.text}")
        else:
            print(f"❌ API 상태 확인 실패: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ 요청 오류: {e}")
    except Exception as e:
        print(f"❌ 예상치 못한 오류: {e}")

if __name__ == "__main__":
    check_aiin_status()

