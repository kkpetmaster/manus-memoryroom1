#!/bin/bash
# deploy_manus_agent.sh
# Manus Agent를 사용자 서버에 배포하는 스크립트

echo "🚀 Manus Agent 배포 시작..."

# 1. 프로젝트 디렉토리 생성
echo "📁 프로젝트 디렉토리 생성 중..."
mkdir -p /home/aiinmaster25/manus-residency
cd /home/aiinmaster25/manus-residency

# 2. 필요한 디렉토리 생성
echo "📂 필요한 디렉토리 생성 중..."
mkdir -p manus-agent logs manus-data

# 3. requirements.txt 생성
echo "📋 requirements.txt 생성 중..."
cat > manus-agent/requirements.txt << 'EOF'
flask==3.0.0
flask-cors==4.0.0
flask-socketio==5.3.6
requests==2.31.0
selenium==4.15.0
beautifulsoup4==4.12.2
pandas==2.1.3
numpy==1.25.2
openai==1.3.0
google-api-python-client==2.108.0
youtube-dl==2021.12.17
yt-dlp==2023.11.16
paramiko==3.3.1
celery==5.3.4
redis==5.0.1
schedule==1.2.0
python-dotenv==1.0.0
EOF

# 4. Dockerfile 생성
echo "🐳 Dockerfile 생성 중..."
cat > manus-agent/Dockerfile << 'EOF'
FROM python:3.11-slim

# 시스템 패키지 설치
RUN apt-get update && apt-get install -y \
    curl \
    wget \
    git \
    vim \
    nodejs \
    npm \
    chromium-browser \
    && rm -rf /var/lib/apt/lists/*

# Python 패키지 설치
COPY requirements.txt .
RUN pip install -r requirements.txt

# 작업 디렉토리 설정
WORKDIR /app

# Manus 에이전트 코드 복사
COPY . .

# 포트 노출
EXPOSE 8080

# 실행 명령
CMD ["python", "manus_main.py"]
EOF

# 5. Manus Agent 메인 코드 생성
echo "🤖 Manus Agent 메인 코드 생성 중..."
cat > manus-agent/manus_main.py << 'EOF'
#!/usr/bin/env python3
"""
Manus Agent Main Application
사용자 채팅 웹에 상주하여 자동 수익화 작업을 수행하는 Manus 에이전트
"""

import os
import json
import logging
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import subprocess
import threading
import time

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, origins="*")
socketio = SocketIO(app, cors_allowed_origins="*")

class ManusAgent:
    def __init__(self):
        self.is_running = True
        self.active_tasks = {}
        self.revenue_engines = {}
        
    def execute_command(self, command, working_dir="/app"):
        """터미널 명령어 실행"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=working_dir,
                capture_output=True,
                text=True,
                timeout=300  # 5분 타임아웃
            )
            
            return {
                "success": True,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode,
                "timestamp": datetime.now().isoformat()
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Command timeout (5 minutes)",
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def start_revenue_automation(self, task_type, config):
        """수익화 자동화 작업 시작"""
        task_id = f"{task_type}_{int(time.time())}"
        
        if task_type == "youtube":
            return self.start_youtube_automation(task_id, config)
        elif task_type == "blog":
            return self.start_blog_automation(task_id, config)
        elif task_type == "general":
            return self.start_general_automation(task_id, config)
        else:
            return {
                "success": False,
                "error": f"Unknown task type: {task_type}"
            }
    
    def start_youtube_automation(self, task_id, config):
        """YouTube 수익화 자동화"""
        logger.info(f"Starting YouTube automation task: {task_id}")
        self.active_tasks[task_id] = {
            "type": "youtube",
            "status": "running",
            "config": config,
            "started_at": datetime.now().isoformat()
        }
        return {"success": True, "task_id": task_id, "type": "youtube"}
    
    def start_blog_automation(self, task_id, config):
        """블로그 수익화 자동화"""
        logger.info(f"Starting blog automation task: {task_id}")
        self.active_tasks[task_id] = {
            "type": "blog",
            "status": "running",
            "config": config,
            "started_at": datetime.now().isoformat()
        }
        return {"success": True, "task_id": task_id, "type": "blog"}
    
    def start_general_automation(self, task_id, config):
        """일반 수익화 자동화"""
        logger.info(f"Starting general automation task: {task_id}")
        self.active_tasks[task_id] = {
            "type": "general",
            "status": "running",
            "config": config,
            "started_at": datetime.now().isoformat()
        }
        return {"success": True, "task_id": task_id, "type": "general"}

# Manus Agent 인스턴스 생성
manus = ManusAgent()

@app.route("/api/manus/status", methods=["GET"])
def status():
    """Manus Agent 상태 확인"""
    return jsonify({
        "status": "active",
        "message": "Manus Agent가 사용자 서버에서 상주 중입니다.",
        "timestamp": datetime.now().isoformat(),
        "active_tasks": len(manus.active_tasks),
        "endpoints": {
            "execute_command": "/api/manus/execute",
            "start_automation": "/api/manus/automate",
            "get_tasks": "/api/manus/tasks"
        }
    })

@app.route("/api/manus/execute", methods=["POST"])
def execute_command():
    """명령어 실행 엔드포인트"""
    try:
        data = request.get_json()
        command = data.get('command')
        working_dir = data.get('working_dir', '/app')
        
        if not command:
            return jsonify({
                "success": False,
                "error": "Command is required"
            }), 400
        
        logger.info(f"Executing command: {command}")
        result = manus.execute_command(command, working_dir)
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error executing command: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route("/api/manus/automate", methods=["POST"])
def start_automation():
    """자동화 작업 시작 엔드포인트"""
    try:
        data = request.get_json()
        task_type = data.get('type')
        config = data.get('config', {})
        
        if not task_type:
            return jsonify({
                "success": False,
                "error": "Task type is required"
            }), 400
        
        logger.info(f"Starting automation: {task_type}")
        result = manus.start_revenue_automation(task_type, config)
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error starting automation: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route("/api/manus/tasks", methods=["GET"])
def get_tasks():
    """활성 작업 목록 조회"""
    return jsonify({
        "active_tasks": manus.active_tasks,
        "count": len(manus.active_tasks),
        "timestamp": datetime.now().isoformat()
    })

@socketio.on('connect')
def handle_connect():
    """WebSocket 연결 처리"""
    logger.info("Client connected to Manus Agent")
    emit("status", {"message": "Connected to Manus Agent"})

@socketio.on('command')
def handle_command(data):
    """WebSocket을 통한 명령어 처리"""
    command = data.get('command')
    if command:
        result = manus.execute_command(command)
        emit('command_result', result)

if __name__ == '__main__':
    logger.info("Starting Manus Agent...")
    socketio.run(app, host='0.0.0.0', port=8080, debug=False)
EOF

# 6. Docker Compose 파일 생성
echo "🐙 Docker Compose 파일 생성 중..."
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  manus-agent:
    build:
      context: ./manus-agent
      dockerfile: Dockerfile
    ports:
      - "8080:8080"
    environment:
      - MANUS_ENV=production
      - REDIS_URL=redis://redis:6379
    volumes:
      - ./manus-data:/app/data
      - ./logs:/app/logs
    depends_on:
      - redis
    networks:
      - manus-network
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    networks:
      - manus-network
    restart: unless-stopped

volumes:
  redis-data:
  manus-data:

networks:
  manus-network:
    driver: bridge
EOF

# 7. Docker 이미지 빌드 및 실행
echo "🔨 Docker 이미지 빌드 중..."
docker-compose build

echo "🚀 Docker Compose 서비스 시작 중..."
docker-compose up -d

# 8. 서비스 상태 확인
echo "⏳ 서비스 시작 대기 중..."
sleep 10

echo "🔍 서비스 상태 확인 중..."
docker-compose ps

echo "🌐 API 상태 테스트 중..."
curl -s http://localhost:8080/api/manus/status | python3 -m json.tool

echo ""
echo "✅ Manus Agent 배포 완료!"
echo ""
echo "📊 상태 확인: curl http://localhost:8080/api/manus/status"
echo "🔧 명령 실행: curl -X POST http://localhost:8080/api/manus/execute -H 'Content-Type: application/json' -d '{\"command\":\"ls -la\"}"
echo "🤖 자동화 시작: curl -X POST http://localhost:8080/api/manus/automate -H 'Content-Type: application/json' -d '{\"type\":\"general\",\"config\":{}}'"
echo "📋 작업 목록: curl http://localhost:8080/api/manus/tasks"
echo ""
echo "🔗 AIIN 연결 주소: http://localhost:8080/api/manus/execute"
echo ""

