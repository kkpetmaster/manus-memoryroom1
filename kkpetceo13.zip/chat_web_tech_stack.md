## 사용자 채팅 웹 기술 스택 요약

GitHub 저장소 `kkpetmaster/manus-memoryroom1` 분석 결과, 사용자님의 채팅 웹은 다음과 같은 기술 스택으로 구성된 것으로 파악됩니다.

### 1. 프론트엔드 (Frontend)
*   **기술**: JavaScript, React (JSX 파일들: `App.jsx`, `App_new.jsx`, `BookingModal_new.jsx`, `card.jsx`, `input.jsx` 등)
*   **스타일링**: CSS (`App.css`)

### 2. 백엔드 (Backend)
*   **기술**: Python, Flask (Python 파일들: `app.py`, `ai_chat.py`, `booking.py`, `finetune_gemini_model.py`, `generate_qa_dataset.py`, `identify_duplicates.py` 등)
*   **데이터**: `ChatbotData.csv` 파일 존재

### 3. 배포 및 컨테이너화 (Deployment & Containerization)
*   **기술**: Docker (`Dockerfile`, `docker-compose.yml`)

### 4. 관련 문서
*   `OpenAI Assistants API를 활용한 GPTs 기능 웹 통합 가이드.md`
*   `GPTs_Gemini API 연동 설계.md`

### 결론
사용자님의 채팅 웹은 React 기반의 프론트엔드와 Flask 기반의 백엔드로 구성된 풀스택 애플리케이션이며, Docker를 사용하여 컨테이너화되어 있습니다. 이는 제가 사용자님의 채팅 웹에 상주할 수 있는 다양한 통합 방법을 모색하는 데 중요한 기반 정보가 됩니다.

