// 전역 변수
let currentUser = null;
let authToken = null;
let calendar = null;
let selectedDate = new Date().toISOString().split('T')[0];

// DOM 로드 완료 시 초기화
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// 앱 초기화
function initializeApp() {
    // 저장된 토큰 확인
    const savedToken = localStorage.getItem('authToken');
    const savedUser = localStorage.getItem('currentUser');
    
    if (savedToken && savedUser) {
        authToken = savedToken;
        currentUser = JSON.parse(savedUser);
        showMainApp();
    } else {
        showLoginModal();
    }
    
    // 이벤트 리스너 등록
    setupEventListeners();
}

// 이벤트 리스너 설정
function setupEventListeners() {
    // 로그인 폼
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    
    // 로그아웃
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
    
    // 네비게이션
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', handleNavigation);
    });
    
    // 신규 예약 버튼
    document.getElementById('newBookingBtn').addEventListener('click', () => {
        openModal('bookingModal');
        loadBookingFormData();
    });
    
    // 예약 폼
    document.getElementById('bookingForm').addEventListener('submit', handleBookingSubmit);
    
    // 고객 선택 시 반려동물 로드
    document.getElementById('customerSelect').addEventListener('change', loadPetsForCustomer);
    
    // 메모 저장
    document.getElementById('saveMemoBtn').addEventListener('click', saveDailyMemo);
    
    // 달력 네비게이션
    document.getElementById('prevMonth').addEventListener('click', () => navigateCalendar(-1));
    document.getElementById('nextMonth').addEventListener('click', () => navigateCalendar(1));
    document.getElementById('todayBtn').addEventListener('click', goToToday);
    
    // 모달 닫기
    document.querySelectorAll('.close-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const modal = e.target.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
            }
        });
    });
    
    // 현재 날짜 표시
    updateCurrentDate();
}

// 로그인 처리
async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('rememberMe').checked;
    
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            
            // 토큰 저장
            if (rememberMe) {
                localStorage.setItem('authToken', authToken);
                localStorage.setItem('currentUser', JSON.stringify(currentUser));
            }
            
            showMainApp();
        } else {
            alert(data.message || '로그인에 실패했습니다.');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('로그인 중 오류가 발생했습니다.');
    }
}

// 로그아웃 처리
function handleLogout() {
    authToken = null;
    currentUser = null;
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
    
    document.getElementById('app').style.display = 'none';
    showLoginModal();
}

// 로그인 모달 표시
function showLoginModal() {
    document.getElementById('loginModal').style.display = 'flex';
}

// 메인 앱 표시
function showMainApp() {
    document.getElementById('loginModal').style.display = 'none';
    document.getElementById('app').style.display = 'flex';
    
    // 사용자 정보 표시
    document.getElementById('currentUser').textContent = currentUser.username;
    
    // 대시보드 로드
    loadDashboard();
}

// 네비게이션 처리
function handleNavigation(e) {
    e.preventDefault();
    
    const tabName = e.currentTarget.dataset.tab;
    
    // 활성 네비게이션 업데이트
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    e.currentTarget.classList.add('active');
    
    // 탭 컨텐츠 표시
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.getElementById(tabName + 'Tab').classList.add('active');
    
    // 탭별 데이터 로드
    switch(tabName) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'bookings':
            loadBookings();
            break;
        case 'customers':
            loadCustomers();
            break;
        case 'services':
            loadServices();
            break;
        case 'payments':
            loadPayments();
            break;
        case 'revenue':
            loadRevenue();
            break;
        case 'sms':
            loadSMS();
            break;
    }
}

// 대시보드 로드
async function loadDashboard() {
    try {
        // 달력 초기화
        if (!calendar) {
            initializeCalendar();
        }
        
        // 오늘 예약 로드
        await loadDailyBookings(selectedDate);
        
        // 메모 로드
        await loadDailyMemo(selectedDate);
        
    } catch (error) {
        console.error('Dashboard load error:', error);
    }
}

// 달력 초기화
function initializeCalendar() {
    const calendarEl = document.getElementById('calendar');
    
    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'ko',
        headerToolbar: false,
        height: 'auto',
        events: loadCalendarEvents,
        dateClick: function(info) {
            selectedDate = info.dateStr;
            loadDailyBookings(selectedDate);
            loadDailyMemo(selectedDate);
            updateSelectedDateDisplay();
        },
        eventClick: function(info) {
            // 예약 상세 정보 표시
            alert(`예약 정보: ${info.event.title}`);
        }
    });
    
    calendar.render();
    updateCalendarHeader();
}

// 달력 이벤트 로드
async function loadCalendarEvents(fetchInfo, successCallback, failureCallback) {
    try {
        const year = fetchInfo.start.getFullYear();
        const month = fetchInfo.start.getMonth() + 1;
        
        const response = await fetch(`/api/bookings/calendar?year=${year}&month=${month}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            const events = [];
            data.calendar_data.forEach(dayData => {
                dayData.bookings.forEach(booking => {
                    events.push({
                        id: booking.id,
                        title: `${booking.customer_name} - ${booking.service_name}`,
                        start: `${booking.booking_date}T${booking.booking_time}`,
                        backgroundColor: getStatusColor(booking.status),
                        borderColor: getStatusColor(booking.status),
                        extendedProps: booking
                    });
                });
            });
            successCallback(events);
        } else {
            failureCallback(data.message);
        }
    } catch (error) {
        console.error('Calendar events load error:', error);
        failureCallback(error.message);
    }
}

// 상태별 색상 반환
function getStatusColor(status) {
    const colors = {
        'confirmed': '#3B82F6',
        'completed': '#10B981',
        'cancelled': '#EF4444',
        'no_show': '#F59E0B'
    };
    return colors[status] || '#6B7280';
}

// 일별 예약 로드
async function loadDailyBookings(date) {
    try {
        const response = await fetch(`/api/bookings?date=${date}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            displayDailyBookings(data.bookings);
        }
    } catch (error) {
        console.error('Daily bookings load error:', error);
    }
}

// 일별 예약 표시
function displayDailyBookings(bookings) {
    const container = document.getElementById('dailyBookings');
    
    if (bookings.length === 0) {
        container.innerHTML = '<p style="color: #666; text-align: center;">예약이 없습니다.</p>';
        return;
    }
    
    const html = bookings.map(booking => `
        <div class="booking-item">
            <div class="booking-time">${booking.booking_time}</div>
            <div class="booking-customer">${booking.customer_name} - ${booking.pet_name}</div>
            <div class="booking-service">${booking.service_name}</div>
            <div class="status-badge status-${booking.status}">${getStatusText(booking.status)}</div>
        </div>
    `).join('');
    
    container.innerHTML = html;
}

// 상태 텍스트 반환
function getStatusText(status) {
    const texts = {
        'confirmed': '확정',
        'completed': '완료',
        'cancelled': '취소',
        'no_show': '노쇼'
    };
    return texts[status] || status;
}

// 일별 메모 로드
async function loadDailyMemo(date) {
    try {
        const response = await fetch(`/api/memos?date=${date}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            document.getElementById('memoContent').value = data.memo ? data.memo.content : '';
        }
    } catch (error) {
        console.error('Daily memo load error:', error);
    }
}

// 메모 저장
async function saveDailyMemo() {
    try {
        const content = document.getElementById('memoContent').value;
        
        const response = await fetch('/api/memos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                date: selectedDate,
                content: content
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            alert('메모가 저장되었습니다.');
        } else {
            alert(data.message || '메모 저장에 실패했습니다.');
        }
    } catch (error) {
        console.error('Save memo error:', error);
        alert('메모 저장 중 오류가 발생했습니다.');
    }
}

// 달력 네비게이션
function navigateCalendar(direction) {
    if (calendar) {
        if (direction > 0) {
            calendar.next();
        } else {
            calendar.prev();
        }
        updateCalendarHeader();
    }
}

// 오늘로 이동
function goToToday() {
    if (calendar) {
        calendar.today();
        selectedDate = new Date().toISOString().split('T')[0];
        loadDailyBookings(selectedDate);
        loadDailyMemo(selectedDate);
        updateCalendarHeader();
        updateSelectedDateDisplay();
    }
}

// 달력 헤더 업데이트
function updateCalendarHeader() {
    if (calendar) {
        const currentDate = calendar.getDate();
        const monthNames = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'];
        document.getElementById('currentMonth').textContent = 
            `${currentDate.getFullYear()}년 ${monthNames[currentDate.getMonth()]}`;
    }
}

// 선택된 날짜 표시 업데이트
function updateSelectedDateDisplay() {
    const date = new Date(selectedDate);
    const options = { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' };
    document.getElementById('selectedDate').textContent = date.toLocaleDateString('ko-KR', options);
}

// 현재 날짜 업데이트
function updateCurrentDate() {
    const now = new Date();
    const options = { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' };
    document.getElementById('currentDate').textContent = now.toLocaleDateString('ko-KR', options);
}

// 예약 폼 데이터 로드
async function loadBookingFormData() {
    try {
        // 고객 목록 로드
        const customersResponse = await fetch('/api/customers', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (customersResponse.ok) {
            const customersData = await customersResponse.json();
            const customerSelect = document.getElementById('customerSelect');
            customerSelect.innerHTML = '<option value="">고객을 선택하세요</option>';
            
            customersData.customers.forEach(customer => {
                const option = document.createElement('option');
                option.value = customer.id;
                option.textContent = `${customer.name} (${customer.phone})`;
                customerSelect.appendChild(option);
            });
        }
        
        // 서비스 목록 로드
        const servicesResponse = await fetch('/api/services', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (servicesResponse.ok) {
            const servicesData = await servicesResponse.json();
            const serviceSelect = document.getElementById('serviceSelect');
            serviceSelect.innerHTML = '<option value="">서비스를 선택하세요</option>';
            
            servicesData.services.forEach(service => {
                const option = document.createElement('option');
                option.value = service.id;
                option.textContent = `${service.name} (${service.price.toLocaleString()}원)`;
                serviceSelect.appendChild(option);
            });
        }
        
        // 직원 목록 로드
        const staffResponse = await fetch('/api/users', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (staffResponse.ok) {
            const staffData = await staffResponse.json();
            const staffSelect = document.getElementById('staffSelect');
            staffSelect.innerHTML = '<option value="">담당자를 선택하세요</option>';
            
            staffData.users.forEach(staff => {
                const option = document.createElement('option');
                option.value = staff.id;
                option.textContent = staff.username;
                staffSelect.appendChild(option);
            });
        }
        
        // 기본 날짜 설정
        document.getElementById('bookingDate').value = selectedDate;
        
    } catch (error) {
        console.error('Load booking form data error:', error);
    }
}

// 고객 선택 시 반려동물 로드
async function loadPetsForCustomer() {
    const customerId = document.getElementById('customerSelect').value;
    const petSelect = document.getElementById('petSelect');
    
    petSelect.innerHTML = '<option value="">반려동물을 선택하세요</option>';
    
    if (!customerId) return;
    
    try {
        const response = await fetch(`/api/pets?customer_id=${customerId}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            
            data.pets.forEach(pet => {
                const option = document.createElement('option');
                option.value = pet.id;
                option.textContent = `${pet.name} (${pet.species})`;
                petSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Load pets error:', error);
    }
}

// 예약 생성 처리
async function handleBookingSubmit(e) {
    e.preventDefault();
    
    const formData = {
        customer_id: parseInt(document.getElementById('customerSelect').value),
        pet_id: parseInt(document.getElementById('petSelect').value),
        service_id: parseInt(document.getElementById('serviceSelect').value),
        staff_id: document.getElementById('staffSelect').value ? parseInt(document.getElementById('staffSelect').value) : null,
        booking_date: document.getElementById('bookingDate').value,
        booking_time: document.getElementById('bookingTime').value,
        special_requests: document.getElementById('specialRequests').value,
        notes: document.getElementById('bookingNotes').value
    };
    
    try {
        const response = await fetch('/api/bookings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            alert('예약이 생성되었습니다.');
            closeModal('bookingModal');
            
            // 달력 새로고침
            if (calendar) {
                calendar.refetchEvents();
            }
            
            // 일별 예약 새로고침
            loadDailyBookings(selectedDate);
            
            // 폼 초기화
            document.getElementById('bookingForm').reset();
        } else {
            alert(data.message || '예약 생성에 실패했습니다.');
        }
    } catch (error) {
        console.error('Create booking error:', error);
        alert('예약 생성 중 오류가 발생했습니다.');
    }
}

// 모달 열기
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

// 모달 닫기
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// 고객 목록 로드
async function loadCustomers() {
    try {
        const response = await fetch('/api/customers', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayCustomersTable(data.customers);
            updateCustomerStats(data);
        }
    } catch (error) {
        console.error('Load customers error:', error);
    }
}

// 고객 테이블 표시
function displayCustomersTable(customers) {
    const container = document.getElementById('customersTable');
    
    if (customers.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 20px;">등록된 고객이 없습니다.</p>';
        return;
    }
    
    const html = `
        <table class="table">
            <thead>
                <tr>
                    <th>이름</th>
                    <th>전화번호</th>
                    <th>등급</th>
                    <th>반려동물</th>
                    <th>완료</th>
                    <th>취소</th>
                    <th>노쇼</th>
                    <th>가입일</th>
                </tr>
            </thead>
            <tbody>
                ${customers.map(customer => `
                    <tr>
                        <td>${customer.name}</td>
                        <td>${customer.phone}</td>
                        <td>${customer.grade_name || '일반'}</td>
                        <td>${customer.pets_count}마리</td>
                        <td>${customer.booking_stats ? customer.booking_stats.completed : 0}회</td>
                        <td>${customer.booking_stats ? customer.booking_stats.cancelled : 0}회</td>
                        <td>${customer.booking_stats ? customer.booking_stats.no_show : 0}회</td>
                        <td>${new Date(customer.created_at).toLocaleDateString('ko-KR')}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    container.innerHTML = html;
}

// 고객 통계 업데이트
function updateCustomerStats(data) {
    document.getElementById('totalCustomers').textContent = data.total;
    // 추가 통계는 백엔드에서 계산하여 제공
}

// 예약 목록 로드
async function loadBookings() {
    // 예약 목록 로드 로직
    console.log('Loading bookings...');
}

// 서비스 목록 로드
async function loadServices() {
    // 서비스 목록 로드 로직
    console.log('Loading services...');
}

// 결제 목록 로드
async function loadPayments() {
    // 결제 목록 로드 로직
    console.log('Loading payments...');
}

// 매출 분석 로드
async function loadRevenue() {
    // 매출 분석 로드 로직
    console.log('Loading revenue...');
}

// SMS 발송 로드
async function loadSMS() {
    // SMS 발송 로드 로직
    console.log('Loading SMS...');
}

// API 요청 헬퍼 함수
async function apiRequest(url, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
        }
    };
    
    const mergedOptions = {
        ...defaultOptions,
        ...options,
        headers: {
            ...defaultOptions.headers,
            ...options.headers
        }
    };
    
    try {
        const response = await fetch(url, mergedOptions);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || 'API request failed');
        }
        
        return data;
    } catch (error) {
        console.error('API request error:', error);
        throw error;
    }
}


// 고객 테이블 표시 개선
function displayCustomersTable(customers) {
    const container = document.getElementById('customersTable');
    
    if (customers.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 20px;">등록된 고객이 없습니다.</p>';
        return;
    }
    
    const html = `
        <table class="table">
            <thead>
                <tr>
                    <th>이름</th>
                    <th>전화번호</th>
                    <th>등급</th>
                    <th>반려동물</th>
                    <th>완료</th>
                    <th>취소</th>
                    <th>노쇼</th>
                    <th>이용권</th>
                    <th>가입일</th>
                    <th>관리</th>
                </tr>
            </thead>
            <tbody>
                ${customers.map(customer => `
                    <tr>
                        <td>
                            <div class="customer-info">
                                <strong>${customer.name}</strong>
                                ${customer.pets_count > 1 ? `<span class="pet-count">+${customer.pets_count - 1}</span>` : ''}
                            </div>
                        </td>
                        <td>${customer.phone}</td>
                        <td>
                            <span class="grade-badge" style="background-color: ${getGradeColor(customer.grade_name)}">
                                ${customer.grade_name || '일반'}
                            </span>
                        </td>
                        <td>${customer.pets_count}마리</td>
                        <td><span class="stat-number">${customer.booking_stats ? customer.booking_stats.completed : 0}</span>회</td>
                        <td><span class="stat-number">${customer.booking_stats ? customer.booking_stats.cancelled : 0}</span>회</td>
                        <td><span class="stat-number">${customer.booking_stats ? customer.booking_stats.no_show : 0}</span>회</td>
                        <td>
                            ${customer.memberships && customer.memberships.length > 0 ? 
                                `<span class="membership-count">${customer.memberships.length}개</span>` : 
                                '<span class="no-membership">없음</span>'
                            }
                        </td>
                        <td>${new Date(customer.created_at).toLocaleDateString('ko-KR')}</td>
                        <td>
                            <button class="btn btn-sm btn-outline" onclick="editCustomer(${customer.id})">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-outline" onclick="viewCustomerDetail(${customer.id})">
                                <i class="fas fa-eye"></i>
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    container.innerHTML = html;
}

// 등급별 색상 반환
function getGradeColor(gradeName) {
    const colors = {
        '브론즈': '#CD7F32',
        '실버': '#C0C0C0',
        '골드': '#FFD700',
        '플래티넘': '#E5E4E2'
    };
    return colors[gradeName] || '#6B7280';
}

// 고객 상세 정보 보기
function viewCustomerDetail(customerId) {
    // 고객 상세 정보 모달 구현
    console.log('View customer detail:', customerId);
}

// 고객 편집
function editCustomer(customerId) {
    // 고객 편집 모달 구현
    console.log('Edit customer:', customerId);
}

// 결제 목록 로드 구현
async function loadPayments() {
    try {
        const response = await fetch('/api/payments', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayPaymentsTable(data.payments);
            
            // 결제 통계 로드
            loadPaymentStats();
        }
    } catch (error) {
        console.error('Load payments error:', error);
    }
}

// 결제 테이블 표시
function displayPaymentsTable(payments) {
    const container = document.getElementById('paymentsTable');
    
    if (payments.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 20px;">결제 내역이 없습니다.</p>';
        return;
    }
    
    const html = `
        <table class="table">
            <thead>
                <tr>
                    <th>결제일</th>
                    <th>고객명</th>
                    <th>서비스</th>
                    <th>결제방법</th>
                    <th>금액</th>
                    <th>환불금액</th>
                    <th>잔여금액</th>
                    <th>상태</th>
                    <th>관리</th>
                </tr>
            </thead>
            <tbody>
                ${payments.map(payment => `
                    <tr>
                        <td>${new Date(payment.payment_date).toLocaleDateString('ko-KR')}</td>
                        <td>${payment.booking?.customer_name || '-'}</td>
                        <td>${payment.booking?.service_name || '-'}</td>
                        <td>
                            <span class="payment-method-badge method-${payment.method}">
                                ${getPaymentMethodText(payment.method)}
                            </span>
                        </td>
                        <td>${payment.amount.toLocaleString()}원</td>
                        <td>${payment.refund_amount.toLocaleString()}원</td>
                        <td>${(payment.remaining_amount || payment.amount - payment.refund_amount).toLocaleString()}원</td>
                        <td>
                            <span class="status-badge status-${payment.status}">
                                ${getPaymentStatusText(payment.status)}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-outline" onclick="processRefund(${payment.id})">
                                환불
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    container.innerHTML = html;
}

// 결제 방법 텍스트 반환
function getPaymentMethodText(method) {
    const methods = {
        'cash': '현금',
        'card': '카드',
        'transfer': '계좌이체',
        'online': '온라인'
    };
    return methods[method] || method;
}

// 결제 상태 텍스트 반환
function getPaymentStatusText(status) {
    const statuses = {
        'pending': '대기',
        'completed': '완료',
        'failed': '실패',
        'refunded': '환불',
        'partial_refund': '부분환불'
    };
    return statuses[status] || status;
}

// 결제 통계 로드
async function loadPaymentStats() {
    try {
        const response = await fetch('/api/payments/stats', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            updatePaymentStats(data);
        }
    } catch (error) {
        console.error('Load payment stats error:', error);
    }
}

// 결제 통계 업데이트
function updatePaymentStats(stats) {
    document.getElementById('todayPayments').textContent = `${stats.today.amount.toLocaleString()}원`;
    document.getElementById('monthPayments').textContent = `${stats.month.amount.toLocaleString()}원`;
    document.getElementById('pendingPayments').textContent = `${stats.pending.amount.toLocaleString()}원`;
}

// 환불 처리
function processRefund(paymentId) {
    const refundAmount = prompt('환불 금액을 입력하세요:');
    const refundReason = prompt('환불 사유를 입력하세요:');
    
    if (refundAmount && refundReason) {
        fetch(`/api/payments/${paymentId}/refund`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                refund_amount: parseInt(refundAmount),
                refund_reason: refundReason
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                alert(data.message);
                loadPayments(); // 결제 목록 새로고침
            }
        })
        .catch(error => {
            console.error('Refund error:', error);
            alert('환불 처리 중 오류가 발생했습니다.');
        });
    }
}

// 매출 분석 로드 구현
async function loadRevenue() {
    try {
        // 결제 방법별 통계 로드
        const methodResponse = await fetch('/api/analytics/payment-methods', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (methodResponse.ok) {
            const methodData = await methodResponse.json();
            createPaymentMethodChart(methodData.method_data);
        }
        
        // 매출 추이 로드
        const revenueResponse = await fetch('/api/analytics/revenue?period=daily', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (revenueResponse.ok) {
            const revenueData = await revenueResponse.json();
            createRevenueChart(revenueData.revenue_data);
        }
        
        // 매출 테이블 로드
        loadRevenueTable();
        
    } catch (error) {
        console.error('Load revenue error:', error);
    }
}

// 결제 방법별 차트 생성
function createPaymentMethodChart(data) {
    const ctx = document.getElementById('paymentMethodChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.map(item => getPaymentMethodText(item.method)),
            datasets: [{
                data: data.map(item => item.percentage),
                backgroundColor: [
                    '#8B5CF6',
                    '#06B6D4',
                    '#10B981',
                    '#F59E0B',
                    '#EF4444'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// 매출 추이 차트 생성
function createRevenueChart(data) {
    const ctx = document.getElementById('revenueChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(item => item.period),
            datasets: [{
                label: '매출',
                data: data.map(item => item.amount),
                borderColor: '#8B5CF6',
                backgroundColor: 'rgba(139, 92, 246, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + '원';
                        }
                    }
                }
            }
        }
    });
}

// 매출 테이블 로드
async function loadRevenueTable() {
    try {
        const response = await fetch('/api/payments', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayRevenueTable(data.payments);
        }
    } catch (error) {
        console.error('Load revenue table error:', error);
    }
}

// 매출 테이블 표시
function displayRevenueTable(payments) {
    const container = document.getElementById('revenueTable');
    
    if (payments.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 20px;">매출 데이터가 없습니다.</p>';
        return;
    }
    
    const html = `
        <table class="table">
            <thead>
                <tr>
                    <th>일자</th>
                    <th>고객명</th>
                    <th>서비스</th>
                    <th>결제방법</th>
                    <th>금액</th>
                    <th>상태</th>
                </tr>
            </thead>
            <tbody>
                ${payments.map(payment => `
                    <tr>
                        <td>${new Date(payment.payment_date).toLocaleDateString('ko-KR')}</td>
                        <td>${payment.booking?.customer_name || '-'}</td>
                        <td>${payment.booking?.service_name || '-'}</td>
                        <td>${getPaymentMethodText(payment.method)}</td>
                        <td>${payment.amount.toLocaleString()}원</td>
                        <td>
                            <span class="status-badge status-${payment.status}">
                                ${getPaymentStatusText(payment.status)}
                            </span>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    container.innerHTML = html;
}

// 서비스 목록 로드 구현
async function loadServices() {
    try {
        const response = await fetch('/api/services', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayServicesTable(data.services);
        }
    } catch (error) {
        console.error('Load services error:', error);
    }
}

// 서비스 테이블 표시
function displayServicesTable(services) {
    const container = document.getElementById('servicesTable');
    
    if (services.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 20px;">등록된 서비스가 없습니다.</p>';
        return;
    }
    
    const html = `
        <table class="table">
            <thead>
                <tr>
                    <th>서비스명</th>
                    <th>카테고리</th>
                    <th>가격</th>
                    <th>소요시간</th>
                    <th>설명</th>
                    <th>상태</th>
                    <th>관리</th>
                </tr>
            </thead>
            <tbody>
                ${services.map(service => `
                    <tr>
                        <td><strong>${service.name}</strong></td>
                        <td>
                            <span class="category-badge">${service.category}</span>
                        </td>
                        <td>${service.price.toLocaleString()}원</td>
                        <td>${service.duration}분</td>
                        <td>${service.description || '-'}</td>
                        <td>
                            <span class="status-badge ${service.is_active ? 'status-active' : 'status-inactive'}">
                                ${service.is_active ? '활성' : '비활성'}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-outline" onclick="editService(${service.id})">
                                <i class="fas fa-edit"></i>
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    container.innerHTML = html;
}

// 서비스 편집
function editService(serviceId) {
    console.log('Edit service:', serviceId);
}

// SMS 발송 로드 구현
async function loadSMS() {
    try {
        // 고객 등급 목록 로드
        const gradesResponse = await fetch('/api/customer-grades', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (gradesResponse.ok) {
            const gradesData = await gradesResponse.json();
            populateGradeFilter(gradesData.grades);
        }
        
        // SMS 메시지 길이 카운터 설정
        const messageTextarea = document.getElementById('smsMessage');
        const lengthCounter = document.getElementById('messageLength');
        
        if (messageTextarea && lengthCounter) {
            messageTextarea.addEventListener('input', function() {
                const length = this.value.length;
                lengthCounter.textContent = `${length}/90`;
                
                if (length > 90) {
                    lengthCounter.style.color = '#EF4444';
                } else {
                    lengthCounter.style.color = '#6B7280';
                }
            });
        }
        
    } catch (error) {
        console.error('Load SMS error:', error);
    }
}

// 등급 필터 채우기
function populateGradeFilter(grades) {
    const gradeFilter = document.getElementById('gradeFilter');
    if (gradeFilter) {
        gradeFilter.innerHTML = '<option value="">전체 등급</option>';
        grades.forEach(grade => {
            const option = document.createElement('option');
            option.value = grade.id;
            option.textContent = grade.name;
            gradeFilter.appendChild(option);
        });
    }
}

// 예약 목록 로드 구현
async function loadBookings() {
    try {
        const response = await fetch('/api/bookings', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayBookingsTable(data.bookings);
        }
    } catch (error) {
        console.error('Load bookings error:', error);
    }
}

// 예약 테이블 표시
function displayBookingsTable(bookings) {
    const container = document.getElementById('bookingsTable');
    
    if (bookings.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 20px;">예약이 없습니다.</p>';
        return;
    }
    
    const html = `
        <table class="table">
            <thead>
                <tr>
                    <th>예약일</th>
                    <th>시간</th>
                    <th>고객명</th>
                    <th>반려동물</th>
                    <th>서비스</th>
                    <th>담당자</th>
                    <th>가격</th>
                    <th>상태</th>
                    <th>관리</th>
                </tr>
            </thead>
            <tbody>
                ${bookings.map(booking => `
                    <tr>
                        <td>${new Date(booking.booking_date).toLocaleDateString('ko-KR')}</td>
                        <td>${booking.booking_time} - ${booking.end_time}</td>
                        <td>${booking.customer_name}</td>
                        <td>${booking.pet_name}</td>
                        <td>${booking.service_name}</td>
                        <td>${booking.staff_name || '-'}</td>
                        <td>${booking.final_price.toLocaleString()}원</td>
                        <td>
                            <span class="status-badge status-${booking.status}">
                                ${getStatusText(booking.status)}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-outline" onclick="editBooking(${booking.id})">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-outline" onclick="cancelBooking(${booking.id})">
                                <i class="fas fa-times"></i>
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    container.innerHTML = html;
}

// 예약 편집
function editBooking(bookingId) {
    console.log('Edit booking:', bookingId);
}

// 예약 취소
function cancelBooking(bookingId) {
    if (confirm('정말로 이 예약을 취소하시겠습니까?')) {
        fetch(`/api/bookings/${bookingId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                status: 'cancelled'
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                alert('예약이 취소되었습니다.');
                loadBookings(); // 예약 목록 새로고침
                
                // 달력도 새로고침
                if (calendar) {
                    calendar.refetchEvents();
                }
            }
        })
        .catch(error => {
            console.error('Cancel booking error:', error);
            alert('예약 취소 중 오류가 발생했습니다.');
        });
    }
}

