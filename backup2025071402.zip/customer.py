from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Customer(db.Model):
    __tablename__ = 'customers'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120))
    address = db.Column(db.Text)
    grade_id = db.Column(db.Integer, db.ForeignKey('customer_grades.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 관계 설정
    pets = db.relationship('Pet', backref='owner', lazy=True, cascade='all, delete-orphan')
    bookings = db.relationship('Booking', backref='customer', lazy=True)
    memberships = db.relationship('Membership', backref='customer', lazy=True)
    grade = db.relationship('CustomerGrade', backref='customers')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'phone': self.phone,
            'email': self.email,
            'address': self.address,
            'grade_id': self.grade_id,
            'grade_name': self.grade.name if self.grade else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'pets_count': len(self.pets),
            'bookings_count': len(self.bookings)
        }

class CustomerGrade(db.Model):
    __tablename__ = 'customer_grades'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    min_visits = db.Column(db.Integer, default=0)
    max_visits = db.Column(db.Integer)
    benefits = db.Column(db.Text)
    color = db.Column(db.String(7), default='#6B7280')  # 색상 코드
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'min_visits': self.min_visits,
            'max_visits': self.max_visits,
            'benefits': self.benefits,
            'color': self.color,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Pet(db.Model):
    __tablename__ = 'pets'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    species = db.Column(db.String(50), nullable=False)  # 강아지, 고양이
    breed = db.Column(db.String(100))
    age = db.Column(db.Integer)
    weight = db.Column(db.Float)
    gender = db.Column(db.String(10))
    notes = db.Column(db.Text)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 관계 설정
    bookings = db.relationship('Booking', backref='pet', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'species': self.species,
            'breed': self.breed,
            'age': self.age,
            'weight': self.weight,
            'gender': self.gender,
            'notes': self.notes,
            'customer_id': self.customer_id,
            'customer_name': self.owner.name if self.owner else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Membership(db.Model):
    __tablename__ = 'memberships'
    
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    type = db.Column(db.String(20), nullable=False)  # 금액권, 횟수권, 시간권
    name = db.Column(db.String(100), nullable=False)
    total_amount = db.Column(db.Integer, default=0)
    remaining_amount = db.Column(db.Integer, default=0)
    purchase_date = db.Column(db.DateTime, default=datetime.utcnow)
    expiry_date = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'customer_id': self.customer_id,
            'type': self.type,
            'name': self.name,
            'total_amount': self.total_amount,
            'remaining_amount': self.remaining_amount,
            'purchase_date': self.purchase_date.isoformat() if self.purchase_date else None,
            'expiry_date': self.expiry_date.isoformat() if self.expiry_date else None,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

