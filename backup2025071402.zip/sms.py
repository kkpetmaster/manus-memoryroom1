from flask import Blueprint, request, jsonify
from src.models.customer import Customer, CustomerGrade, db
from src.models.booking import Booking
from src.routes.auth import token_required
from datetime import datetime, date, timedelta
from sqlalchemy import func, and_, or_

sms_bp = Blueprint('sms', __name__)

@sms_bp.route('/sms/targets', methods=['GET'])
@token_required
def get_sms_targets(current_user):
    """SMS 발송 대상 고객 조회"""
    try:
        # 쿼리 파라미터
        grade_id = request.args.get('grade_id', type=int)
        visit_range = request.args.get('visit_range')
        last_visit_days = request.args.get('last_visit_days', type=int)
        
        # 기본 쿼리
        query = Customer.query
        
        # 등급 필터
        if grade_id:
            query = query.filter(Customer.grade_id == grade_id)
        
        # 방문 횟수 필터
        if visit_range:
            if visit_range == '1-5':
                query = query.filter(Customer.visit_count.between(1, 5))
            elif visit_range == '6-15':
                query = query.filter(Customer.visit_count.between(6, 15))
            elif visit_range == '16+':
                query = query.filter(Customer.visit_count >= 16)
        
        # 마지막 방문일 필터
        if last_visit_days:
            cutoff_date = date.today() - timedelta(days=last_visit_days)
            query = query.filter(
                or_(
                    Customer.last_visit_date < cutoff_date,
                    Customer.last_visit_date.is_(None)
                )
            )
        
        customers = query.all()
        
        return jsonify({
            'customers': [
                {
                    'id': customer.id,
                    'name': customer.name,
                    'phone': customer.phone,
                    'grade_name': customer.grade.name if customer.grade else '일반',
                    'visit_count': customer.visit_count,
                    'last_visit_date': customer.last_visit_date.isoformat() if customer.last_visit_date else None
                } for customer in customers
            ],
            'total_count': len(customers)
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get SMS targets: {str(e)}'}), 500

@sms_bp.route('/sms/send', methods=['POST'])
@token_required
def send_sms(current_user):
    """SMS 발송"""
    try:
        data = request.get_json()
        
        # 필수 필드 검증
        required_fields = ['message', 'target_customers']
        for field in required_fields:
            if field not in data:
                return jsonify({'message': f'{field} is required'}), 400
        
        message = data['message']
        target_customers = data['target_customers']  # 고객 ID 리스트
        
        # 메시지 길이 검증
        if len(message) > 90:
            return jsonify({'message': 'Message too long (max 90 characters)'}), 400
        
        # 발송 대상 고객 조회
        customers = Customer.query.filter(Customer.id.in_(target_customers)).all()
        
        if not customers:
            return jsonify({'message': 'No valid customers found'}), 400
        
        # SMS 발송 로그 생성 (실제 SMS 발송은 외부 API 연동 필요)
        sms_log = {
            'message': message,
            'sent_to': [
                {
                    'customer_id': customer.id,
                    'customer_name': customer.name,
                    'phone': customer.phone
                } for customer in customers
            ],
            'sent_by': current_user.username,
            'sent_at': datetime.utcnow().isoformat(),
            'total_count': len(customers)
        }
        
        # 실제 환경에서는 여기서 SMS API 호출
        # 예: send_sms_via_api(customers, message)
        
        return jsonify({
            'message': f'SMS sent to {len(customers)} customers',
            'sms_log': sms_log
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to send SMS: {str(e)}'}), 500

@sms_bp.route('/sms/templates', methods=['GET'])
@token_required
def get_sms_templates(current_user):
    """SMS 템플릿 조회"""
    try:
        # 미리 정의된 SMS 템플릿들
        templates = [
            {
                'id': 1,
                'name': '예약 확인',
                'message': '[{shop_name}] {customer_name}님의 {date} {time} 예약이 확정되었습니다. 감사합니다.'
            },
            {
                'id': 2,
                'name': '예약 리마인더',
                'message': '[{shop_name}] {customer_name}님, 내일 {time} 예약을 잊지 마세요!'
            },
            {
                'id': 3,
                'name': '생일 축하',
                'message': '[{shop_name}] {pet_name}의 생일을 축하합니다! 특별 할인 혜택을 확인해보세요.'
            },
            {
                'id': 4,
                'name': '재방문 유도',
                'message': '[{shop_name}] {customer_name}님, 오랜만이에요! 새로운 서비스를 확인해보세요.'
            },
            {
                'id': 5,
                'name': '이벤트 안내',
                'message': '[{shop_name}] 특별 이벤트! 이번 주 예약 시 20% 할인 혜택을 드립니다.'
            }
        ]
        
        return jsonify({'templates': templates}), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get SMS templates: {str(e)}'}), 500

@sms_bp.route('/sms/history', methods=['GET'])
@token_required
def get_sms_history(current_user):
    """SMS 발송 이력 조회"""
    try:
        # 실제 환경에서는 SMS 발송 이력을 데이터베이스에서 조회
        # 여기서는 샘플 데이터 반환
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # 샘플 SMS 발송 이력
        sample_history = [
            {
                'id': 1,
                'message': '예약 확인 메시지입니다.',
                'sent_count': 15,
                'sent_by': 'admin',
                'sent_at': '2025-07-14T10:30:00',
                'status': 'completed'
            },
            {
                'id': 2,
                'message': '이벤트 안내 메시지입니다.',
                'sent_count': 32,
                'sent_by': 'manager',
                'sent_at': '2025-07-13T14:15:00',
                'status': 'completed'
            }
        ]
        
        return jsonify({
            'history': sample_history,
            'total': len(sample_history),
            'page': page,
            'per_page': per_page
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get SMS history: {str(e)}'}), 500

@sms_bp.route('/sms/stats', methods=['GET'])
@token_required
def get_sms_stats(current_user):
    """SMS 발송 통계"""
    try:
        # 실제 환경에서는 SMS 발송 통계를 데이터베이스에서 조회
        # 여기서는 샘플 데이터 반환
        
        today = date.today()
        
        stats = {
            'today': {
                'sent_count': 25,
                'success_count': 24,
                'fail_count': 1
            },
            'this_month': {
                'sent_count': 450,
                'success_count': 442,
                'fail_count': 8
            },
            'total_customers': Customer.query.count(),
            'active_customers': Customer.query.filter(
                Customer.last_visit_date >= today - timedelta(days=30)
            ).count()
        }
        
        return jsonify(stats), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get SMS stats: {str(e)}'}), 500

@sms_bp.route('/customer-grades', methods=['GET'])
@token_required
def get_customer_grades(current_user):
    """고객 등급 목록 조회"""
    try:
        grades = CustomerGrade.query.all()
        
        return jsonify({
            'grades': [
                {
                    'id': grade.id,
                    'name': grade.name,
                    'min_visits': grade.min_visits,
                    'discount_rate': grade.discount_rate
                } for grade in grades
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get customer grades: {str(e)}'}), 500

