// Chart.js 설정 및 차트 생성 함수

// 전역 차트 변수
let paymentMethodChart = null;
let revenueChart = null;
let customerChart = null;
let serviceChart = null;

// Chart.js 기본 설정
Chart.defaults.font.family = "'Inter', sans-serif";
Chart.defaults.font.size = 12;
Chart.defaults.color = '#6B7280';

// 결제 방법별 차트 생성
function createPaymentMethodChart(data) {
    const ctx = document.getElementById('paymentMethodChart');
    if (!ctx) return;
    
    // 기존 차트 제거
    if (paymentMethodChart) {
        paymentMethodChart.destroy();
    }
    
    const colors = [
        '#8B5CF6', // 보라색
        '#06B6D4', // 청록색
        '#10B981', // 초록색
        '#F59E0B', // 주황색
        '#EF4444'  // 빨간색
    ];
    
    paymentMethodChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.map(item => getPaymentMethodText(item.method)),
            datasets: [{
                data: data.map(item => item.amount),
                backgroundColor: colors.slice(0, data.length),
                borderWidth: 0,
                hoverBorderWidth: 2,
                hoverBorderColor: '#FFFFFF'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value.toLocaleString()}원 (${percentage}%)`;
                        }
                    }
                }
            },
            cutout: '60%'
        }
    });
}

// 매출 추이 차트 생성
function createRevenueChart(data) {
    const ctx = document.getElementById('revenueChart');
    if (!ctx) return;
    
    // 기존 차트 제거
    if (revenueChart) {
        revenueChart.destroy();
    }
    
    revenueChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(item => formatPeriodLabel(item.period)),
            datasets: [{
                label: '매출',
                data: data.map(item => item.amount),
                borderColor: '#8B5CF6',
                backgroundColor: 'rgba(139, 92, 246, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#8B5CF6',
                pointBorderColor: '#FFFFFF',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                intersect: false,
                mode: 'index'
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#FFFFFF',
                    bodyColor: '#FFFFFF',
                    borderColor: '#8B5CF6',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return `매출: ${context.parsed.y.toLocaleString()}원`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    border: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    border: {
                        display: false
                    },
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + '원';
                        }
                    }
                }
            }
        }
    });
}

// 고객 등급별 차트 생성
function createCustomerChart(data) {
    const ctx = document.getElementById('customerChart');
    if (!ctx) return;
    
    // 기존 차트 제거
    if (customerChart) {
        customerChart.destroy();
    }
    
    const gradeColors = {
        '브론즈': '#CD7F32',
        '실버': '#C0C0C0',
        '골드': '#FFD700',
        '플래티넘': '#E5E4E2'
    };
    
    customerChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(item => item.grade_name || '일반'),
            datasets: [{
                label: '고객 수',
                data: data.map(item => item.customer_count),
                backgroundColor: data.map(item => gradeColors[item.grade_name] || '#6B7280'),
                borderRadius: 8,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ${context.parsed.y}명`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    border: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    border: {
                        display: false
                    },
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// 서비스별 매출 차트 생성
function createServiceChart(data) {
    const ctx = document.getElementById('serviceChart');
    if (!ctx) return;
    
    // 기존 차트 제거
    if (serviceChart) {
        serviceChart.destroy();
    }
    
    // 상위 5개 서비스만 표시
    const topServices = data.slice(0, 5);
    
    serviceChart = new Chart(ctx, {
        type: 'horizontalBar',
        data: {
            labels: topServices.map(item => item.service_name),
            datasets: [{
                label: '매출',
                data: topServices.map(item => item.total_revenue),
                backgroundColor: '#10B981',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `매출: ${context.parsed.x.toLocaleString()}원`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    border: {
                        display: false
                    },
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + '원';
                        }
                    }
                },
                y: {
                    grid: {
                        display: false
                    },
                    border: {
                        display: false
                    }
                }
            }
        }
    });
}

// 기간 라벨 포맷팅
function formatPeriodLabel(period) {
    if (period.includes('-W')) {
        // 주별 형식: 2025-W01 -> 1주차
        const week = period.split('-W')[1];
        return `${week}주차`;
    } else if (period.match(/^\d{4}-\d{2}$/)) {
        // 월별 형식: 2025-01 -> 1월
        const month = period.split('-')[1];
        return `${parseInt(month)}월`;
    } else {
        // 일별 형식: 2025-01-01 -> 1/1
        const date = new Date(period);
        return `${date.getMonth() + 1}/${date.getDate()}`;
    }
}

// 차트 데이터 새로고침
function refreshCharts() {
    // 결제 방법별 차트 새로고침
    fetch('/api/analytics/payment-methods', {
        headers: {
            'Authorization': `Bearer ${authToken}`
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.method_data && data.method_data.length > 0) {
            createPaymentMethodChart(data.method_data);
        }
    })
    .catch(error => console.error('Payment method chart error:', error));
    
    // 매출 추이 차트 새로고침
    const period = document.getElementById('revenuePeriod')?.value || 'daily';
    fetch(`/api/analytics/revenue?period=${period}`, {
        headers: {
            'Authorization': `Bearer ${authToken}`
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.revenue_data && data.revenue_data.length > 0) {
            createRevenueChart(data.revenue_data);
        }
    })
    .catch(error => console.error('Revenue chart error:', error));
    
    // 고객 분석 차트 새로고침
    fetch('/api/analytics/customers', {
        headers: {
            'Authorization': `Bearer ${authToken}`
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.grade_distribution && data.grade_distribution.length > 0) {
            createCustomerChart(data.grade_distribution);
        }
    })
    .catch(error => console.error('Customer chart error:', error));
    
    // 서비스별 매출 차트 새로고침
    fetch('/api/analytics/services', {
        headers: {
            'Authorization': `Bearer ${authToken}`
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.service_data && data.service_data.length > 0) {
            createServiceChart(data.service_data);
        }
    })
    .catch(error => console.error('Service chart error:', error));
}

// 차트 리사이즈 처리
window.addEventListener('resize', function() {
    if (paymentMethodChart) paymentMethodChart.resize();
    if (revenueChart) revenueChart.resize();
    if (customerChart) customerChart.resize();
    if (serviceChart) serviceChart.resize();
});

// 차트 초기화
function initializeCharts() {
    // Chart.js 로드 확인
    if (typeof Chart === 'undefined') {
        console.error('Chart.js is not loaded');
        return;
    }
    
    // 매출 분석 페이지에서만 차트 초기화
    if (document.getElementById('paymentMethodChart') || 
        document.getElementById('revenueChart')) {
        refreshCharts();
    }
}

// DOM 로드 완료 후 차트 초기화
document.addEventListener('DOMContentLoaded', function() {
    // Chart.js 로드 대기
    setTimeout(initializeCharts, 1000);
});

