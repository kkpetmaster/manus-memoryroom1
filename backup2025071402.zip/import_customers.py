import json
import sqlite3
import os
from datetime import datetime, date

def create_database_connection():
    """데이터베이스 연결 생성"""
    db_path = "/home/ubuntu/pet-shop-system/src/database/app.db"
    return sqlite3.connect(db_path)

def get_or_create_customer_grade(conn, grade_name):
    """고객 등급 조회 또는 생성"""
    cursor = conn.cursor()
    
    # 기존 등급 조회
    cursor.execute("SELECT id FROM customer_grades WHERE name = ?", (grade_name,))
    result = cursor.fetchone()
    
    if result:
        return result[0]
    
    # 새 등급 생성
    grade_mapping = {
        "일반": {"min_visits": 0, "discount_rate": 0.0},
        "브론즈": {"min_visits": 5, "discount_rate": 0.05},
        "실버": {"min_visits": 15, "discount_rate": 0.10},
        "골드": {"min_visits": 30, "discount_rate": 0.15},
        "플래티넘": {"min_visits": 50, "discount_rate": 0.20}
    }
    
    grade_info = grade_mapping.get(grade_name, grade_mapping["일반"])
    
    cursor.execute("""
        INSERT INTO customer_grades (name, min_visits, discount_rate)
        VALUES (?, ?, ?)
    """, (grade_name, grade_info["min_visits"], grade_info["discount_rate"]))
    
    return cursor.lastrowid

def import_customers_to_database(processed_customers):
    """처리된 고객 정보를 데이터베이스에 이전"""
    conn = create_database_connection()
    cursor = conn.cursor()
    
    imported_count = 0
    
    try:
        for customer_data in processed_customers:
            # 전화번호로 기존 고객 확인
            cursor.execute("SELECT id FROM customers WHERE phone = ?", (customer_data["phone"],))
            existing_customer = cursor.fetchone()
            
            if existing_customer:
                print(f"고객 {customer_data['name']} (전화번호: {customer_data['phone']})는 이미 존재합니다. 업데이트합니다.")
                customer_id = existing_customer[0]
                
                # 기존 고객 정보 업데이트
                grade_id = get_or_create_customer_grade(conn, customer_data["grade"])
                
                cursor.execute("""
                    UPDATE customers 
                    SET name = ?, grade_id = ?, visit_count = ?, 
                        completed_bookings = ?, cancelled_bookings = ?, no_show_bookings = ?
                    WHERE id = ?
                """, (
                    customer_data["name"],
                    grade_id,
                    customer_data["completedBookings"],
                    customer_data["completedBookings"],
                    customer_data["cancelledBookings"],
                    customer_data["noShowBookings"],
                    customer_id
                ))
            else:
                # 새 고객 생성
                grade_id = get_or_create_customer_grade(conn, customer_data["grade"])
                
                cursor.execute("""
                    INSERT INTO customers (name, phone, grade_id, visit_count, 
                                         completed_bookings, cancelled_bookings, no_show_bookings,
                                         created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    customer_data["name"],
                    customer_data["phone"],
                    grade_id,
                    customer_data["completedBookings"],
                    customer_data["completedBookings"],
                    customer_data["cancelledBookings"],
                    customer_data["noShowBookings"],
                    datetime.utcnow()
                ))
                
                customer_id = cursor.lastrowid
                print(f"새 고객 {customer_data['name']} (ID: {customer_id})를 생성했습니다.")
            
            # 반려동물 정보 처리
            for pet_data in customer_data["pets"]:
                # 기존 반려동물 확인
                cursor.execute("""
                    SELECT id FROM pets WHERE customer_id = ? AND name = ?
                """, (customer_id, pet_data["name"]))
                
                existing_pet = cursor.fetchone()
                
                if not existing_pet:
                    # 새 반려동물 추가
                    cursor.execute("""
                        INSERT INTO pets (customer_id, name, breed, created_at)
                        VALUES (?, ?, ?, ?)
                    """, (customer_id, pet_data["name"], pet_data["breed"], datetime.utcnow()))
                    
                    print(f"  - 반려동물 {pet_data['name']} ({pet_data['breed']})를 추가했습니다.")
            
            # 이용권 정보 처리
            if customer_data["membership"] != "보유 이용권 없음":
                membership_info = customer_data["membership"]
                if "정기권" in membership_info:
                    remaining_count = int(membership_info.split(":")[1].replace("회", ""))
                    
                    # 기존 이용권 확인
                    cursor.execute("""
                        SELECT id FROM memberships WHERE customer_id = ? AND status = 'active'
                    """, (customer_id,))
                    
                    existing_membership = cursor.fetchone()
                    
                    if not existing_membership:
                        cursor.execute("""
                            INSERT INTO memberships (customer_id, membership_type, total_count, 
                                                   remaining_count, status, created_at)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """, (customer_id, "정기권", remaining_count + 10, remaining_count, 
                              "active", datetime.utcnow()))
                        
                        print(f"  - 이용권 (남은 횟수: {remaining_count}회)를 추가했습니다.")
            
            imported_count += 1
        
        conn.commit()
        print(f"\n총 {imported_count}명의 고객 정보를 성공적으로 이전했습니다.")
        
    except Exception as e:
        conn.rollback()
        print(f"데이터베이스 이전 중 오류 발생: {str(e)}")
        raise
    
    finally:
        conn.close()

if __name__ == "__main__":
    # 처리된 고객 정보 로드
    with open("/home/ubuntu/teepee_customer_processed.json", "r", encoding="utf-8") as f:
        processed_customers = json.load(f)
    
    print(f"{len(processed_customers)}명의 고객 정보를 애견샵 예약 시스템으로 이전합니다...")
    
    # 데이터베이스로 이전
    import_customers_to_database(processed_customers)
    
    print("고객 정보 이전이 완료되었습니다!")

