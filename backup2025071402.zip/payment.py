from flask import Blueprint, request, jsonify
from src.models.booking import Payment, Booking, db
from src.routes.auth import token_required
from datetime import datetime, date
from sqlalchemy import func, and_, or_

payment_bp = Blueprint('payment', __name__)

@payment_bp.route('/payments', methods=['GET'])
@token_required
def get_payments(current_user):
    try:
        # 쿼리 파라미터
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        method = request.args.get('method')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # 기본 쿼리
        query = Payment.query
        
        # 필터 적용
        if status:
            query = query.filter(Payment.status == status)
        
        if method:
            query = query.filter(Payment.method == method)
        
        if start_date:
            start = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(Payment.payment_date >= start)
        
        if end_date:
            end = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(Payment.payment_date <= end)
        
        # 정렬 및 페이지네이션
        query = query.order_by(Payment.payment_date.desc())
        payments = query.paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'payments': [payment.to_dict() for payment in payments.items],
            'total': payments.total,
            'pages': payments.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get payments: {str(e)}'}), 500

@payment_bp.route('/payments', methods=['POST'])
@token_required
def create_payment(current_user):
    try:
        data = request.get_json()
        
        # 필수 필드 검증
        required_fields = ['booking_id', 'amount', 'method']
        for field in required_fields:
            if field not in data:
                return jsonify({'message': f'{field} is required'}), 400
        
        # 예약 존재 확인
        booking = Booking.query.get(data['booking_id'])
        if not booking:
            return jsonify({'message': 'Booking not found'}), 404
        
        # 새 결제 생성
        new_payment = Payment(
            booking_id=data['booking_id'],
            amount=data['amount'],
            method=data['method'],
            status=data.get('status', 'pending'),
            transaction_id=data.get('transaction_id'),
            notes=data.get('notes')
        )
        
        # 잔여 금액 계산
        new_payment.remaining_amount = new_payment.amount - new_payment.refund_amount
        
        db.session.add(new_payment)
        db.session.commit()
        
        return jsonify({
            'message': 'Payment created successfully',
            'payment': new_payment.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to create payment: {str(e)}'}), 500

@payment_bp.route('/payments/<int:payment_id>', methods=['PUT'])
@token_required
def update_payment(current_user, payment_id):
    try:
        payment = Payment.query.get_or_404(payment_id)
        data = request.get_json()
        
        # 업데이트 가능한 필드들
        if 'status' in data:
            payment.status = data['status']
        if 'refund_amount' in data:
            payment.refund_amount = data['refund_amount']
            payment.remaining_amount = payment.amount - payment.refund_amount
        if 'notes' in data:
            payment.notes = data['notes']
        if 'transaction_id' in data:
            payment.transaction_id = data['transaction_id']
        
        payment.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Payment updated successfully',
            'payment': payment.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to update payment: {str(e)}'}), 500

@payment_bp.route('/payments/stats', methods=['GET'])
@token_required
def get_payment_stats(current_user):
    try:
        # 오늘 날짜
        today = date.today()
        
        # 오늘 결제 통계
        today_payments = db.session.query(
            func.sum(Payment.amount).label('total_amount'),
            func.count(Payment.id).label('total_count')
        ).filter(
            func.date(Payment.payment_date) == today,
            Payment.status == 'completed'
        ).first()
        
        # 이번 달 결제 통계
        month_start = today.replace(day=1)
        month_payments = db.session.query(
            func.sum(Payment.amount).label('total_amount'),
            func.count(Payment.id).label('total_count')
        ).filter(
            Payment.payment_date >= month_start,
            Payment.status == 'completed'
        ).first()
        
        # 미결제 통계
        pending_payments = db.session.query(
            func.sum(Payment.amount).label('total_amount'),
            func.count(Payment.id).label('total_count')
        ).filter(Payment.status == 'pending').first()
        
        # 결제 방법별 통계
        method_stats = db.session.query(
            Payment.method,
            func.sum(Payment.amount).label('total_amount'),
            func.count(Payment.id).label('total_count')
        ).filter(Payment.status == 'completed').group_by(Payment.method).all()
        
        return jsonify({
            'today': {
                'amount': today_payments.total_amount or 0,
                'count': today_payments.total_count or 0
            },
            'month': {
                'amount': month_payments.total_amount or 0,
                'count': month_payments.total_count or 0
            },
            'pending': {
                'amount': pending_payments.total_amount or 0,
                'count': pending_payments.total_count or 0
            },
            'methods': [
                {
                    'method': stat.method,
                    'amount': stat.total_amount,
                    'count': stat.total_count
                } for stat in method_stats
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get payment stats: {str(e)}'}), 500

@payment_bp.route('/payments/<int:payment_id>/refund', methods=['POST'])
@token_required
def process_refund(current_user, payment_id):
    try:
        payment = Payment.query.get_or_404(payment_id)
        data = request.get_json()
        
        refund_amount = data.get('refund_amount', 0)
        refund_reason = data.get('refund_reason', '')
        
        # 환불 가능 금액 확인
        max_refund = payment.amount - payment.refund_amount
        if refund_amount > max_refund:
            return jsonify({'message': 'Refund amount exceeds available amount'}), 400
        
        # 환불 처리
        payment.refund_amount += refund_amount
        payment.remaining_amount = payment.amount - payment.refund_amount
        
        # 환불 상태 업데이트
        if payment.refund_amount == payment.amount:
            payment.status = 'refunded'
        elif payment.refund_amount > 0:
            payment.status = 'partial_refund'
        
        # 환불 메모 추가
        if payment.notes:
            payment.notes += f"\n환불: {refund_amount}원 ({refund_reason})"
        else:
            payment.notes = f"환불: {refund_amount}원 ({refund_reason})"
        
        payment.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Refund processed successfully',
            'payment': payment.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to process refund: {str(e)}'}), 500

