import json

def process_customer_data(raw_data):
    processed_customers = {}
    
    for customer in raw_data:
        # 전화번호와 보호자 이름으로 중복을 식별
        # Teepee 데이터에서 전화번호가 불완전한 경우가 있어 보호자 이름도 함께 사용
        phone = customer["contact"].split("\n")[0].strip() if "\n" in customer["contact"] else customer["contact"].strip()
        guardian_name = customer["guardianName"].strip()
        
        # 이름이 비어있는 경우 보호자 이름을 사용
        name = customer["name"].strip() if customer["name"].strip() else guardian_name

        # 반려동물 이름 정리
        pet_name_raw = customer["petName"].strip()
        pet_name = pet_name_raw.split(" (")[0].strip() if " (" in pet_name_raw else pet_name_raw
        pet_breed = pet_name_raw.split(" (")[1].replace(")", "").strip() if " (" in pet_name_raw else "기타"

        # 고유 키 생성 (전화번호 + 보호자 이름)
        unique_key = f"{phone}_{guardian_name}"
        
        if unique_key not in processed_customers:
            processed_customers[unique_key] = {
                "name": name,
                "phone": phone,
                "guardianName": guardian_name,
                "pets": [{
                    "name": pet_name,
                    "breed": pet_breed
                }],
                "grade": customer["grade"].strip() if customer["grade"].strip() else "일반",
                "completedBookings": customer["completed"],
                "cancelledBookings": customer["cancelled"],
                "noShowBookings": customer["noShow"],
                "membership": customer["membership"].strip(),
                "latestVisitInfo": {
                    "completed": customer["completed"],
                    "cancelled": customer["cancelled"],
                    "noShow": customer["noShow"]
                }
            }
        else:
            # 중복 고객인 경우 최신 이용 정보로 통합
            # 여기서는 completedBookings가 더 큰 경우를 최신으로 간주
            existing_customer = processed_customers[unique_key]
            if customer["completed"] > existing_customer["completedBookings"]:
                existing_customer["completedBookings"] = customer["completed"]
                existing_customer["cancelledBookings"] = customer["cancelled"]
                existing_customer["noShowBookings"] = customer["noShow"]
                existing_customer["membership"] = customer["membership"].strip()
                existing_customer["grade"] = customer["grade"].strip() if customer["grade"].strip() else existing_customer["grade"]
            
            # 반려동물 정보 추가 (중복 방지)
            new_pet = {"name": pet_name, "breed": pet_breed}
            if new_pet not in existing_customer["pets"]:
                existing_customer["pets"].append(new_pet)
                
    return list(processed_customers.values())

if __name__ == "__main__":
    with open("teepee_customer_raw.json", "r", encoding="utf-8") as f:
        raw_customer_data = json.load(f)
    
    processed_data = process_customer_data(raw_customer_data)
    
    with open("teepee_customer_processed.json", "w", encoding="utf-8") as f:
        json.dump(processed_data, f, ensure_ascii=False, indent=4)

    print(f"Processed {len(processed_data)} unique customers.")


