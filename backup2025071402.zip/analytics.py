from flask import Blueprint, request, jsonify
from src.models.booking import Payment, Booking, Service, db
from src.models.customer import Customer
from src.routes.auth import token_required
from datetime import datetime, date, timedelta
from sqlalchemy import func, and_, or_, extract
import calendar

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/analytics/revenue', methods=['GET'])
@token_required
def get_revenue_analytics(current_user):
    try:
        # 쿼리 파라미터
        period = request.args.get('period', 'daily')  # daily, weekly, monthly
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # 기본 날짜 범위 설정
        if not start_date or not end_date:
            today = date.today()
            if period == 'daily':
                start_date = today - timedelta(days=30)
                end_date = today
            elif period == 'weekly':
                start_date = today - timedelta(weeks=12)
                end_date = today
            else:  # monthly
                start_date = today - timedelta(days=365)
                end_date = today
        else:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        # 매출 데이터 조회
        revenue_data = []
        
        if period == 'daily':
            # 일별 매출
            daily_revenue = db.session.query(
                func.date(Payment.payment_date).label('date'),
                func.sum(Payment.amount).label('total_amount'),
                func.count(Payment.id).label('total_count')
            ).filter(
                and_(
                    func.date(Payment.payment_date) >= start_date,
                    func.date(Payment.payment_date) <= end_date,
                    Payment.status == 'completed'
                )
            ).group_by(func.date(Payment.payment_date)).all()
            
            revenue_data = [
                {
                    'period': str(item.date),
                    'amount': item.total_amount or 0,
                    'count': item.total_count or 0
                } for item in daily_revenue
            ]
            
        elif period == 'weekly':
            # 주별 매출
            weekly_revenue = db.session.query(
                func.year(Payment.payment_date).label('year'),
                func.week(Payment.payment_date).label('week'),
                func.sum(Payment.amount).label('total_amount'),
                func.count(Payment.id).label('total_count')
            ).filter(
                and_(
                    func.date(Payment.payment_date) >= start_date,
                    func.date(Payment.payment_date) <= end_date,
                    Payment.status == 'completed'
                )
            ).group_by(
                func.year(Payment.payment_date),
                func.week(Payment.payment_date)
            ).all()
            
            revenue_data = [
                {
                    'period': f"{item.year}-W{item.week:02d}",
                    'amount': item.total_amount or 0,
                    'count': item.total_count or 0
                } for item in weekly_revenue
            ]
            
        else:  # monthly
            # 월별 매출
            monthly_revenue = db.session.query(
                func.year(Payment.payment_date).label('year'),
                func.month(Payment.payment_date).label('month'),
                func.sum(Payment.amount).label('total_amount'),
                func.count(Payment.id).label('total_count')
            ).filter(
                and_(
                    func.date(Payment.payment_date) >= start_date,
                    func.date(Payment.payment_date) <= end_date,
                    Payment.status == 'completed'
                )
            ).group_by(
                func.year(Payment.payment_date),
                func.month(Payment.payment_date)
            ).all()
            
            revenue_data = [
                {
                    'period': f"{item.year}-{item.month:02d}",
                    'amount': item.total_amount or 0,
                    'count': item.total_count or 0
                } for item in monthly_revenue
            ]
        
        return jsonify({
            'period': period,
            'start_date': str(start_date),
            'end_date': str(end_date),
            'revenue_data': revenue_data
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get revenue analytics: {str(e)}'}), 500

@analytics_bp.route('/analytics/payment-methods', methods=['GET'])
@token_required
def get_payment_method_analytics(current_user):
    try:
        # 쿼리 파라미터
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # 기본 날짜 범위 (최근 30일)
        if not start_date or not end_date:
            today = date.today()
            start_date = today - timedelta(days=30)
            end_date = today
        else:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        # 결제 방법별 통계
        method_stats = db.session.query(
            Payment.method,
            func.sum(Payment.amount).label('total_amount'),
            func.count(Payment.id).label('total_count')
        ).filter(
            and_(
                func.date(Payment.payment_date) >= start_date,
                func.date(Payment.payment_date) <= end_date,
                Payment.status == 'completed'
            )
        ).group_by(Payment.method).all()
        
        # 전체 금액 계산
        total_amount = sum(stat.total_amount for stat in method_stats)
        
        # 결과 데이터
        method_data = []
        for stat in method_stats:
            percentage = (stat.total_amount / total_amount * 100) if total_amount > 0 else 0
            method_data.append({
                'method': stat.method,
                'amount': stat.total_amount,
                'count': stat.total_count,
                'percentage': round(percentage, 1)
            })
        
        return jsonify({
            'start_date': str(start_date),
            'end_date': str(end_date),
            'total_amount': total_amount,
            'method_data': method_data
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get payment method analytics: {str(e)}'}), 500

@analytics_bp.route('/analytics/services', methods=['GET'])
@token_required
def get_service_analytics(current_user):
    try:
        # 쿼리 파라미터
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # 기본 날짜 범위 (최근 30일)
        if not start_date or not end_date:
            today = date.today()
            start_date = today - timedelta(days=30)
            end_date = today
        else:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        # 서비스별 예약 및 매출 통계
        service_stats = db.session.query(
            Service.name,
            Service.category,
            func.count(Booking.id).label('booking_count'),
            func.sum(Payment.amount).label('total_revenue')
        ).join(
            Booking, Service.id == Booking.service_id
        ).join(
            Payment, Booking.id == Payment.booking_id
        ).filter(
            and_(
                Booking.booking_date >= start_date,
                Booking.booking_date <= end_date,
                Payment.status == 'completed'
            )
        ).group_by(Service.id, Service.name, Service.category).all()
        
        service_data = [
            {
                'service_name': stat.name,
                'category': stat.category,
                'booking_count': stat.booking_count,
                'total_revenue': stat.total_revenue or 0
            } for stat in service_stats
        ]
        
        return jsonify({
            'start_date': str(start_date),
            'end_date': str(end_date),
            'service_data': service_data
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get service analytics: {str(e)}'}), 500

@analytics_bp.route('/analytics/customers', methods=['GET'])
@token_required
def get_customer_analytics(current_user):
    try:
        # 고객 등급별 통계
        grade_stats = db.session.query(
            Customer.grade_id,
            func.count(Customer.id).label('customer_count')
        ).group_by(Customer.grade_id).all()
        
        # 신규 고객 통계 (최근 30일)
        thirty_days_ago = date.today() - timedelta(days=30)
        new_customers = Customer.query.filter(
            Customer.created_at >= thirty_days_ago
        ).count()
        
        # 활성 고객 통계 (최근 30일 내 예약이 있는 고객)
        active_customers = db.session.query(
            func.count(func.distinct(Booking.customer_id))
        ).filter(
            Booking.booking_date >= thirty_days_ago
        ).scalar()
        
        # 총 고객 수
        total_customers = Customer.query.count()
        
        return jsonify({
            'total_customers': total_customers,
            'new_customers_30d': new_customers,
            'active_customers_30d': active_customers or 0,
            'grade_distribution': [
                {
                    'grade_id': stat.grade_id,
                    'customer_count': stat.customer_count
                } for stat in grade_stats
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get customer analytics: {str(e)}'}), 500

@analytics_bp.route('/analytics/dashboard', methods=['GET'])
@token_required
def get_dashboard_analytics(current_user):
    try:
        today = date.today()
        
        # 오늘 통계
        today_stats = db.session.query(
            func.count(Booking.id).label('bookings'),
            func.sum(Payment.amount).label('revenue')
        ).join(
            Payment, Booking.id == Payment.booking_id, isouter=True
        ).filter(
            and_(
                Booking.booking_date == today,
                or_(Payment.status == 'completed', Payment.status.is_(None))
            )
        ).first()
        
        # 이번 달 통계
        month_start = today.replace(day=1)
        month_stats = db.session.query(
            func.count(Booking.id).label('bookings'),
            func.sum(Payment.amount).label('revenue')
        ).join(
            Payment, Booking.id == Payment.booking_id, isouter=True
        ).filter(
            and_(
                Booking.booking_date >= month_start,
                or_(Payment.status == 'completed', Payment.status.is_(None))
            )
        ).first()
        
        # 예약 상태별 통계
        status_stats = db.session.query(
            Booking.status,
            func.count(Booking.id).label('count')
        ).filter(
            Booking.booking_date >= month_start
        ).group_by(Booking.status).all()
        
        return jsonify({
            'today': {
                'bookings': today_stats.bookings or 0,
                'revenue': today_stats.revenue or 0
            },
            'month': {
                'bookings': month_stats.bookings or 0,
                'revenue': month_stats.revenue or 0
            },
            'booking_status': [
                {
                    'status': stat.status,
                    'count': stat.count
                } for stat in status_stats
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get dashboard analytics: {str(e)}'}), 500

