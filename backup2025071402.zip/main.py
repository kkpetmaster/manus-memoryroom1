import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.models.customer import Customer, CustomerGrade, Pet, Membership
from src.models.booking import Booking, Service, Payment, DailyMemo
from src.routes.user import user_bp
from src.routes.auth import auth_bp
from src.routes.booking import booking_bp
from src.routes.customer import customer_bp
from src.routes.payment import payment_bp
from src.routes.analytics import analytics_bp
from src.routes.sms import sms_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# CORS 설정
CORS(app, supports_credentials=True)

# 블루프린트 등록
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(booking_bp, url_prefix='/api')
app.register_blueprint(customer_bp, url_prefix='/api')
app.register_blueprint(payment_bp, url_prefix='/api')
app.register_blueprint(analytics_bp, url_prefix='/api')
app.register_blueprint(sms_bp, url_prefix='/api')

# 데이터베이스 설정
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def init_sample_data():
    """샘플 데이터 초기화"""
    from werkzeug.security import generate_password_hash
    from src.models.user import User
    from datetime import datetime, date, time
    
    # 기본 사용자 생성
    if not User.query.filter_by(username='admin').first():
        admin = User(
            username='admin',
            password=generate_password_hash('admin123'),
            email='admin@petshop.com',
            role='admin'
        )
        db.session.add(admin)
    
    if not User.query.filter_by(username='manager').first():
        manager = User(
            username='manager',
            password=generate_password_hash('manager123'),
            email='manager@petshop.com',
            role='manager'
        )
        db.session.add(manager)
    
    if not User.query.filter_by(username='staff1').first():
        staff = User(
            username='staff1',
            password=generate_password_hash('staff123'),
            email='staff1@petshop.com',
            role='staff'
        )
        db.session.add(staff)
    
    # 고객 등급 생성
    if not CustomerGrade.query.first():
        grades = [
            CustomerGrade(name='브론즈', min_visits=0, max_visits=4, color='#CD7F32', benefits='기본 혜택'),
            CustomerGrade(name='실버', min_visits=5, max_visits=14, color='#C0C0C0', benefits='5% 할인'),
            CustomerGrade(name='골드', min_visits=15, max_visits=29, color='#FFD700', benefits='10% 할인'),
            CustomerGrade(name='플래티넘', min_visits=30, color='#E5E4E2', benefits='15% 할인 + 우선 예약')
        ]
        for grade in grades:
            db.session.add(grade)
    
    # 서비스 생성
    if not Service.query.first():
        services = [
            Service(name='기본 목욕', description='기본적인 목욕 서비스', price=30000, duration=60, category='목욕'),
            Service(name='프리미엄 목욕', description='프리미엄 목욕 + 마사지', price=50000, duration=90, category='목욕'),
            Service(name='전체 미용', description='전체적인 미용 서비스', price=80000, duration=120, category='미용'),
            Service(name='부분 미용', description='부분적인 미용 서비스', price=40000, duration=60, category='미용'),
            Service(name='네일 케어', description='발톱 정리 서비스', price=15000, duration=30, category='케어'),
            Service(name='치아 케어', description='치아 청소 서비스', price=25000, duration=45, category='케어')
        ]
        for service in services:
            db.session.add(service)
    
    # 샘플 고객 생성
    if not Customer.query.first():
        customers = [
            Customer(name='김철수', phone='010-1234-5678', email='kim@example.com', grade_id=1),
            Customer(name='이영희', phone='010-2345-6789', email='lee@example.com', grade_id=2),
            Customer(name='박민수', phone='010-3456-7890', email='park@example.com', grade_id=1),
            Customer(name='최지영', phone='010-4567-8901', email='choi@example.com', grade_id=3)
        ]
        for customer in customers:
            db.session.add(customer)
        
        db.session.commit()
        
        # 샘플 반려동물 생성
        pets = [
            Pet(name='멍멍이', species='강아지', breed='골든 리트리버', age=3, weight=25.5, gender='수컷', customer_id=1),
            Pet(name='야옹이', species='고양이', breed='페르시안', age=2, weight=4.2, gender='암컷', customer_id=2),
            Pet(name='초코', species='강아지', breed='푸들', age=1, weight=3.8, gender='수컷', customer_id=3),
            Pet(name='루비', species='강아지', breed='말티즈', age=4, weight=2.5, gender='암컷', customer_id=4)
        ]
        for pet in pets:
            db.session.add(pet)
        
        # 샘플 예약 생성
        bookings = [
            Booking(
                customer_id=1, pet_id=1, service_id=1, staff_id=1,
                booking_date=date.today(), booking_time=time(10, 0),
                end_time=time(11, 0), status='confirmed',
                original_price=30000, final_price=30000
            ),
            Booking(
                customer_id=2, pet_id=2, service_id=3, staff_id=2,
                booking_date=date.today(), booking_time=time(14, 0),
                end_time=time(16, 0), status='confirmed',
                original_price=80000, final_price=72000, discount_amount=8000
            )
        ]
        for booking in bookings:
            db.session.add(booking)
    
    db.session.commit()

with app.app_context():
    db.create_all()
    init_sample_data()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

