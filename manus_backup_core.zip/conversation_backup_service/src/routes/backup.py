from flask import Blueprint, request, jsonify
import json
import os
import sys
from datetime import datetime
import requests
import base64
from google.cloud import storage

# 백업 클라이언트 임포트
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from backup_client import ConversationBackupClient

backup_bp = Blueprint('backup', __name__)

# 전역 백업 클라이언트 인스턴스
backup_clients = {}

@backup_bp.route('/init', methods=['POST'])
def init_backup():
    """백업 클라이언트 초기화"""
    try:
        data = request.get_json()
        
        # 필수 파라미터 확인
        required_fields = ['user_id']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        user_id = data['user_id']
        
        # 백업 설정
        config = {
            'github_token': data.get('github_token'),
            'github_repo': data.get('github_repo'),
            'gcp_project_id': data.get('gcp_project_id'),
            'gcp_bucket_name': data.get('gcp_bucket_name'),
            'user_id': user_id,
            'backup_interval': data.get('backup_interval', 30)
        }
        
        # 백업 클라이언트 생성
        backup_client = ConversationBackupClient(config)
        backup_clients[user_id] = backup_client
        
        return jsonify({
            'success': True,
            'conversation_id': backup_client.conversation_data['conversation_id'],
            'message': 'Backup client initialized successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@backup_bp.route('/message', methods=['POST'])
def add_message():
    """메시지 추가 및 백업"""
    try:
        data = request.get_json()
        
        # 필수 파라미터 확인
        required_fields = ['user_id', 'role', 'content']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        user_id = data['user_id']
        
        # 백업 클라이언트 확인
        if user_id not in backup_clients:
            return jsonify({'error': 'Backup client not initialized'}), 400
        
        backup_client = backup_clients[user_id]
        
        # 메시지 추가
        backup_client.add_message(
            role=data['role'],
            content=data['content'],
            attachments=data.get('attachments', []),
            function_calls=data.get('function_calls', [])
        )
        
        return jsonify({
            'success': True,
            'message': 'Message added and backed up successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@backup_bp.route('/context', methods=['POST'])
def update_context():
    """컨텍스트 업데이트"""
    try:
        data = request.get_json()
        
        user_id = data.get('user_id')
        if not user_id:
            return jsonify({'error': 'Missing user_id'}), 400
        
        # 백업 클라이언트 확인
        if user_id not in backup_clients:
            return jsonify({'error': 'Backup client not initialized'}), 400
        
        backup_client = backup_clients[user_id]
        
        # 컨텍스트 업데이트
        backup_client.update_context(
            task_plan=data.get('task_plan'),
            current_phase=data.get('current_phase'),
            working_directory=data.get('working_directory'),
            files_created=data.get('files_created')
        )
        
        return jsonify({
            'success': True,
            'message': 'Context updated successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@backup_bp.route('/restore/<conversation_id>', methods=['GET'])
def restore_conversation(conversation_id):
    """대화 복원"""
    try:
        source = request.args.get('source', 'github')
        user_id = request.args.get('user_id')
        
        if not user_id:
            return jsonify({'error': 'Missing user_id parameter'}), 400
        
        # 백업 클라이언트 확인
        if user_id not in backup_clients:
            return jsonify({'error': 'Backup client not initialized'}), 400
        
        backup_client = backup_clients[user_id]
        
        # 대화 복원
        conversation_data = backup_client.restore_conversation(conversation_id, source)
        
        if conversation_data:
            return jsonify({
                'success': True,
                'conversation_data': conversation_data
            })
        else:
            return jsonify({'error': 'Conversation not found'}), 404
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@backup_bp.route('/list', methods=['GET'])
def list_conversations():
    """대화 목록 조회"""
    try:
        source = request.args.get('source', 'github')
        user_id = request.args.get('user_id')
        
        if not user_id:
            return jsonify({'error': 'Missing user_id parameter'}), 400
        
        # 백업 클라이언트 확인
        if user_id not in backup_clients:
            return jsonify({'error': 'Backup client not initialized'}), 400
        
        backup_client = backup_clients[user_id]
        
        # 대화 목록 조회
        conversations = backup_client.list_conversations(source)
        
        return jsonify({
            'success': True,
            'conversations': conversations
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@backup_bp.route('/status/<user_id>', methods=['GET'])
def get_backup_status(user_id):
    """백업 상태 조회"""
    try:
        if user_id not in backup_clients:
            return jsonify({
                'initialized': False,
                'message': 'Backup client not initialized'
            })
        
        backup_client = backup_clients[user_id]
        
        return jsonify({
            'initialized': True,
            'conversation_id': backup_client.conversation_data['conversation_id'],
            'message_count': len(backup_client.conversation_data['messages']),
            'last_updated': backup_client.conversation_data['last_updated'],
            'context': backup_client.conversation_data['context']
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@backup_bp.route('/export/<user_id>', methods=['GET'])
def export_conversation(user_id):
    """대화 내용 내보내기"""
    try:
        if user_id not in backup_clients:
            return jsonify({'error': 'Backup client not initialized'}), 400
        
        backup_client = backup_clients[user_id]
        
        return jsonify({
            'success': True,
            'conversation_data': backup_client.conversation_data
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@backup_bp.route('/manual-backup', methods=['POST'])
def manual_backup():
    """수동 백업 실행"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        if not user_id:
            return jsonify({'error': 'Missing user_id'}), 400
        
        if user_id not in backup_clients:
            return jsonify({'error': 'Backup client not initialized'}), 400
        
        backup_client = backup_clients[user_id]
        
        # 수동 백업 실행
        backup_client._trigger_backup()
        
        return jsonify({
            'success': True,
            'message': 'Manual backup completed'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

