# 계정 간 대화 연속성 가이드

## 개요
Manus 무료 크레딧이 소진되었을 때 새로운 계정으로 이전하여 대화를 이어갈 수 있는 완전한 가이드입니다.

## 1. 현재 계정에서 백업 준비

### 1.1 GitHub Repository 설정
```bash
# 1. GitHub에서 새 Private Repository 생성
# 2. Personal Access Token 생성 (repo 권한 필요)
# 3. Repository 이름: manus-conversation-backup
```

### 1.2 백업 시스템 초기화
1. 백업 서비스 웹 인터페이스 접속
2. 다음 정보 입력:
   - 사용자 ID: 고유한 식별자 (예: your_username_2025)
   - GitHub Token: 생성한 Personal Access Token
   - GitHub Repository: username/manus-conversation-backup
   - 백업 간격: 30초 (기본값)

### 1.3 현재 대화 백업
```javascript
// 웹 인터페이스에서 또는 API 직접 호출
// 모든 메시지와 컨텍스트가 자동으로 백업됩니다
```

## 2. 새 계정으로 이전

### 2.1 새 계정 생성
1. 새로운 이메일로 Manus 계정 생성
2. 무료 크레딧 확인

### 2.2 백업 시스템 재설정
1. 동일한 백업 서비스에 접속
2. **동일한 설정** 사용:
   - 사용자 ID: 이전과 동일한 ID 사용
   - GitHub Token: 동일한 토큰 사용
   - GitHub Repository: 동일한 저장소 사용

### 2.3 대화 복원
1. "대화 복원" 섹션에서 "대화 목록 조회" 클릭
2. 복원할 대화 ID 선택
3. "대화 복원" 버튼 클릭

## 3. 자동화 스크립트

### 3.1 백업 자동화 스크립트
```python
#!/usr/bin/env python3
"""
Manus 대화 자동 백업 스크립트
크레딧 소진 전에 실행하여 모든 대화 내용을 백업합니다.
"""

import requests
import json
import time
from datetime import datetime

class ManusBackupAutomation:
    def __init__(self, backup_service_url, user_id, github_token, github_repo):
        self.backup_service_url = backup_service_url.rstrip('/')
        self.user_id = user_id
        self.github_token = github_token
        self.github_repo = github_repo
        
    def initialize_backup(self):
        """백업 시스템 초기화"""
        url = f"{self.backup_service_url}/api/backup/init"
        data = {
            "user_id": self.user_id,
            "github_token": self.github_token,
            "github_repo": self.github_repo,
            "backup_interval": 30
        }
        
        response = requests.post(url, json=data)
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                print(f"백업 시스템 초기화 성공: {result.get('conversation_id')}")
                return result.get('conversation_id')
            else:
                print(f"초기화 실패: {result.get('error')}")
                return None
        else:
            print(f"HTTP 오류: {response.status_code}")
            return None
    
    def backup_conversation_history(self, messages):
        """대화 기록 백업"""
        for message in messages:
            self.add_message(
                role=message.get('role', 'user'),
                content=message.get('content', ''),
                attachments=message.get('attachments', []),
                function_calls=message.get('function_calls', [])
            )
            time.sleep(1)  # API 호출 간격
    
    def add_message(self, role, content, attachments=None, function_calls=None):
        """메시지 추가"""
        url = f"{self.backup_service_url}/api/backup/message"
        data = {
            "user_id": self.user_id,
            "role": role,
            "content": content,
            "attachments": attachments or [],
            "function_calls": function_calls or []
        }
        
        response = requests.post(url, json=data)
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                print(f"메시지 백업 성공: {role}")
            else:
                print(f"메시지 백업 실패: {result.get('error')}")
        else:
            print(f"HTTP 오류: {response.status_code}")
    
    def update_context(self, task_plan=None, current_phase=None, 
                      working_directory=None, files_created=None):
        """컨텍스트 업데이트"""
        url = f"{self.backup_service_url}/api/backup/context"
        data = {
            "user_id": self.user_id,
            "task_plan": task_plan,
            "current_phase": current_phase,
            "working_directory": working_directory,
            "files_created": files_created
        }
        
        response = requests.post(url, json=data)
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                print("컨텍스트 업데이트 성공")
            else:
                print(f"컨텍스트 업데이트 실패: {result.get('error')}")
        else:
            print(f"HTTP 오류: {response.status_code}")
    
    def export_conversation(self):
        """대화 내용 내보내기"""
        url = f"{self.backup_service_url}/api/backup/export/{self.user_id}"
        
        response = requests.get(url)
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                # 파일로 저장
                filename = f"manus_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(result['conversation_data'], f, indent=2, ensure_ascii=False)
                print(f"대화 내용이 {filename}에 저장되었습니다.")
                return filename
            else:
                print(f"내보내기 실패: {result.get('error')}")
                return None
        else:
            print(f"HTTP 오류: {response.status_code}")
            return None

# 사용 예제
if __name__ == "__main__":
    # 설정
    BACKUP_SERVICE_URL = "http://localhost:5000"  # 백업 서비스 URL
    USER_ID = "your_unique_user_id"
    GITHUB_TOKEN = "your_github_token"
    GITHUB_REPO = "username/manus-conversation-backup"
    
    # 백업 자동화 인스턴스 생성
    backup = ManusBackupAutomation(
        backup_service_url=BACKUP_SERVICE_URL,
        user_id=USER_ID,
        github_token=GITHUB_TOKEN,
        github_repo=GITHUB_REPO
    )
    
    # 백업 시스템 초기화
    conversation_id = backup.initialize_backup()
    
    if conversation_id:
        # 현재 대화 내용 백업 (예시)
        sample_messages = [
            {"role": "user", "content": "안녕하세요!"},
            {"role": "assistant", "content": "안녕하세요! 무엇을 도와드릴까요?"},
            # ... 더 많은 메시지
        ]
        
        backup.backup_conversation_history(sample_messages)
        
        # 컨텍스트 정보 업데이트
        backup.update_context(
            task_plan={"goal": "백업 테스트", "phases": []},
            current_phase=1,
            working_directory="/home/ubuntu/work",
            files_created=["test.txt", "backup.json"]
        )
        
        # 최종 백업 파일 생성
        backup_file = backup.export_conversation()
        print(f"백업 완료: {backup_file}")
```

### 3.2 복원 자동화 스크립트
```python
#!/usr/bin/env python3
"""
새 계정에서 대화 복원 스크립트
"""

import requests
import json

class ManusRestoreAutomation:
    def __init__(self, backup_service_url, user_id, github_token, github_repo):
        self.backup_service_url = backup_service_url.rstrip('/')
        self.user_id = user_id
        self.github_token = github_token
        self.github_repo = github_repo
    
    def initialize_and_restore(self, conversation_id):
        """백업 시스템 초기화 및 대화 복원"""
        # 1. 백업 시스템 초기화
        init_url = f"{self.backup_service_url}/api/backup/init"
        init_data = {
            "user_id": self.user_id,
            "github_token": self.github_token,
            "github_repo": self.github_repo,
            "backup_interval": 30
        }
        
        response = requests.post(init_url, json=init_data)
        if response.status_code != 200:
            print("백업 시스템 초기화 실패")
            return False
        
        # 2. 대화 복원
        restore_url = f"{self.backup_service_url}/api/backup/restore/{conversation_id}"
        params = {"user_id": self.user_id, "source": "github"}
        
        response = requests.get(restore_url, params=params)
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                print("대화 복원 성공!")
                print(f"복원된 메시지 수: {len(result['conversation_data']['messages'])}")
                return result['conversation_data']
            else:
                print(f"복원 실패: {result.get('error')}")
                return None
        else:
            print(f"HTTP 오류: {response.status_code}")
            return None
    
    def list_available_conversations(self):
        """사용 가능한 대화 목록 조회"""
        url = f"{self.backup_service_url}/api/backup/list"
        params = {"user_id": self.user_id, "source": "github"}
        
        response = requests.get(url, params=params)
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                return result['conversations']
            else:
                print(f"목록 조회 실패: {result.get('error')}")
                return []
        else:
            print(f"HTTP 오류: {response.status_code}")
            return []

# 사용 예제
if __name__ == "__main__":
    # 설정 (이전 계정과 동일하게)
    BACKUP_SERVICE_URL = "http://localhost:5000"
    USER_ID = "your_unique_user_id"  # 이전과 동일한 ID
    GITHUB_TOKEN = "your_github_token"  # 동일한 토큰
    GITHUB_REPO = "username/manus-conversation-backup"  # 동일한 저장소
    
    restore = ManusRestoreAutomation(
        backup_service_url=BACKUP_SERVICE_URL,
        user_id=USER_ID,
        github_token=GITHUB_TOKEN,
        github_repo=GITHUB_REPO
    )
    
    # 사용 가능한 대화 목록 확인
    conversations = restore.list_available_conversations()
    print("사용 가능한 대화:")
    for conv_id in conversations:
        print(f"- {conv_id}")
    
    # 특정 대화 복원
    if conversations:
        latest_conversation = conversations[0]  # 가장 최근 대화
        restored_data = restore.initialize_and_restore(latest_conversation)
        
        if restored_data:
            print("복원 완료!")
            print(f"대화 ID: {restored_data['conversation_id']}")
            print(f"마지막 업데이트: {restored_data['last_updated']}")
```

## 4. 단계별 실행 가이드

### 4.1 크레딧 소진 전 (현재 계정)
1. 백업 서비스 실행
2. GitHub Repository 및 Token 설정
3. 백업 시스템 초기화
4. 자동 백업 활성화
5. 대화 내용 수동 내보내기 (보험용)

### 4.2 새 계정 생성 후
1. 새 Manus 계정으로 로그인
2. 동일한 백업 서비스 접속
3. 동일한 설정으로 초기화
4. 대화 목록에서 복원할 대화 선택
5. 대화 복원 실행
6. 컨텍스트 및 파일 상태 확인

### 4.3 연속성 확인
1. 복원된 대화 내용 검증
2. 작업 진행 상황 확인
3. 파일 및 컨텍스트 복원 확인
4. 새 계정에서 작업 재개

## 5. 주의사항

### 5.1 보안
- GitHub Token은 안전하게 보관
- Private Repository 사용 필수
- 민감한 정보는 별도 암호화 고려

### 5.2 데이터 무결성
- 정기적인 수동 백업 권장
- 중요한 파일은 별도 저장
- 백업 상태 정기 확인

### 5.3 제한사항
- GitHub API 호출 제한 고려
- 대용량 파일은 별도 처리 필요
- 네트워크 연결 상태 확인

## 6. 문제 해결

### 6.1 백업 실패
- GitHub Token 권한 확인
- Repository 접근 권한 확인
- 네트워크 연결 상태 확인

### 6.2 복원 실패
- 대화 ID 정확성 확인
- 백업 파일 존재 여부 확인
- 설정 정보 일치 여부 확인

### 6.3 연속성 문제
- 컨텍스트 정보 수동 확인
- 파일 경로 및 상태 확인
- 작업 단계 재확인

이 가이드를 따라하면 Manus 계정 간 완벽한 대화 연속성을 보장할 수 있습니다.

