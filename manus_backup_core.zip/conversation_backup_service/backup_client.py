#!/usr/bin/env python3
"""
실시간 대화 백업 클라이언트
GitHub와 Google Cloud Storage에 대화 내용을 백업합니다.
"""

import json
import os
import time
import hashlib
from datetime import datetime
from typing import Dict, List, Any, Optional
import requests
from google.cloud import storage
import base64

class ConversationBackupClient:
    def __init__(self, config: Dict[str, Any]):
        """
        백업 클라이언트 초기화
        
        Args:
            config: 설정 딕셔너리
                - github_token: GitHub Personal Access Token
                - github_repo: GitHub 저장소 (owner/repo)
                - gcp_project_id: GCP 프로젝트 ID
                - gcp_bucket_name: GCS 버킷 이름
                - backup_interval: 백업 간격 (초)
        """
        self.config = config
        self.github_token = config.get('github_token')
        self.github_repo = config.get('github_repo')
        self.gcp_project_id = config.get('gcp_project_id')
        self.gcp_bucket_name = config.get('gcp_bucket_name')
        self.backup_interval = config.get('backup_interval', 30)
        
        # GitHub API 헤더
        self.github_headers = {
            'Authorization': f'token {self.github_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # GCS 클라이언트 초기화
        if self.gcp_project_id:
            try:
                self.gcs_client = storage.Client(project=self.gcp_project_id)
                self.bucket = self.gcs_client.bucket(self.gcp_bucket_name)
            except Exception as e:
                print(f"GCS 클라이언트 초기화 실패: {e}")
                self.gcs_client = None
                self.bucket = None
        
        # 대화 데이터 저장
        self.conversation_data = {
            "conversation_id": self._generate_conversation_id(),
            "user_id": config.get('user_id', 'anonymous'),
            "created_at": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
            "messages": [],
            "context": {
                "task_plan": {},
                "current_phase": 1,
                "working_directory": os.getcwd(),
                "files_created": []
            }
        }
    
    def _generate_conversation_id(self) -> str:
        """고유한 대화 ID 생성"""
        timestamp = str(int(time.time()))
        random_str = os.urandom(8).hex()
        return f"conv_{timestamp}_{random_str}"
    
    def add_message(self, role: str, content: str, attachments: List[str] = None, 
                   function_calls: List[Dict] = None):
        """대화에 메시지 추가"""
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "attachments": attachments or [],
            "function_calls": function_calls or []
        }
        
        self.conversation_data["messages"].append(message)
        self.conversation_data["last_updated"] = datetime.now().isoformat()
        
        # 자동 백업 트리거
        self._trigger_backup()
    
    def update_context(self, task_plan: Dict = None, current_phase: int = None,
                      working_directory: str = None, files_created: List[str] = None):
        """컨텍스트 정보 업데이트"""
        if task_plan is not None:
            self.conversation_data["context"]["task_plan"] = task_plan
        if current_phase is not None:
            self.conversation_data["context"]["current_phase"] = current_phase
        if working_directory is not None:
            self.conversation_data["context"]["working_directory"] = working_directory
        if files_created is not None:
            self.conversation_data["context"]["files_created"] = files_created
        
        self.conversation_data["last_updated"] = datetime.now().isoformat()
        self._trigger_backup()
    
    def _trigger_backup(self):
        """백업 트리거"""
        try:
            # GitHub 백업
            if self.github_token and self.github_repo:
                self._backup_to_github()
            
            # GCS 백업
            if self.gcs_client and self.bucket:
                self._backup_to_gcs()
                
        except Exception as e:
            print(f"백업 실패: {e}")
    
    def _backup_to_github(self):
        """GitHub에 백업"""
        try:
            # 파일 경로
            file_path = f"conversations/{self.conversation_data['conversation_id']}.json"
            
            # 현재 파일 내용 확인
            url = f"https://api.github.com/repos/{self.github_repo}/contents/{file_path}"
            response = requests.get(url, headers=self.github_headers)
            
            # 파일 내용 준비
            content = json.dumps(self.conversation_data, indent=2, ensure_ascii=False)
            encoded_content = base64.b64encode(content.encode('utf-8')).decode('utf-8')
            
            # 커밋 데이터
            commit_data = {
                "message": f"Update conversation {self.conversation_data['conversation_id']}",
                "content": encoded_content
            }
            
            # 기존 파일이 있으면 SHA 추가
            if response.status_code == 200:
                commit_data["sha"] = response.json()["sha"]
            
            # 파일 업데이트/생성
            response = requests.put(url, headers=self.github_headers, json=commit_data)
            
            if response.status_code in [200, 201]:
                print(f"GitHub 백업 성공: {file_path}")
            else:
                print(f"GitHub 백업 실패: {response.status_code} - {response.text}")
                
        except Exception as e:
            print(f"GitHub 백업 오류: {e}")
    
    def _backup_to_gcs(self):
        """Google Cloud Storage에 백업"""
        try:
            # 파일 이름
            blob_name = f"conversations/{self.conversation_data['conversation_id']}.json"
            
            # 블롭 생성
            blob = self.bucket.blob(blob_name)
            
            # 데이터 업로드
            content = json.dumps(self.conversation_data, indent=2, ensure_ascii=False)
            blob.upload_from_string(content, content_type='application/json')
            
            print(f"GCS 백업 성공: {blob_name}")
            
        except Exception as e:
            print(f"GCS 백업 오류: {e}")
    
    def restore_conversation(self, conversation_id: str, source: str = 'github') -> Optional[Dict]:
        """대화 복원"""
        try:
            if source == 'github':
                return self._restore_from_github(conversation_id)
            elif source == 'gcs':
                return self._restore_from_gcs(conversation_id)
            else:
                raise ValueError("지원되지 않는 소스입니다. 'github' 또는 'gcs'를 사용하세요.")
                
        except Exception as e:
            print(f"대화 복원 실패: {e}")
            return None
    
    def _restore_from_github(self, conversation_id: str) -> Optional[Dict]:
        """GitHub에서 대화 복원"""
        try:
            file_path = f"conversations/{conversation_id}.json"
            url = f"https://api.github.com/repos/{self.github_repo}/contents/{file_path}"
            
            response = requests.get(url, headers=self.github_headers)
            
            if response.status_code == 200:
                content = base64.b64decode(response.json()["content"]).decode('utf-8')
                return json.loads(content)
            else:
                print(f"GitHub에서 대화를 찾을 수 없습니다: {conversation_id}")
                return None
                
        except Exception as e:
            print(f"GitHub 복원 오류: {e}")
            return None
    
    def _restore_from_gcs(self, conversation_id: str) -> Optional[Dict]:
        """GCS에서 대화 복원"""
        try:
            blob_name = f"conversations/{conversation_id}.json"
            blob = self.bucket.blob(blob_name)
            
            if blob.exists():
                content = blob.download_as_text()
                return json.loads(content)
            else:
                print(f"GCS에서 대화를 찾을 수 없습니다: {conversation_id}")
                return None
                
        except Exception as e:
            print(f"GCS 복원 오류: {e}")
            return None
    
    def list_conversations(self, source: str = 'github') -> List[str]:
        """저장된 대화 목록 조회"""
        try:
            if source == 'github':
                return self._list_github_conversations()
            elif source == 'gcs':
                return self._list_gcs_conversations()
            else:
                raise ValueError("지원되지 않는 소스입니다. 'github' 또는 'gcs'를 사용하세요.")
                
        except Exception as e:
            print(f"대화 목록 조회 실패: {e}")
            return []
    
    def _list_github_conversations(self) -> List[str]:
        """GitHub에서 대화 목록 조회"""
        try:
            url = f"https://api.github.com/repos/{self.github_repo}/contents/conversations"
            response = requests.get(url, headers=self.github_headers)
            
            if response.status_code == 200:
                files = response.json()
                return [f["name"].replace(".json", "") for f in files if f["name"].endswith(".json")]
            else:
                return []
                
        except Exception as e:
            print(f"GitHub 목록 조회 오류: {e}")
            return []
    
    def _list_gcs_conversations(self) -> List[str]:
        """GCS에서 대화 목록 조회"""
        try:
            blobs = self.bucket.list_blobs(prefix="conversations/")
            return [blob.name.split("/")[-1].replace(".json", "") for blob in blobs if blob.name.endswith(".json")]
            
        except Exception as e:
            print(f"GCS 목록 조회 오류: {e}")
            return []

# 사용 예제
if __name__ == "__main__":
    # 설정
    config = {
        'github_token': 'your_github_token',
        'github_repo': 'username/backup-repo',
        'gcp_project_id': 'your-gcp-project',
        'gcp_bucket_name': 'your-backup-bucket',
        'user_id': 'user123',
        'backup_interval': 30
    }
    
    # 백업 클라이언트 생성
    backup_client = ConversationBackupClient(config)
    
    # 메시지 추가
    backup_client.add_message("user", "안녕하세요!")
    backup_client.add_message("assistant", "안녕하세요! 무엇을 도와드릴까요?")
    
    # 컨텍스트 업데이트
    backup_client.update_context(
        task_plan={"goal": "테스트", "phases": []},
        current_phase=1,
        files_created=["test.txt"]
    )
    
    print(f"대화 ID: {backup_client.conversation_data['conversation_id']}")

