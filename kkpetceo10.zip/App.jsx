import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { Send, Trash2, MessageCircle, Bot, User } from 'lucide-react'
import './App.css'

function App() {
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState('')
  const [sender, setSender] = useState('사용자')
  const [loading, setLoading] = useState(false)
  const scrollAreaRef = useRef(null)

  // 메시지 로드
  const loadMessages = async () => {
    try {
      const response = await fetch('/api/messages')
      const data = await response.json()
      if (data.success) {
        setMessages(data.messages)
      }
    } catch (error) {
      console.error('메시지 로드 실패:', error)
    }
  }

  // 메시지 전송 (Manus AI 응답 포함)
  const sendMessage = async () => {
    if (!newMessage.trim()) return

    setLoading(true)
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: newMessage,
          sender: sender
        })
      })

      const data = await response.json()
      if (data.success) {
        // 사용자 메시지 추가
        if (data.user_message) {
          setMessages(prev => [...prev, data.user_message])
        }
        
        // Manus AI 응답이 있으면 추가
        if (data.ai_response) {
          setMessages(prev => [...prev, data.ai_response])
        }
        
        setNewMessage('')
      }
    } catch (error) {
      console.error('메시지 전송 실패:', error)
    } finally {
      setLoading(false)
    }
  }

  // 모든 메시지 삭제
  const clearMessages = async () => {
    try {
      const response = await fetch('/api/messages', {
        method: 'DELETE'
      })
      const data = await response.json()
      if (data.success) {
        setMessages([])
      }
    } catch (error) {
      console.error('메시지 삭제 실패:', error)
    }
  }

  // 컴포넌트 마운트 시 메시지 로드
  useEffect(() => {
    loadMessages()
  }, [])

  // 새 메시지가 추가될 때 스크롤을 맨 아래로
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollElement = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]')
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight
      }
    }
  }, [messages])

  // Enter 키로 메시지 전송
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  // 메시지 발신자에 따른 아이콘 반환
  const getSenderIcon = (senderName) => {
    if (senderName === 'Manus AI') {
      return <Bot className="w-4 h-4" />
    }
    return <User className="w-4 h-4" />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="h-[90vh] flex flex-col shadow-xl">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2 text-xl">
              <MessageCircle className="w-6 h-6" />
              Manus AI 채팅 웹 애플리케이션
            </CardTitle>
            <p className="text-blue-100 text-sm">Manus AI와 실시간으로 대화하세요</p>
          </CardHeader>
          
          <CardContent className="flex-1 flex flex-col p-0">
            {/* 메시지 영역 */}
            <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
              <div className="space-y-4">
                {messages.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    <Bot className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>안녕하세요! Manus AI입니다.</p>
                    <p>무엇을 도와드릴까요?</p>
                  </div>
                ) : (
                  messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender === 'Manus AI' ? 'justify-start' : 'justify-end'}`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                          message.sender === 'Manus AI'
                            ? 'bg-gray-100 text-gray-800 border border-gray-200'
                            : 'bg-blue-600 text-white'
                        }`}
                      >
                        <div className="flex items-center gap-2 text-xs opacity-75 mb-2">
                          {getSenderIcon(message.sender)}
                          <span>{message.sender}</span>
                        </div>
                        <div className="whitespace-pre-wrap">{message.message}</div>
                        <div className="text-xs opacity-75 mt-2">
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                  ))
                )}
                
                {/* 로딩 인디케이터 */}
                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 text-gray-800 border border-gray-200 px-4 py-3 rounded-lg max-w-xs">
                      <div className="flex items-center gap-2 text-xs opacity-75 mb-2">
                        <Bot className="w-4 h-4" />
                        <span>Manus AI</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* 입력 영역 */}
            <div className="border-t bg-white p-4">
              <div className="flex gap-2 mb-2">
                <Input
                  placeholder="이름을 입력하세요"
                  value={sender}
                  onChange={(e) => setSender(e.target.value)}
                  className="w-32"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearMessages}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                  전체 삭제
                </Button>
              </div>
              
              <div className="flex gap-2">
                <Input
                  placeholder="Manus AI에게 메시지를 보내세요..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={loading}
                  className="flex-1"
                />
                <Button
                  onClick={sendMessage}
                  disabled={loading || !newMessage.trim()}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Send className="w-4 h-4" />
                  전송
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default App

