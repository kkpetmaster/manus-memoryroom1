from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import json
import os
import openai
from datetime import datetime

chat_bp = Blueprint('chat', __name__)

# 채팅 메시지를 저장할 파일 경로
CHAT_HISTORY_FILE = os.path.join(os.path.dirname(__file__), '..', 'database', 'chat_history.json')

# OpenAI 클라이언트 초기화 (환경 변수에서 API 키와 베이스 URL 가져오기)
client = openai.OpenAI(
    api_key=os.getenv('OPENAI_API_KEY'),
    base_url=os.getenv('OPENAI_API_BASE')
)

def load_chat_history():
    """채팅 기록을 로드합니다."""
    if os.path.exists(CHAT_HISTORY_FILE):
        try:
            with open(CHAT_HISTORY_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return []
    return []

def save_chat_history(history):
    """채팅 기록을 저장합니다."""
    os.makedirs(os.path.dirname(CHAT_HISTORY_FILE), exist_ok=True)
    with open(CHAT_HISTORY_FILE, 'w', encoding='utf-8') as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

def get_manus_ai_response(user_message, chat_history):
    """Manus AI로부터 응답을 받습니다."""
    try:
        # 채팅 기록을 OpenAI 형식으로 변환
        messages = [
            {"role": "system", "content": "당신은 Manus AI입니다. 사용자와 친근하고 도움이 되는 대화를 나누세요. 한국어로 응답해주세요."}
        ]
        
        # 최근 10개의 메시지만 컨텍스트로 사용
        recent_history = chat_history[-10:] if len(chat_history) > 10 else chat_history
        
        for msg in recent_history:
            if msg['sender'] == 'Manus AI':
                messages.append({"role": "assistant", "content": msg['message']})
            else:
                messages.append({"role": "user", "content": msg['message']})
        
        # 현재 사용자 메시지 추가
        messages.append({"role": "user", "content": user_message})
        
        # OpenAI API 호출
        response = client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            max_tokens=1000,
            temperature=0.7
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        print(f"Manus AI API 호출 오류: {str(e)}")
        return "죄송합니다. 현재 응답을 생성할 수 없습니다. 잠시 후 다시 시도해주세요."

@chat_bp.route('/messages', methods=['GET'])
@cross_origin()
def get_messages():
    """모든 채팅 메시지를 반환합니다."""
    try:
        history = load_chat_history()
        return jsonify({
            'success': True,
            'messages': history
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@chat_bp.route('/messages', methods=['POST'])
@cross_origin()
def send_message():
    """새로운 채팅 메시지를 추가하고 Manus AI 응답을 생성합니다."""
    try:
        data = request.get_json()
        
        if not data or 'message' not in data or 'sender' not in data:
            return jsonify({
                'success': False,
                'error': 'message와 sender 필드가 필요합니다.'
            }), 400
        
        # 기존 기록 로드
        history = load_chat_history()
        
        # 사용자 메시지 생성 및 저장
        user_message = {
            'id': datetime.now().isoformat() + '_user',
            'message': data['message'],
            'sender': data['sender'],
            'timestamp': datetime.now().isoformat()
        }
        
        history.append(user_message)
        save_chat_history(history)
        
        # Manus AI 응답 생성 (사용자가 Manus AI가 아닌 경우에만)
        if data['sender'] != 'Manus AI':
            ai_response_text = get_manus_ai_response(data['message'], history)
            
            # Manus AI 응답 메시지 생성 및 저장
            ai_message = {
                'id': datetime.now().isoformat() + '_ai',
                'message': ai_response_text,
                'sender': 'Manus AI',
                'timestamp': datetime.now().isoformat()
            }
            
            history.append(ai_message)
            save_chat_history(history)
            
            return jsonify({
                'success': True,
                'user_message': user_message,
                'ai_response': ai_message
            })
        else:
            return jsonify({
                'success': True,
                'user_message': user_message
            })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@chat_bp.route('/messages', methods=['DELETE'])
@cross_origin()
def clear_messages():
    """모든 채팅 메시지를 삭제합니다."""
    try:
        save_chat_history([])
        return jsonify({
            'success': True,
            'message': '모든 메시지가 삭제되었습니다.'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

