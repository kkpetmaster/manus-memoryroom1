# API 연동 및 chavion.com 도메인 연결 가이드

## 1. 외부 API 연동 방안

현재 배포된 채팅 웹 애플리케이션은 자체적인 Flask 백엔드 API를 사용하여 메시지 송수신 기능을 구현하고 있습니다. 만약 외부 서비스(예: Gemini API, 다른 챗봇 API 등)와의 연동을 원하신다면, 다음과 같은 방법들을 고려할 수 있습니다.

### 1.1. Flask 백엔드에서 외부 API 호출

가장 일반적이고 권장되는 방법입니다. Flask 백엔드에서 외부 API를 호출하고, 그 결과를 프론트엔드로 전달하는 방식입니다. 이 방법은 API 키와 같은 민감한 정보를 백엔드에 안전하게 보관할 수 있으며, CORS(Cross-Origin Resource Sharing) 문제로부터 자유롭다는 장점이 있습니다.

**구현 단계:**
1.  **외부 API 클라이언트 설치:** `requests`와 같은 HTTP 클라이언트 라이브러리를 Flask 프로젝트의 가상 환경에 설치합니다.
    ```bash
    cd chat-web-backend
    source venv/bin/activate
    pip install requests
    ```
2.  **새로운 API 라우트 또는 기존 라우트 수정:** `chat-web-backend/src/routes/chat.py` 파일에 새로운 라우트를 추가하거나, 기존 메시지 전송 라우트를 수정하여 외부 API를 호출하도록 합니다.
    예시: `src/routes/chat.py` 파일에 챗봇 응답을 위한 라우트 추가
    ```python
    # ... (기존 코드)

    import requests

    @chat_bp.route("/chatbot_response", methods=["POST"])
    @cross_origin()
    def get_chatbot_response():
        user_message = request.json.get("message")
        if not user_message:
            return jsonify({"success": False, "error": "메시지가 필요합니다."}), 400

        # 외부 챗봇 API 호출 예시 (실제 API 엔드포인트와 키로 대체 필요)
        external_api_url = "https://api.external-chatbot.com/v1/chat"
        headers = {
            "Authorization": "Bearer YOUR_EXTERNAL_API_KEY",
            "Content-Type": "application/json"
        }
        payload = {
            "prompt": user_message
        }

        try:
            response = requests.post(external_api_url, headers=headers, json=payload)
            response.raise_for_status() # HTTP 오류 발생 시 예외 발생
            chatbot_reply = response.json().get("text", "") # 응답 형식에 따라 변경

            # 챗봇 응답을 채팅 기록에 추가
            new_message = {
                "id": datetime.now().isoformat(),
                "message": chatbot_reply,
                "sender": "챗봇",
                "timestamp": datetime.now().isoformat()
            }
            history = load_chat_history()
            history.append(new_message)
            save_chat_history(history)

            return jsonify({"success": True, "reply": chatbot_reply})
        except requests.exceptions.RequestException as e:
            return jsonify({"success": False, "error": f"외부 API 호출 실패: {str(e)}"}), 500

    # ... (기존 코드)
    ```
3.  **프론트엔드 수정:** `chat-web-frontend/src/App.jsx` 파일에서 사용자의 메시지를 전송할 때, 외부 API를 호출하는 백엔드 라우트로 요청을 보내도록 수정합니다.
    예시: `src/App.jsx`에서 챗봇 응답 요청
    ```javascript
    // ... (기존 코드)

    const sendMessage = async () => {
      if (!newMessage.trim()) return

      setLoading(true)
      try {
        // 사용자 메시지 전송
        const userMessageResponse = await fetch("/api/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            message: newMessage,
            sender: sender
          })
        })
        const userMessageData = await userMessageResponse.json()
        if (userMessageData.success) {
          setMessages(prev => [...prev, userMessageData.message])
          setNewMessage("")
        }

        // 챗봇 응답 요청
        const chatbotResponse = await fetch("/api/chatbot_response", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            message: newMessage
          })
        })
        const chatbotData = await chatbotResponse.json()
        if (chatbotData.success && chatbotData.reply) {
          // 챗봇 응답은 백엔드에서 이미 채팅 기록에 추가되었으므로, 여기서는 새로고침만
          loadMessages() 
        }

      } catch (error) {
        console.error("메시지/챗봇 응답 전송 실패:", error)
      } finally {
        setLoading(false)
      }
    }

    // ... (기존 코드)
    ```

### 1.2. React 프론트엔드에서 직접 외부 API 호출 (권장하지 않음)

프론트엔드에서 직접 외부 API를 호출하는 것도 가능하지만, 보안상의 이유(API 키 노출 위험)와 CORS 문제로 인해 일반적으로 권장되지 않습니다. 특히 API 키가 필요한 경우, 이 방법은 사용하지 않는 것이 좋습니다.

**구현 단계:**
1.  `chat-web-frontend/src/App.jsx` 파일에서 `fetch` 또는 `axios`와 같은 HTTP 클라이언트를 사용하여 외부 API를 직접 호출합니다.
2.  API 키와 같은 민감한 정보는 환경 변수 등을 통해 관리해야 하지만, 클라이언트 측 환경 변수는 빌드 시점에 포함되므로 완전히 안전하지 않습니다.

## 2. chavion.com 도메인 연결 가이드

현재 배포된 웹 애플리케이션은 Manus VM의 임시 도메인(`https://5001-ihhzpvrxri3nvr8g2iwsf-da9298e1.manusvm.computer`)을 사용하고 있습니다. `chavion.com`과 같은 사용자 지정 도메인을 연결하려면, GCP(Google Cloud Platform)의 로드 밸런서 또는 CDN 서비스를 활용해야 합니다.

**GCP에서 사용자 지정 도메인 연결을 위한 일반적인 단계:**

1.  **GCP 프로젝트 준비:**
    *   GCP 계정이 있어야 하며, 결제가 활성화된 프로젝트가 필요합니다.
    *   Cloud DNS, Cloud Load Balancing, Cloud Run (또는 App Engine) API가 프로젝트에서 활성화되어 있어야 합니다.

2.  **도메인 소유권 확인:**
    *   `chavion.com` 도메인의 소유권을 GCP에 확인해야 합니다. 이는 일반적으로 도메인 등록 기관의 DNS 설정에 특정 TXT 레코드를 추가하여 수행합니다.
    *   [Google Search Console](https://search.google.com/search-console/welcome)을 통해 도메인 소유권을 확인할 수 있습니다.

3.  **Cloud Run (또는 App Engine) 서비스 배포:**
    *   현재 Manus VM에 배포된 Flask 백엔드와 React 프론트엔드를 GCP Cloud Run 또는 App Engine으로 배포해야 합니다. 이전에 제공된 `interactive_terminal_web_project.zip` 파일과 `Interactive Terminal Web - GCP 배포 가이드.md`를 참고하여 GCP에 배포를 진행합니다.
    *   **Cloud Run 배포 예시 (Docker 필요):**
        *   `chat-web-backend` 디렉토리에 `Dockerfile`을 생성하여 Flask 애플리케이션을 컨테이너화합니다.
        *   `gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/chat-app-backend` 명령으로 컨테이너 이미지를 빌드하고 Container Registry에 푸시합니다.
        *   `gcloud run deploy chat-app-backend --image gcr.io/YOUR_PROJECT_ID/chat-app-backend --platform managed --region YOUR_REGION --allow-unauthenticated` 명령으로 Cloud Run에 배포합니다.

4.  **로드 밸런서 설정 (HTTPS 및 도메인 매핑):**
    *   GCP 콘솔에서 **네트워크 서비스 > 부하 분산**으로 이동하여 새 HTTP(S) 부하 분산기를 생성합니다.
    *   **프론트엔드 구성:** HTTPS를 활성화하고, `chavion.com` 도메인에 대한 SSL/TLS 인증서를 구성합니다. Google 관리형 인증서를 사용하는 것이 가장 편리합니다.
    *   **백엔드 구성:** Cloud Run 서비스(또는 App Engine 서비스)를 백엔드 서비스로 연결합니다.
    *   **호스트 및 경로 규칙:** `chavion.com`으로 들어오는 요청이 해당 백엔드 서비스로 라우팅되도록 규칙을 설정합니다.

5.  **DNS 레코드 업데이트:**
    *   도메인 등록 기관(예: GoDaddy, Namecheap 등)으로 이동하여 `chavion.com`의 DNS 설정을 수정합니다.
    *   GCP 로드 밸런서의 외부 IP 주소를 가리키도록 `A` 레코드 또는 `CNAME` 레코드를 추가합니다.
        *   `chavion.com` (루트 도메인)의 경우, 로드 밸런서의 IP 주소를 가리키는 `A` 레코드를 추가합니다.
        *   `www.chavion.com`과 같은 서브도메인의 경우, `chavion.com`을 가리키는 `CNAME` 레코드를 추가하거나, 로드 밸런서의 IP를 가리키는 `A` 레코드를 추가할 수 있습니다.
    *   DNS 변경 사항이 전파되는 데 시간이 걸릴 수 있습니다 (최대 48시간).

**참고:**
*   GCP Cloud Run은 사용자 지정 도메인 매핑 기능을 직접 제공하므로, 간단한 배포의 경우 로드 밸런서 없이 Cloud Run 자체의 사용자 지정 도메인 기능을 사용할 수도 있습니다. 하지만 로드 밸런서는 더 복잡한 트래픽 관리, CDN 통합, 여러 서비스 라우팅 등에 유용합니다.
*   정확한 단계는 GCP의 UI 및 기능 업데이트에 따라 달라질 수 있으므로, 항상 [Google Cloud 공식 문서](https://cloud.google.com/docs)를 참조하는 것이 좋습니다.

이 가이드가 `chavion.com` 도메인 연결 및 외부 API 연동에 도움이 되기를 바랍니다. 추가적인 질문이 있으시면 언제든지 문의해주세요.

