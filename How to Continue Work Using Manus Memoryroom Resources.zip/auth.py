from flask import Blueprint, request, jsonify, session
from src.models.user import db, User, Staff
from datetime import datetime
import jwt
import os

auth_bp = Blueprint('auth', __name__)

# JWT 시크릿 키 (실제 운영에서는 환경변수로 관리)
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-here')

@auth_bp.route('/login', methods=['POST'])
def login():
    """사용자 로그인"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            return jsonify({'error': '사용자명과 비밀번호를 입력해주세요.'}), 400

        # 사용자 조회
        user = User.query.filter_by(username=username).first()
        
        if not user or not user.check_password(password):
            return jsonify({'error': '잘못된 사용자명 또는 비밀번호입니다.'}), 401

        if not user.is_active:
            return jsonify({'error': '비활성화된 계정입니다.'}), 401

        # 마지막 로그인 시간 업데이트
        user.last_login = datetime.utcnow()
        db.session.commit()

        # JWT 토큰 생성
        token_payload = {
            'user_id': user.id,
            'username': user.username,
            'role': user.role,
            'exp': datetime.utcnow().timestamp() + 86400  # 24시간 후 만료
        }
        token = jwt.encode(token_payload, JWT_SECRET, algorithm='HS256')

        # 세션에 사용자 정보 저장
        session['user_id'] = user.id
        session['username'] = user.username
        session['role'] = user.role

        return jsonify({
            'message': '로그인 성공',
            'token': token,
            'user': user.to_dict()
        }), 200

    except Exception as e:
        return jsonify({'error': f'로그인 중 오류가 발생했습니다: {str(e)}'}), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    """사용자 로그아웃"""
    try:
        # 세션 클리어
        session.clear()
        return jsonify({'message': '로그아웃 되었습니다.'}), 200
    except Exception as e:
        return jsonify({'error': f'로그아웃 중 오류가 발생했습니다: {str(e)}'}), 500

@auth_bp.route('/register', methods=['POST'])
def register():
    """새 사용자 등록 (관리자만 가능)"""
    try:
        # 권한 확인
        if 'user_id' not in session:
            return jsonify({'error': '로그인이 필요합니다.'}), 401
        
        current_user = User.query.get(session['user_id'])
        if not current_user or not current_user.has_permission('manage_users'):
            return jsonify({'error': '사용자 관리 권한이 없습니다.'}), 403

        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        role = data.get('role', 'staff')

        if not username or not email or not password:
            return jsonify({'error': '모든 필드를 입력해주세요.'}), 400

        # 중복 확인
        if User.query.filter_by(username=username).first():
            return jsonify({'error': '이미 존재하는 사용자명입니다.'}), 400

        if User.query.filter_by(email=email).first():
            return jsonify({'error': '이미 존재하는 이메일입니다.'}), 400

        # 새 사용자 생성
        new_user = User(
            username=username,
            email=email,
            role=role
        )
        new_user.set_password(password)

        db.session.add(new_user)
        db.session.commit()

        return jsonify({
            'message': '사용자가 성공적으로 등록되었습니다.',
            'user': new_user.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'사용자 등록 중 오류가 발생했습니다: {str(e)}'}), 500

@auth_bp.route('/me', methods=['GET'])
def get_current_user():
    """현재 로그인한 사용자 정보 조회"""
    try:
        if 'user_id' not in session:
            return jsonify({'error': '로그인이 필요합니다.'}), 401

        user = User.query.get(session['user_id'])
        if not user:
            return jsonify({'error': '사용자를 찾을 수 없습니다.'}), 404

        return jsonify({'user': user.to_dict()}), 200

    except Exception as e:
        return jsonify({'error': f'사용자 정보 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@auth_bp.route('/change-password', methods=['POST'])
def change_password():
    """비밀번호 변경"""
    try:
        if 'user_id' not in session:
            return jsonify({'error': '로그인이 필요합니다.'}), 401

        data = request.get_json()
        current_password = data.get('current_password')
        new_password = data.get('new_password')

        if not current_password or not new_password:
            return jsonify({'error': '현재 비밀번호와 새 비밀번호를 입력해주세요.'}), 400

        user = User.query.get(session['user_id'])
        if not user:
            return jsonify({'error': '사용자를 찾을 수 없습니다.'}), 404

        if not user.check_password(current_password):
            return jsonify({'error': '현재 비밀번호가 올바르지 않습니다.'}), 400

        # 새 비밀번호 설정
        user.set_password(new_password)
        db.session.commit()

        return jsonify({'message': '비밀번호가 성공적으로 변경되었습니다.'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'비밀번호 변경 중 오류가 발생했습니다: {str(e)}'}), 500

@auth_bp.route('/users', methods=['GET'])
def get_users():
    """사용자 목록 조회 (관리자만 가능)"""
    try:
        if 'user_id' not in session:
            return jsonify({'error': '로그인이 필요합니다.'}), 401
        
        current_user = User.query.get(session['user_id'])
        if not current_user or not current_user.has_permission('manage_users'):
            return jsonify({'error': '사용자 관리 권한이 없습니다.'}), 403

        users = User.query.all()
        return jsonify({
            'users': [user.to_dict() for user in users]
        }), 200

    except Exception as e:
        return jsonify({'error': f'사용자 목록 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@auth_bp.route('/users/<int:user_id>/toggle-status', methods=['POST'])
def toggle_user_status(user_id):
    """사용자 활성화/비활성화 토글 (관리자만 가능)"""
    try:
        if 'user_id' not in session:
            return jsonify({'error': '로그인이 필요합니다.'}), 401
        
        current_user = User.query.get(session['user_id'])
        if not current_user or not current_user.has_permission('manage_users'):
            return jsonify({'error': '사용자 관리 권한이 없습니다.'}), 403

        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': '사용자를 찾을 수 없습니다.'}), 404

        # 자기 자신은 비활성화할 수 없음
        if user.id == current_user.id:
            return jsonify({'error': '자기 자신의 계정은 비활성화할 수 없습니다.'}), 400

        user.is_active = not user.is_active
        db.session.commit()

        status = '활성화' if user.is_active else '비활성화'
        return jsonify({
            'message': f'사용자가 {status}되었습니다.',
            'user': user.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'사용자 상태 변경 중 오류가 발생했습니다: {str(e)}'}), 500

