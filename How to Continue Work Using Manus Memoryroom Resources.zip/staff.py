from flask import Blueprint, request, jsonify, session
from src.models.user import db, Staff, User, Booking
from datetime import datetime

staff_bp = Blueprint('staff', __name__)

def require_login():
    """로그인 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    return None

def require_permission(permission):
    """권한 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.has_permission(permission):
        return jsonify({'error': '권한이 없습니다.'}), 403
    
    return None

@staff_bp.route('/staff', methods=['GET'])
def get_staff():
    """직원 목록 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        search = request.args.get('search', '')
        is_active = request.args.get('is_active')
        position = request.args.get('position')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))

        query = Staff.query
        
        # 활성화 상태 필터
        if is_active is not None:
            is_active_bool = is_active.lower() == 'true'
            query = query.filter(Staff.is_active == is_active_bool)
        
        # 직책 필터
        if position:
            query = query.filter(Staff.position.contains(position))
        
        # 검색 필터 (직원명, 전화번호, 이메일)
        if search:
            query = query.filter(
                Staff.name.contains(search) | 
                Staff.phone.contains(search) |
                Staff.email.contains(search)
            )

        staff_list = query.order_by(Staff.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )

        # 직원 정보에 사용자 계정 정보 추가
        staff_data = []
        for staff in staff_list.items:
            staff_dict = staff.to_dict()
            if staff.user_id:
                user = User.query.get(staff.user_id)
                if user:
                    staff_dict['username'] = user.username
                    staff_dict['role'] = user.role
                    staff_dict['user_is_active'] = user.is_active
            staff_data.append(staff_dict)

        return jsonify({
            'staff': staff_data,
            'total': staff_list.total,
            'pages': staff_list.pages,
            'current_page': page
        }), 200

    except Exception as e:
        return jsonify({'error': f'직원 목록 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@staff_bp.route('/staff', methods=['POST'])
def create_staff():
    """새 직원 등록 (관리자/매니저만 가능)"""
    auth_error = require_permission('manage_users')
    if auth_error:
        return auth_error
    
    try:
        data = request.get_json()
        
        # 필수 필드 확인
        if not data.get('name'):
            return jsonify({'error': '직원 이름은 필수 입력 항목입니다.'}), 400

        # 전화번호 중복 확인 (제공된 경우)
        if data.get('phone'):
            existing_staff = Staff.query.filter_by(phone=data['phone']).first()
            if existing_staff:
                return jsonify({'error': '이미 등록된 전화번호입니다.'}), 400

        # 이메일 중복 확인 (제공된 경우)
        if data.get('email'):
            existing_email = Staff.query.filter_by(email=data['email']).first()
            if existing_email:
                return jsonify({'error': '이미 등록된 이메일입니다.'}), 400

        # 사용자 계정 연결 확인 (제공된 경우)
        user = None
        if data.get('user_id'):
            user = User.query.get(data['user_id'])
            if not user:
                return jsonify({'error': '존재하지 않는 사용자 계정입니다.'}), 404
            
            # 이미 다른 직원과 연결된 계정인지 확인
            existing_staff_user = Staff.query.filter_by(user_id=data['user_id']).first()
            if existing_staff_user:
                return jsonify({'error': '이미 다른 직원과 연결된 사용자 계정입니다.'}), 400

        # 새 직원 생성
        new_staff = Staff(
            name=data['name'],
            phone=data.get('phone', ''),
            email=data.get('email', ''),
            position=data.get('position', ''),
            user_id=data.get('user_id'),
            is_active=data.get('is_active', True)
        )

        db.session.add(new_staff)
        db.session.commit()

        # 응답에 사용자 계정 정보 포함
        staff_dict = new_staff.to_dict()
        if user:
            staff_dict['username'] = user.username
            staff_dict['role'] = user.role
            staff_dict['user_is_active'] = user.is_active

        return jsonify({
            'message': '직원이 성공적으로 등록되었습니다.',
            'staff': staff_dict
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'직원 등록 중 오류가 발생했습니다: {str(e)}'}), 500

@staff_bp.route('/staff/<int:staff_id>', methods=['GET'])
def get_staff_detail(staff_id):
    """특정 직원 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        staff = Staff.query.get(staff_id)
        if not staff:
            return jsonify({'error': '직원을 찾을 수 없습니다.'}), 404

        # 직원의 예약 담당 이력 조회
        bookings = Booking.query.filter_by(staff_id=staff_id).order_by(Booking.booking_date.desc()).limit(10).all()

        staff_data = staff.to_dict()
        
        # 사용자 계정 정보 추가
        if staff.user_id:
            user = User.query.get(staff.user_id)
            if user:
                staff_data['username'] = user.username
                staff_data['role'] = user.role
                staff_data['user_is_active'] = user.is_active
                staff_data['last_login'] = user.last_login.isoformat() if user.last_login else None

        # 예약 통계 추가
        total_bookings = Booking.query.filter_by(staff_id=staff_id).count()
        completed_bookings = Booking.query.filter_by(staff_id=staff_id, status='completed').count()
        
        staff_data['statistics'] = {
            'total_bookings': total_bookings,
            'completed_bookings': completed_bookings,
            'completion_rate': round((completed_bookings / total_bookings * 100), 2) if total_bookings > 0 else 0
        }
        
        staff_data['recent_bookings'] = [booking.to_dict() for booking in bookings]

        return jsonify({'staff': staff_data}), 200

    except Exception as e:
        return jsonify({'error': f'직원 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@staff_bp.route('/staff/<int:staff_id>', methods=['PUT'])
def update_staff(staff_id):
    """직원 정보 수정 (관리자/매니저만 가능)"""
    auth_error = require_permission('manage_users')
    if auth_error:
        return auth_error
    
    try:
        staff = Staff.query.get(staff_id)
        if not staff:
            return jsonify({'error': '직원을 찾을 수 없습니다.'}), 404

        data = request.get_json()

        # 전화번호 중복 확인 (다른 직원과)
        if 'phone' in data and data['phone'] != staff.phone:
            existing_staff = Staff.query.filter_by(phone=data['phone']).first()
            if existing_staff:
                return jsonify({'error': '이미 등록된 전화번호입니다.'}), 400

        # 이메일 중복 확인 (다른 직원과)
        if 'email' in data and data['email'] != staff.email:
            existing_email = Staff.query.filter_by(email=data['email']).first()
            if existing_email:
                return jsonify({'error': '이미 등록된 이메일입니다.'}), 400

        # 사용자 계정 연결 변경
        if 'user_id' in data:
            if data['user_id'] and data['user_id'] != staff.user_id:
                user = User.query.get(data['user_id'])
                if not user:
                    return jsonify({'error': '존재하지 않는 사용자 계정입니다.'}), 404
                
                # 이미 다른 직원과 연결된 계정인지 확인
                existing_staff_user = Staff.query.filter_by(user_id=data['user_id']).first()
                if existing_staff_user and existing_staff_user.id != staff_id:
                    return jsonify({'error': '이미 다른 직원과 연결된 사용자 계정입니다.'}), 400
            
            staff.user_id = data['user_id']

        # 필드 업데이트
        if 'name' in data:
            staff.name = data['name']
        if 'phone' in data:
            staff.phone = data['phone']
        if 'email' in data:
            staff.email = data['email']
        if 'position' in data:
            staff.position = data['position']
        if 'is_active' in data:
            staff.is_active = data['is_active']

        db.session.commit()

        # 응답에 사용자 계정 정보 포함
        staff_dict = staff.to_dict()
        if staff.user_id:
            user = User.query.get(staff.user_id)
            if user:
                staff_dict['username'] = user.username
                staff_dict['role'] = user.role
                staff_dict['user_is_active'] = user.is_active

        return jsonify({
            'message': '직원 정보가 성공적으로 수정되었습니다.',
            'staff': staff_dict
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'직원 정보 수정 중 오류가 발생했습니다: {str(e)}'}), 500

@staff_bp.route('/staff/<int:staff_id>', methods=['DELETE'])
def delete_staff(staff_id):
    """직원 삭제 (관리자만 가능)"""
    auth_error = require_permission('delete')
    if auth_error:
        return auth_error
    
    try:
        staff = Staff.query.get(staff_id)
        if not staff:
            return jsonify({'error': '직원을 찾을 수 없습니다.'}), 404

        # 예약이 있는 직원은 삭제할 수 없음
        existing_bookings = Booking.query.filter_by(staff_id=staff_id).first()
        if existing_bookings:
            return jsonify({'error': '예약 이력이 있는 직원은 삭제할 수 없습니다. 비활성화를 권장합니다.'}), 400

        db.session.delete(staff)
        db.session.commit()

        return jsonify({'message': '직원이 성공적으로 삭제되었습니다.'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'직원 삭제 중 오류가 발생했습니다: {str(e)}'}), 500

@staff_bp.route('/staff/<int:staff_id>/toggle-status', methods=['POST'])
def toggle_staff_status(staff_id):
    """직원 활성화/비활성화 토글 (관리자/매니저만 가능)"""
    auth_error = require_permission('manage_users')
    if auth_error:
        return auth_error
    
    try:
        staff = Staff.query.get(staff_id)
        if not staff:
            return jsonify({'error': '직원을 찾을 수 없습니다.'}), 404

        staff.is_active = not staff.is_active
        db.session.commit()

        status = '활성화' if staff.is_active else '비활성화'
        return jsonify({
            'message': f'직원이 {status}되었습니다.',
            'staff': staff.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'직원 상태 변경 중 오류가 발생했습니다: {str(e)}'}), 500

@staff_bp.route('/staff/<int:staff_id>/bookings', methods=['GET'])
def get_staff_bookings(staff_id):
    """직원별 예약 이력 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        staff = Staff.query.get(staff_id)
        if not staff:
            return jsonify({'error': '직원을 찾을 수 없습니다.'}), 404

        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
        status = request.args.get('status')

        query = Booking.query.filter_by(staff_id=staff_id)
        
        if status:
            query = query.filter(Booking.status == status)

        bookings = query.order_by(
            Booking.booking_date.desc(), Booking.booking_time.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)

        return jsonify({
            'bookings': [booking.to_dict() for booking in bookings.items],
            'total': bookings.total,
            'pages': bookings.pages,
            'current_page': page,
            'staff_info': {
                'id': staff.id,
                'name': staff.name,
                'position': staff.position,
                'is_active': staff.is_active
            }
        }), 200

    except Exception as e:
        return jsonify({'error': f'예약 이력 조회 중 오류가 발생했습니다: {str(e)}'}), 500

