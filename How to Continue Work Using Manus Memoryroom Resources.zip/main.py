import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.models.payment import Payment, Revenue, SMSLog
from src.routes.user import user_bp
from src.routes.auth import auth_bp
from src.routes.booking import booking_bp
from src.routes.customer import customer_bp
from src.routes.pet import pet_bp
from src.routes.service import service_bp
from src.routes.staff import staff_bp
from src.routes.payment import payment_bp
from src.routes.revenue import revenue_bp
from src.routes.sms import sms_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# CORS 설정 - 모든 도메인에서 접근 허용
CORS(app, supports_credentials=True)

# 블루프린트 등록
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(booking_bp, url_prefix='/api')
app.register_blueprint(customer_bp, url_prefix='/api')
app.register_blueprint(pet_bp, url_prefix='/api')
app.register_blueprint(service_bp, url_prefix='/api')
app.register_blueprint(staff_bp, url_prefix='/api')
app.register_blueprint(payment_bp, url_prefix='/api')
app.register_blueprint(revenue_bp, url_prefix='/api')
app.register_blueprint(sms_bp, url_prefix='/api')

# 데이터베이스 설정
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# 데이터베이스 초기화 및 샘플 데이터 생성
with app.app_context():
    db.create_all()
    
    # 샘플 데이터 생성 (처음 실행시에만)
    from src.models.user import User, Customer, Pet, Service, Staff, Booking
    from datetime import datetime, date, time
    
    # 관리자 계정 생성
    if not User.query.filter_by(username='admin').first():
        admin_user = User(
            username='admin',
            email='admin@petshop.com',
            role='admin'
        )
        admin_user.set_password('admin123')
        db.session.add(admin_user)
        
        # 일반 직원 계정 생성
        staff_user = User(
            username='staff1',
            email='staff1@petshop.com',
            role='staff'
        )
        staff_user.set_password('staff123')
        db.session.add(staff_user)
        
        # 매니저 계정 생성
        manager_user = User(
            username='manager',
            email='manager@petshop.com',
            role='manager'
        )
        manager_user.set_password('manager123')
        db.session.add(manager_user)
        
        db.session.commit()
        
        # 직원 정보 생성
        admin_staff = Staff(
            name='관리자',
            phone='010-1234-5678',
            email='admin@petshop.com',
            position='관리자',
            user_id=admin_user.id
        )
        db.session.add(admin_staff)
        
        staff1 = Staff(
            name='김미용사',
            phone='010-2345-6789',
            email='staff1@petshop.com',
            position='미용사',
            user_id=staff_user.id
        )
        db.session.add(staff1)
        
        manager_staff = Staff(
            name='박매니저',
            phone='010-3456-7890',
            email='manager@petshop.com',
            position='매니저',
            user_id=manager_user.id
        )
        db.session.add(manager_staff)
        
        # 서비스 정보 생성
        services = [
            Service(name='기본 미용', description='기본적인 목욕 및 미용 서비스', price=30000, duration=60),
            Service(name='풀 미용', description='전체 미용 서비스 (목욕, 컷, 네일)', price=50000, duration=120),
            Service(name='목욕만', description='목욕 서비스만', price=15000, duration=30),
            Service(name='네일 컷', description='발톱 깎기', price=10000, duration=15),
            Service(name='귀 청소', description='귀 청소 서비스', price=8000, duration=10),
        ]
        
        for service in services:
            db.session.add(service)
        
        # 샘플 고객 생성
        customers = [
            Customer(name='김철수', phone='010-1111-1111', email='kim@example.com', address='서울시 강남구'),
            Customer(name='이영희', phone='010-2222-2222', email='lee@example.com', address='서울시 서초구'),
            Customer(name='박민수', phone='010-3333-3333', email='park@example.com', address='서울시 송파구'),
        ]
        
        for customer in customers:
            db.session.add(customer)
        
        db.session.commit()
        
        # 샘플 반려동물 생성
        pets = [
            Pet(name='멍멍이', breed='골든 리트리버', age=3, weight=25.5, customer_id=1),
            Pet(name='야옹이', breed='페르시안', age=2, weight=4.2, customer_id=1),
            Pet(name='초코', breed='푸들', age=5, weight=8.0, customer_id=2),
            Pet(name='밀크', breed='말티즈', age=1, weight=3.5, customer_id=3),
        ]
        
        for pet in pets:
            db.session.add(pet)
        
        db.session.commit()
        
        # 샘플 예약 생성
        bookings = [
            Booking(
                customer_id=1, pet_id=1, service_id=1, staff_id=2,
                booking_date=date.today(), booking_time=time(10, 0),
                total_price=30000, status='confirmed'
            ),
            Booking(
                customer_id=2, pet_id=3, service_id=2, staff_id=2,
                booking_date=date.today(), booking_time=time(14, 0),
                total_price=50000, status='confirmed'
            ),
        ]
        
        for booking in bookings:
            db.session.add(booking)
        
        db.session.commit()
        
        print("샘플 데이터가 생성되었습니다.")
        print("관리자 계정: admin / admin123")
        print("직원 계정: staff1 / staff123")
        print("매니저 계정: manager / manager123")

# 메인 페이지 및 정적 파일 라우트
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

