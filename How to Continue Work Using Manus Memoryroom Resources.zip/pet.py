from flask import Blueprint, request, jsonify, session
from src.models.user import db, Pet, Customer, Booking
from datetime import datetime

pet_bp = Blueprint('pet', __name__)

def require_login():
    """로그인 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    return None

@pet_bp.route('/pets', methods=['GET'])
def get_pets():
    """반려동물 목록 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        search = request.args.get('search', '')
        customer_id = request.args.get('customer_id')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))

        query = Pet.query.join(Customer)
        
        # 고객별 필터
        if customer_id:
            query = query.filter(Pet.customer_id == customer_id)
        
        # 검색 필터 (반려동물명, 품종, 고객명)
        if search:
            query = query.filter(
                Pet.name.contains(search) | 
                Pet.breed.contains(search) |
                Customer.name.contains(search)
            )

        pets = query.order_by(Pet.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )

        # 반려동물 정보에 고객 정보 추가
        pets_data = []
        for pet in pets.items:
            pet_dict = pet.to_dict()
            pet_dict['customer_name'] = pet.owner.name if pet.owner else None
            pet_dict['customer_phone'] = pet.owner.phone if pet.owner else None
            pets_data.append(pet_dict)

        return jsonify({
            'pets': pets_data,
            'total': pets.total,
            'pages': pets.pages,
            'current_page': page
        }), 200

    except Exception as e:
        return jsonify({'error': f'반려동물 목록 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@pet_bp.route('/pets', methods=['POST'])
def create_pet():
    """새 반려동물 등록"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        data = request.get_json()
        
        # 필수 필드 확인
        if not data.get('name') or not data.get('customer_id'):
            return jsonify({'error': '반려동물 이름과 고객 정보는 필수 입력 항목입니다.'}), 400

        # 고객 존재 확인
        customer = Customer.query.get(data['customer_id'])
        if not customer:
            return jsonify({'error': '존재하지 않는 고객입니다.'}), 404

        # 새 반려동물 생성
        new_pet = Pet(
            name=data['name'],
            breed=data.get('breed', ''),
            age=data.get('age'),
            weight=data.get('weight'),
            notes=data.get('notes', ''),
            customer_id=data['customer_id']
        )

        db.session.add(new_pet)
        db.session.commit()

        # 응답에 고객 정보 포함
        pet_dict = new_pet.to_dict()
        pet_dict['customer_name'] = customer.name
        pet_dict['customer_phone'] = customer.phone

        return jsonify({
            'message': '반려동물이 성공적으로 등록되었습니다.',
            'pet': pet_dict
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'반려동물 등록 중 오류가 발생했습니다: {str(e)}'}), 500

@pet_bp.route('/pets/<int:pet_id>', methods=['GET'])
def get_pet(pet_id):
    """특정 반려동물 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        pet = Pet.query.get(pet_id)
        if not pet:
            return jsonify({'error': '반려동물을 찾을 수 없습니다.'}), 404

        # 반려동물의 예약 이력도 함께 조회
        bookings = Booking.query.filter_by(pet_id=pet_id).order_by(Booking.booking_date.desc()).limit(10).all()

        pet_data = pet.to_dict()
        pet_data['customer_name'] = pet.owner.name if pet.owner else None
        pet_data['customer_phone'] = pet.owner.phone if pet.owner else None
        pet_data['customer_email'] = pet.owner.email if pet.owner else None
        pet_data['recent_bookings'] = [booking.to_dict() for booking in bookings]

        return jsonify({'pet': pet_data}), 200

    except Exception as e:
        return jsonify({'error': f'반려동물 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@pet_bp.route('/pets/<int:pet_id>', methods=['PUT'])
def update_pet(pet_id):
    """반려동물 정보 수정"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        pet = Pet.query.get(pet_id)
        if not pet:
            return jsonify({'error': '반려동물을 찾을 수 없습니다.'}), 404

        data = request.get_json()

        # 고객 변경 시 확인
        if 'customer_id' in data and data['customer_id'] != pet.customer_id:
            customer = Customer.query.get(data['customer_id'])
            if not customer:
                return jsonify({'error': '존재하지 않는 고객입니다.'}), 404
            pet.customer_id = data['customer_id']

        # 필드 업데이트
        if 'name' in data:
            pet.name = data['name']
        if 'breed' in data:
            pet.breed = data['breed']
        if 'age' in data:
            pet.age = data['age']
        if 'weight' in data:
            pet.weight = data['weight']
        if 'notes' in data:
            pet.notes = data['notes']

        db.session.commit()

        # 응답에 고객 정보 포함
        pet_dict = pet.to_dict()
        pet_dict['customer_name'] = pet.owner.name if pet.owner else None
        pet_dict['customer_phone'] = pet.owner.phone if pet.owner else None

        return jsonify({
            'message': '반려동물 정보가 성공적으로 수정되었습니다.',
            'pet': pet_dict
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'반려동물 정보 수정 중 오류가 발생했습니다: {str(e)}'}), 500

@pet_bp.route('/pets/<int:pet_id>', methods=['DELETE'])
def delete_pet(pet_id):
    """반려동물 삭제"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        pet = Pet.query.get(pet_id)
        if not pet:
            return jsonify({'error': '반려동물을 찾을 수 없습니다.'}), 404

        # 예약이 있는 반려동물은 삭제할 수 없음
        existing_bookings = Booking.query.filter_by(pet_id=pet_id).first()
        if existing_bookings:
            return jsonify({'error': '예약 이력이 있는 반려동물은 삭제할 수 없습니다.'}), 400

        db.session.delete(pet)
        db.session.commit()

        return jsonify({'message': '반려동물이 성공적으로 삭제되었습니다.'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'반려동물 삭제 중 오류가 발생했습니다: {str(e)}'}), 500

@pet_bp.route('/pets/<int:pet_id>/bookings', methods=['GET'])
def get_pet_bookings(pet_id):
    """반려동물의 예약 이력 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        pet = Pet.query.get(pet_id)
        if not pet:
            return jsonify({'error': '반려동물을 찾을 수 없습니다.'}), 404

        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))

        bookings = Booking.query.filter_by(pet_id=pet_id).order_by(
            Booking.booking_date.desc(), Booking.booking_time.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)

        return jsonify({
            'bookings': [booking.to_dict() for booking in bookings.items],
            'total': bookings.total,
            'pages': bookings.pages,
            'current_page': page,
            'pet_info': {
                'id': pet.id,
                'name': pet.name,
                'breed': pet.breed,
                'customer_name': pet.owner.name if pet.owner else None
            }
        }), 200

    except Exception as e:
        return jsonify({'error': f'예약 이력 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@pet_bp.route('/pets/<int:pet_id>/health-records', methods=['GET'])
def get_pet_health_records(pet_id):
    """반려동물의 건강 기록 조회 (향후 확장용)"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        pet = Pet.query.get(pet_id)
        if not pet:
            return jsonify({'error': '반려동물을 찾을 수 없습니다.'}), 404

        # 현재는 기본 정보만 반환 (향후 건강 기록 테이블 추가 시 확장)
        health_info = {
            'pet_id': pet.id,
            'name': pet.name,
            'breed': pet.breed,
            'age': pet.age,
            'weight': pet.weight,
            'notes': pet.notes,
            'last_visit': None,  # 향후 구현
            'vaccinations': [],  # 향후 구현
            'medical_history': []  # 향후 구현
        }

        return jsonify({'health_records': health_info}), 200

    except Exception as e:
        return jsonify({'error': f'건강 기록 조회 중 오류가 발생했습니다: {str(e)}'}), 500

