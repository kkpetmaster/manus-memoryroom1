from flask import Blueprint, request, jsonify, session
from src.models.user import db, User, Service, Staff, Customer
from src.models.payment import Revenue
from datetime import datetime, date, timedelta
from sqlalchemy import func, extract
from calendar import monthrange

revenue_bp = Blueprint('revenue', __name__)

def require_permission(permission):
    """권한 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.has_permission(permission):
        return jsonify({'error': '권한이 없습니다.'}), 403
    
    return None

@revenue_bp.route('/revenue/daily', methods=['GET'])
def get_daily_revenue():
    """일별 매출 조회"""
    auth_error = require_permission('view_reports')
    if auth_error:
        return auth_error
    
    try:
        target_date = request.args.get('date', date.today().isoformat())
        
        try:
            target_date = datetime.strptime(target_date, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': '잘못된 날짜 형식입니다. YYYY-MM-DD 형식을 사용해주세요.'}), 400

        # 일별 매출 조회
        daily_revenue = db.session.query(
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('total_count')
        ).filter(Revenue.date == target_date).first()

        # 서비스별 매출
        service_revenue = db.session.query(
            Service.name,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).join(Revenue).filter(
            Revenue.date == target_date
        ).group_by(Service.id, Service.name).all()

        # 직원별 매출
        staff_revenue = db.session.query(
            Staff.name,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).join(Revenue).filter(
            Revenue.date == target_date
        ).group_by(Staff.id, Staff.name).all()

        # 결제 방법별 매출
        payment_method_revenue = db.session.query(
            Revenue.payment_method,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).filter(
            Revenue.date == target_date
        ).group_by(Revenue.payment_method).all()

        return jsonify({
            'date': target_date.isoformat(),
            'summary': {
                'total_amount': float(daily_revenue.total_amount) if daily_revenue.total_amount else 0,
                'total_count': daily_revenue.total_count if daily_revenue.total_count else 0
            },
            'service_breakdown': [
                {
                    'service_name': item.name,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in service_revenue
            ],
            'staff_breakdown': [
                {
                    'staff_name': item.name,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in staff_revenue
            ],
            'payment_method_breakdown': [
                {
                    'method': item.payment_method,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in payment_method_revenue
            ]
        }), 200

    except Exception as e:
        return jsonify({'error': f'일별 매출 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@revenue_bp.route('/revenue/monthly', methods=['GET'])
def get_monthly_revenue():
    """월별 매출 조회"""
    auth_error = require_permission('view_reports')
    if auth_error:
        return auth_error
    
    try:
        year = int(request.args.get('year', date.today().year))
        month = int(request.args.get('month', date.today().month))

        if month < 1 or month > 12:
            return jsonify({'error': '올바른 월을 입력해주세요 (1-12).'}), 400

        # 해당 월의 첫째 날과 마지막 날
        first_day = date(year, month, 1)
        last_day = date(year, month, monthrange(year, month)[1])

        # 월별 매출 조회
        monthly_revenue = db.session.query(
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('total_count')
        ).filter(
            Revenue.date >= first_day,
            Revenue.date <= last_day
        ).first()

        # 일별 매출 추이
        daily_trend = db.session.query(
            Revenue.date,
            func.sum(Revenue.amount).label('daily_amount'),
            func.count(Revenue.id).label('daily_count')
        ).filter(
            Revenue.date >= first_day,
            Revenue.date <= last_day
        ).group_by(Revenue.date).order_by(Revenue.date).all()

        # 서비스별 월 매출
        service_monthly = db.session.query(
            Service.name,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).join(Revenue).filter(
            Revenue.date >= first_day,
            Revenue.date <= last_day
        ).group_by(Service.id, Service.name).order_by(func.sum(Revenue.amount).desc()).all()

        # 직원별 월 매출
        staff_monthly = db.session.query(
            Staff.name,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).join(Revenue).filter(
            Revenue.date >= first_day,
            Revenue.date <= last_day
        ).group_by(Staff.id, Staff.name).order_by(func.sum(Revenue.amount).desc()).all()

        return jsonify({
            'year': year,
            'month': month,
            'summary': {
                'total_amount': float(monthly_revenue.total_amount) if monthly_revenue.total_amount else 0,
                'total_count': monthly_revenue.total_count if monthly_revenue.total_count else 0,
                'average_daily': round(float(monthly_revenue.total_amount) / monthrange(year, month)[1], 2) if monthly_revenue.total_amount else 0
            },
            'daily_trend': [
                {
                    'date': item.date.isoformat(),
                    'amount': float(item.daily_amount),
                    'count': item.daily_count
                }
                for item in daily_trend
            ],
            'service_breakdown': [
                {
                    'service_name': item.name,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in service_monthly
            ],
            'staff_breakdown': [
                {
                    'staff_name': item.name,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in staff_monthly
            ]
        }), 200

    except Exception as e:
        return jsonify({'error': f'월별 매출 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@revenue_bp.route('/revenue/yearly', methods=['GET'])
def get_yearly_revenue():
    """연별 매출 조회"""
    auth_error = require_permission('view_reports')
    if auth_error:
        return auth_error
    
    try:
        year = int(request.args.get('year', date.today().year))

        # 연별 매출 조회
        yearly_revenue = db.session.query(
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('total_count')
        ).filter(
            extract('year', Revenue.date) == year
        ).first()

        # 월별 매출 추이
        monthly_trend = db.session.query(
            extract('month', Revenue.date).label('month'),
            func.sum(Revenue.amount).label('monthly_amount'),
            func.count(Revenue.id).label('monthly_count')
        ).filter(
            extract('year', Revenue.date) == year
        ).group_by(extract('month', Revenue.date)).order_by(extract('month', Revenue.date)).all()

        # 서비스별 연 매출
        service_yearly = db.session.query(
            Service.name,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).join(Revenue).filter(
            extract('year', Revenue.date) == year
        ).group_by(Service.id, Service.name).order_by(func.sum(Revenue.amount).desc()).all()

        # 직원별 연 매출
        staff_yearly = db.session.query(
            Staff.name,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).join(Revenue).filter(
            extract('year', Revenue.date) == year
        ).group_by(Staff.id, Staff.name).order_by(func.sum(Revenue.amount).desc()).all()

        return jsonify({
            'year': year,
            'summary': {
                'total_amount': float(yearly_revenue.total_amount) if yearly_revenue.total_amount else 0,
                'total_count': yearly_revenue.total_count if yearly_revenue.total_count else 0,
                'average_monthly': round(float(yearly_revenue.total_amount) / 12, 2) if yearly_revenue.total_amount else 0
            },
            'monthly_trend': [
                {
                    'month': int(item.month),
                    'amount': float(item.monthly_amount),
                    'count': item.monthly_count
                }
                for item in monthly_trend
            ],
            'service_breakdown': [
                {
                    'service_name': item.name,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in service_yearly
            ],
            'staff_breakdown': [
                {
                    'staff_name': item.name,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in staff_yearly
            ]
        }), 200

    except Exception as e:
        return jsonify({'error': f'연별 매출 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@revenue_bp.route('/revenue/range', methods=['GET'])
def get_revenue_range():
    """기간별 매출 조회"""
    auth_error = require_permission('view_reports')
    if auth_error:
        return auth_error
    
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        if not start_date or not end_date:
            return jsonify({'error': '시작 날짜와 종료 날짜를 모두 입력해주세요.'}), 400

        try:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_dt = datetime.strptime(end_date, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': '잘못된 날짜 형식입니다. YYYY-MM-DD 형식을 사용해주세요.'}), 400

        if start_dt > end_dt:
            return jsonify({'error': '시작 날짜는 종료 날짜보다 이전이어야 합니다.'}), 400

        # 기간별 매출 조회
        range_revenue = db.session.query(
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('total_count')
        ).filter(
            Revenue.date >= start_dt,
            Revenue.date <= end_dt
        ).first()

        # 일별 매출 추이
        daily_trend = db.session.query(
            Revenue.date,
            func.sum(Revenue.amount).label('daily_amount'),
            func.count(Revenue.id).label('daily_count')
        ).filter(
            Revenue.date >= start_dt,
            Revenue.date <= end_dt
        ).group_by(Revenue.date).order_by(Revenue.date).all()

        # 서비스별 기간 매출
        service_range = db.session.query(
            Service.name,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).join(Revenue).filter(
            Revenue.date >= start_dt,
            Revenue.date <= end_dt
        ).group_by(Service.id, Service.name).order_by(func.sum(Revenue.amount).desc()).all()

        # 직원별 기간 매출
        staff_range = db.session.query(
            Staff.name,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).join(Revenue).filter(
            Revenue.date >= start_dt,
            Revenue.date <= end_dt
        ).group_by(Staff.id, Staff.name).order_by(func.sum(Revenue.amount).desc()).all()

        # 고객별 기간 매출 (상위 10명)
        customer_range = db.session.query(
            Customer.name,
            func.sum(Revenue.amount).label('total_amount'),
            func.count(Revenue.id).label('count')
        ).join(Revenue).filter(
            Revenue.date >= start_dt,
            Revenue.date <= end_dt
        ).group_by(Customer.id, Customer.name).order_by(func.sum(Revenue.amount).desc()).limit(10).all()

        days_count = (end_dt - start_dt).days + 1

        return jsonify({
            'start_date': start_dt.isoformat(),
            'end_date': end_dt.isoformat(),
            'days_count': days_count,
            'summary': {
                'total_amount': float(range_revenue.total_amount) if range_revenue.total_amount else 0,
                'total_count': range_revenue.total_count if range_revenue.total_count else 0,
                'average_daily': round(float(range_revenue.total_amount) / days_count, 2) if range_revenue.total_amount else 0
            },
            'daily_trend': [
                {
                    'date': item.date.isoformat(),
                    'amount': float(item.daily_amount),
                    'count': item.daily_count
                }
                for item in daily_trend
            ],
            'service_breakdown': [
                {
                    'service_name': item.name,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in service_range
            ],
            'staff_breakdown': [
                {
                    'staff_name': item.name,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in staff_range
            ],
            'top_customers': [
                {
                    'customer_name': item.name,
                    'amount': float(item.total_amount),
                    'count': item.count
                }
                for item in customer_range
            ]
        }), 200

    except Exception as e:
        return jsonify({'error': f'기간별 매출 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@revenue_bp.route('/revenue/comparison', methods=['GET'])
def get_revenue_comparison():
    """매출 비교 분석"""
    auth_error = require_permission('view_reports')
    if auth_error:
        return auth_error
    
    try:
        comparison_type = request.args.get('type', 'monthly')  # 'monthly', 'yearly'
        
        if comparison_type == 'monthly':
            # 이번 달과 지난 달 비교
            today = date.today()
            this_month_start = date(today.year, today.month, 1)
            
            if today.month == 1:
                last_month_start = date(today.year - 1, 12, 1)
                last_month_end = date(today.year - 1, 12, 31)
            else:
                last_month_start = date(today.year, today.month - 1, 1)
                last_month_end = date(today.year, today.month - 1, monthrange(today.year, today.month - 1)[1])
            
            this_month_end = today

            # 이번 달 매출
            this_month_revenue = db.session.query(
                func.sum(Revenue.amount).label('total_amount'),
                func.count(Revenue.id).label('total_count')
            ).filter(
                Revenue.date >= this_month_start,
                Revenue.date <= this_month_end
            ).first()

            # 지난 달 매출
            last_month_revenue = db.session.query(
                func.sum(Revenue.amount).label('total_amount'),
                func.count(Revenue.id).label('total_count')
            ).filter(
                Revenue.date >= last_month_start,
                Revenue.date <= last_month_end
            ).first()

            this_amount = float(this_month_revenue.total_amount) if this_month_revenue.total_amount else 0
            last_amount = float(last_month_revenue.total_amount) if last_month_revenue.total_amount else 0
            
            growth_rate = round(((this_amount - last_amount) / last_amount * 100), 2) if last_amount > 0 else 0

            return jsonify({
                'comparison_type': 'monthly',
                'current_period': {
                    'period': f"{today.year}-{today.month:02d}",
                    'amount': this_amount,
                    'count': this_month_revenue.total_count if this_month_revenue.total_count else 0
                },
                'previous_period': {
                    'period': f"{last_month_start.year}-{last_month_start.month:02d}",
                    'amount': last_amount,
                    'count': last_month_revenue.total_count if last_month_revenue.total_count else 0
                },
                'growth_rate': growth_rate,
                'growth_amount': this_amount - last_amount
            }), 200

        elif comparison_type == 'yearly':
            # 올해와 작년 비교
            this_year = date.today().year
            last_year = this_year - 1

            # 올해 매출
            this_year_revenue = db.session.query(
                func.sum(Revenue.amount).label('total_amount'),
                func.count(Revenue.id).label('total_count')
            ).filter(
                extract('year', Revenue.date) == this_year
            ).first()

            # 작년 매출
            last_year_revenue = db.session.query(
                func.sum(Revenue.amount).label('total_amount'),
                func.count(Revenue.id).label('total_count')
            ).filter(
                extract('year', Revenue.date) == last_year
            ).first()

            this_amount = float(this_year_revenue.total_amount) if this_year_revenue.total_amount else 0
            last_amount = float(last_year_revenue.total_amount) if last_year_revenue.total_amount else 0
            
            growth_rate = round(((this_amount - last_amount) / last_amount * 100), 2) if last_amount > 0 else 0

            return jsonify({
                'comparison_type': 'yearly',
                'current_period': {
                    'period': str(this_year),
                    'amount': this_amount,
                    'count': this_year_revenue.total_count if this_year_revenue.total_count else 0
                },
                'previous_period': {
                    'period': str(last_year),
                    'amount': last_amount,
                    'count': last_year_revenue.total_count if last_year_revenue.total_count else 0
                },
                'growth_rate': growth_rate,
                'growth_amount': this_amount - last_amount
            }), 200

        else:
            return jsonify({'error': '유효한 비교 타입을 선택해주세요: monthly, yearly'}), 400

    except Exception as e:
        return jsonify({'error': f'매출 비교 분석 중 오류가 발생했습니다: {str(e)}'}), 500

