from flask import Blueprint, request, jsonify, session
from src.models.user import db, User, Booking, Customer
from src.models.payment import SMSLog
from datetime import datetime, date, timedelta
import re

sms_bp = Blueprint('sms', __name__)

def require_login():
    """로그인 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    return None

def require_permission(permission):
    """권한 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.has_permission(permission):
        return jsonify({'error': '권한이 없습니다.'}), 403
    
    return None

def validate_phone_number(phone):
    """전화번호 유효성 검사"""
    # 한국 전화번호 패턴 (010-1234-5678, 01012345678 등)
    pattern = r'^(010|011|016|017|018|019)-?\d{3,4}-?\d{4}$'
    return re.match(pattern, phone.replace('-', '').replace(' ', ''))

def format_phone_number(phone):
    """전화번호 포맷팅"""
    # 숫자만 추출
    numbers = re.sub(r'[^0-9]', '', phone)
    
    # 010-1234-5678 형태로 포맷팅
    if len(numbers) == 11 and numbers.startswith('010'):
        return f"{numbers[:3]}-{numbers[3:7]}-{numbers[7:]}"
    elif len(numbers) == 10:
        return f"{numbers[:3]}-{numbers[3:6]}-{numbers[6:]}"
    else:
        return phone

def generate_message_content(message_type, booking=None, custom_message=None):
    """메시지 내용 생성"""
    if custom_message:
        return custom_message
    
    if not booking:
        return "안녕하세요. 애견샵입니다."
    
    customer_name = booking.customer.name if booking.customer else "고객"
    pet_name = booking.pet.name if booking.pet else "반려동물"
    service_name = booking.service.name if booking.service else "서비스"
    booking_date = booking.booking_date.strftime('%Y년 %m월 %d일') if booking.booking_date else ""
    booking_time = booking.booking_time.strftime('%H시 %M분') if booking.booking_time else ""
    
    templates = {
        'booking_confirm': f"""안녕하세요, {customer_name}님.
애견샵 예약이 확정되었습니다.

📅 예약일시: {booking_date} {booking_time}
🐕 반려동물: {pet_name}
✂️ 서비스: {service_name}

예약 시간에 맞춰 방문해 주세요.
문의사항이 있으시면 언제든 연락주세요.

감사합니다.""",

        'reminder': f"""안녕하세요, {customer_name}님.
내일 애견샵 예약을 알려드립니다.

📅 예약일시: {booking_date} {booking_time}
🐕 반려동물: {pet_name}
✂️ 서비스: {service_name}

예약 시간에 맞춰 방문해 주세요.
감사합니다.""",

        'completion': f"""안녕하세요, {customer_name}님.
{pet_name}의 {service_name} 서비스가 완료되었습니다.

이용해 주셔서 감사합니다.
다음에도 저희 애견샵을 이용해 주세요.""",

        'cancellation': f"""안녕하세요, {customer_name}님.
{booking_date} {booking_time} 예약이 취소되었습니다.

📅 취소된 예약: {booking_date} {booking_time}
🐕 반려동물: {pet_name}
✂️ 서비스: {service_name}

불편을 드려 죄송합니다.
다시 예약을 원하시면 언제든 연락주세요."""
    }
    
    return templates.get(message_type, "안녕하세요. 애견샵입니다.")

def send_sms_mock(phone_number, message):
    """SMS 발송 모의 함수 (실제 SMS API 연동 시 교체)"""
    # 실제 환경에서는 SMS API (예: 네이버 클라우드, 카카오 알림톡 등) 연동
    # 현재는 모의 발송으로 처리
    try:
        # 실제 SMS API 호출 코드가 들어갈 자리
        # response = sms_api.send(phone_number, message)
        
        # 모의 성공 응답
        return {
            'success': True,
            'message_id': f"mock_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            'status': 'sent'
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'status': 'failed'
        }

@sms_bp.route('/sms/send', methods=['POST'])
def send_sms():
    """SMS 발송"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        data = request.get_json()
        
        # 필수 필드 확인
        if not data.get('phone_number') or not data.get('message'):
            return jsonify({'error': '전화번호와 메시지는 필수 입력 항목입니다.'}), 400

        phone_number = data['phone_number']
        message = data['message']
        customer_id = data.get('customer_id')
        booking_id = data.get('booking_id')
        message_type = data.get('message_type', 'manual')

        # 전화번호 유효성 검사
        if not validate_phone_number(phone_number):
            return jsonify({'error': '올바른 전화번호를 입력해주세요.'}), 400

        phone_number = format_phone_number(phone_number)

        # 고객 확인 (제공된 경우)
        customer = None
        if customer_id:
            customer = Customer.query.get(customer_id)
            if not customer:
                return jsonify({'error': '존재하지 않는 고객입니다.'}), 404

        # 예약 확인 (제공된 경우)
        booking = None
        if booking_id:
            booking = Booking.query.get(booking_id)
            if not booking:
                return jsonify({'error': '존재하지 않는 예약입니다.'}), 404
            
            # 예약에서 고객 정보 가져오기
            if not customer_id and booking.customer:
                customer = booking.customer
                customer_id = customer.id

        # SMS 발송
        sms_result = send_sms_mock(phone_number, message)

        # SMS 로그 생성
        sms_log = SMSLog(
            booking_id=booking_id,
            customer_id=customer_id,
            phone_number=phone_number,
            message_type=message_type,
            message_content=message,
            send_status='sent' if sms_result['success'] else 'failed',
            send_date=datetime.utcnow() if sms_result['success'] else None,
            error_message=sms_result.get('error') if not sms_result['success'] else None
        )

        db.session.add(sms_log)
        db.session.commit()

        if sms_result['success']:
            return jsonify({
                'message': 'SMS가 성공적으로 발송되었습니다.',
                'sms_log': sms_log.to_dict(),
                'message_id': sms_result.get('message_id')
            }), 200
        else:
            return jsonify({
                'error': f'SMS 발송에 실패했습니다: {sms_result.get("error")}',
                'sms_log': sms_log.to_dict()
            }), 500

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'SMS 발송 중 오류가 발생했습니다: {str(e)}'}), 500

@sms_bp.route('/sms/send-booking-confirm', methods=['POST'])
def send_booking_confirm():
    """예약 확인 SMS 발송"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        data = request.get_json()
        booking_id = data.get('booking_id')

        if not booking_id:
            return jsonify({'error': '예약 ID는 필수 입력 항목입니다.'}), 400

        booking = Booking.query.get(booking_id)
        if not booking:
            return jsonify({'error': '존재하지 않는 예약입니다.'}), 404

        if not booking.customer or not booking.customer.phone:
            return jsonify({'error': '고객의 전화번호가 등록되지 않았습니다.'}), 400

        # 메시지 내용 생성
        message = generate_message_content('booking_confirm', booking, data.get('custom_message'))
        phone_number = format_phone_number(booking.customer.phone)

        # SMS 발송
        sms_result = send_sms_mock(phone_number, message)

        # SMS 로그 생성
        sms_log = SMSLog(
            booking_id=booking_id,
            customer_id=booking.customer_id,
            phone_number=phone_number,
            message_type='booking_confirm',
            message_content=message,
            send_status='sent' if sms_result['success'] else 'failed',
            send_date=datetime.utcnow() if sms_result['success'] else None,
            error_message=sms_result.get('error') if not sms_result['success'] else None
        )

        db.session.add(sms_log)
        db.session.commit()

        if sms_result['success']:
            return jsonify({
                'message': '예약 확인 SMS가 성공적으로 발송되었습니다.',
                'sms_log': sms_log.to_dict()
            }), 200
        else:
            return jsonify({
                'error': f'SMS 발송에 실패했습니다: {sms_result.get("error")}',
                'sms_log': sms_log.to_dict()
            }), 500

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'예약 확인 SMS 발송 중 오류가 발생했습니다: {str(e)}'}), 500

@sms_bp.route('/sms/send-reminders', methods=['POST'])
def send_reminders():
    """리마인더 SMS 일괄 발송"""
    auth_error = require_permission('write')
    if auth_error:
        return auth_error
    
    try:
        # 내일 예약된 건들 조회
        tomorrow = date.today() + timedelta(days=1)
        bookings = Booking.query.filter(
            Booking.booking_date == tomorrow,
            Booking.status == 'confirmed'
        ).all()

        sent_count = 0
        failed_count = 0
        results = []

        for booking in bookings:
            if not booking.customer or not booking.customer.phone:
                failed_count += 1
                results.append({
                    'booking_id': booking.id,
                    'customer_name': booking.customer.name if booking.customer else None,
                    'status': 'failed',
                    'error': '전화번호가 등록되지 않음'
                })
                continue

            # 메시지 내용 생성
            message = generate_message_content('reminder', booking)
            phone_number = format_phone_number(booking.customer.phone)

            # SMS 발송
            sms_result = send_sms_mock(phone_number, message)

            # SMS 로그 생성
            sms_log = SMSLog(
                booking_id=booking.id,
                customer_id=booking.customer_id,
                phone_number=phone_number,
                message_type='reminder',
                message_content=message,
                send_status='sent' if sms_result['success'] else 'failed',
                send_date=datetime.utcnow() if sms_result['success'] else None,
                error_message=sms_result.get('error') if not sms_result['success'] else None
            )

            db.session.add(sms_log)

            if sms_result['success']:
                sent_count += 1
                results.append({
                    'booking_id': booking.id,
                    'customer_name': booking.customer.name,
                    'phone_number': phone_number,
                    'status': 'sent'
                })
            else:
                failed_count += 1
                results.append({
                    'booking_id': booking.id,
                    'customer_name': booking.customer.name,
                    'phone_number': phone_number,
                    'status': 'failed',
                    'error': sms_result.get('error')
                })

        db.session.commit()

        return jsonify({
            'message': f'리마인더 SMS 발송 완료: 성공 {sent_count}건, 실패 {failed_count}건',
            'summary': {
                'total_bookings': len(bookings),
                'sent_count': sent_count,
                'failed_count': failed_count
            },
            'results': results
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'리마인더 SMS 발송 중 오류가 발생했습니다: {str(e)}'}), 500

@sms_bp.route('/sms/logs', methods=['GET'])
def get_sms_logs():
    """SMS 발송 로그 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        customer_id = request.args.get('customer_id')
        booking_id = request.args.get('booking_id')
        message_type = request.args.get('message_type')
        send_status = request.args.get('send_status')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))

        query = SMSLog.query

        # 필터 적용
        if customer_id:
            query = query.filter(SMSLog.customer_id == customer_id)
        
        if booking_id:
            query = query.filter(SMSLog.booking_id == booking_id)
        
        if message_type:
            query = query.filter(SMSLog.message_type == message_type)
        
        if send_status:
            query = query.filter(SMSLog.send_status == send_status)
        
        if start_date:
            try:
                start_dt = datetime.strptime(start_date, '%Y-%m-%d')
                query = query.filter(SMSLog.created_at >= start_dt)
            except ValueError:
                return jsonify({'error': '잘못된 시작 날짜 형식입니다.'}), 400
        
        if end_date:
            try:
                end_dt = datetime.strptime(end_date, '%Y-%m-%d')
                query = query.filter(SMSLog.created_at <= end_dt)
            except ValueError:
                return jsonify({'error': '잘못된 종료 날짜 형식입니다.'}), 400

        sms_logs = query.order_by(SMSLog.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )

        return jsonify({
            'sms_logs': [log.to_dict() for log in sms_logs.items],
            'total': sms_logs.total,
            'pages': sms_logs.pages,
            'current_page': page
        }), 200

    except Exception as e:
        return jsonify({'error': f'SMS 로그 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@sms_bp.route('/sms/templates', methods=['GET'])
def get_sms_templates():
    """SMS 템플릿 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        templates = {
            'booking_confirm': {
                'name': '예약 확인',
                'description': '예약이 확정되었을 때 발송하는 메시지',
                'template': generate_message_content('booking_confirm')
            },
            'reminder': {
                'name': '예약 리마인더',
                'description': '예약 하루 전에 발송하는 알림 메시지',
                'template': generate_message_content('reminder')
            },
            'completion': {
                'name': '서비스 완료',
                'description': '서비스가 완료되었을 때 발송하는 메시지',
                'template': generate_message_content('completion')
            },
            'cancellation': {
                'name': '예약 취소',
                'description': '예약이 취소되었을 때 발송하는 메시지',
                'template': generate_message_content('cancellation')
            }
        }

        return jsonify({'templates': templates}), 200

    except Exception as e:
        return jsonify({'error': f'SMS 템플릿 조회 중 오류가 발생했습니다: {str(e)}'}), 500

