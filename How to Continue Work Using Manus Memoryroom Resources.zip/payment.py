from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.String(50), nullable=False)  # 'cash', 'card', 'transfer', 'mobile'
    payment_status = db.Column(db.String(20), default='pending')  # 'pending', 'completed', 'failed', 'refunded'
    transaction_id = db.Column(db.String(100))  # 외부 결제 시스템 거래 ID
    payment_date = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 관계 설정
    booking = db.relationship('Booking', backref='payments')

    def to_dict(self):
        return {
            'id': self.id,
            'booking_id': self.booking_id,
            'amount': self.amount,
            'payment_method': self.payment_method,
            'payment_status': self.payment_status,
            'transaction_id': self.transaction_id,
            'payment_date': self.payment_date.isoformat() if self.payment_date else None,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Revenue(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'))
    staff_id = db.Column(db.Integer, db.ForeignKey('staff.id'))
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'))
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'))
    amount = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.String(50))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # 관계 설정
    service = db.relationship('Service', backref='revenues')
    staff = db.relationship('Staff', backref='revenues')
    customer = db.relationship('Customer', backref='revenues')
    booking = db.relationship('Booking', backref='revenues')

    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.isoformat() if self.date else None,
            'service_id': self.service_id,
            'staff_id': self.staff_id,
            'customer_id': self.customer_id,
            'booking_id': self.booking_id,
            'amount': self.amount,
            'payment_method': self.payment_method,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'service_name': self.service.name if self.service else None,
            'staff_name': self.staff.name if self.staff else None,
            'customer_name': self.customer.name if self.customer else None
        }

class SMSLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'))
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    message_type = db.Column(db.String(50), nullable=False)  # 'booking_confirm', 'reminder', 'completion', 'cancellation'
    message_content = db.Column(db.Text, nullable=False)
    send_status = db.Column(db.String(20), default='pending')  # 'pending', 'sent', 'failed'
    send_date = db.Column(db.DateTime)
    error_message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # 관계 설정
    booking = db.relationship('Booking', backref='sms_logs')
    customer = db.relationship('Customer', backref='sms_logs')

    def to_dict(self):
        return {
            'id': self.id,
            'booking_id': self.booking_id,
            'customer_id': self.customer_id,
            'phone_number': self.phone_number,
            'message_type': self.message_type,
            'message_content': self.message_content,
            'send_status': self.send_status,
            'send_date': self.send_date.isoformat() if self.send_date else None,
            'error_message': self.error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'customer_name': self.customer.name if self.customer else None
        }

