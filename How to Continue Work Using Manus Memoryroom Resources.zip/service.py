from flask import Blueprint, request, jsonify, session
from src.models.user import db, Service, Booking, User
from datetime import datetime

service_bp = Blueprint('service', __name__)

def require_login():
    """로그인 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    return None

def require_permission(permission):
    """권한 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.has_permission(permission):
        return jsonify({'error': '권한이 없습니다.'}), 403
    
    return None

@service_bp.route('/services', methods=['GET'])
def get_services():
    """서비스 목록 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        search = request.args.get('search', '')
        is_active = request.args.get('is_active')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))

        query = Service.query
        
        # 활성화 상태 필터
        if is_active is not None:
            is_active_bool = is_active.lower() == 'true'
            query = query.filter(Service.is_active == is_active_bool)
        
        # 검색 필터 (서비스명, 설명)
        if search:
            query = query.filter(
                Service.name.contains(search) | 
                Service.description.contains(search)
            )

        services = query.order_by(Service.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )

        return jsonify({
            'services': [service.to_dict() for service in services.items],
            'total': services.total,
            'pages': services.pages,
            'current_page': page
        }), 200

    except Exception as e:
        return jsonify({'error': f'서비스 목록 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@service_bp.route('/services', methods=['POST'])
def create_service():
    """새 서비스 생성 (관리자/매니저만 가능)"""
    auth_error = require_permission('write')
    if auth_error:
        return auth_error
    
    try:
        data = request.get_json()
        
        # 필수 필드 확인
        if not data.get('name') or not data.get('price'):
            return jsonify({'error': '서비스명과 가격은 필수 입력 항목입니다.'}), 400

        # 가격 유효성 검사
        try:
            price = float(data['price'])
            if price < 0:
                return jsonify({'error': '가격은 0 이상이어야 합니다.'}), 400
        except (ValueError, TypeError):
            return jsonify({'error': '올바른 가격을 입력해주세요.'}), 400

        # 서비스명 중복 확인
        existing_service = Service.query.filter_by(name=data['name']).first()
        if existing_service:
            return jsonify({'error': '이미 존재하는 서비스명입니다.'}), 400

        # 새 서비스 생성
        new_service = Service(
            name=data['name'],
            description=data.get('description', ''),
            price=price,
            duration=data.get('duration'),
            is_active=data.get('is_active', True)
        )

        db.session.add(new_service)
        db.session.commit()

        return jsonify({
            'message': '서비스가 성공적으로 생성되었습니다.',
            'service': new_service.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'서비스 생성 중 오류가 발생했습니다: {str(e)}'}), 500

@service_bp.route('/services/<int:service_id>', methods=['GET'])
def get_service(service_id):
    """특정 서비스 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        service = Service.query.get(service_id)
        if not service:
            return jsonify({'error': '서비스를 찾을 수 없습니다.'}), 404

        # 서비스 사용 통계 추가
        total_bookings = Booking.query.filter_by(service_id=service_id).count()
        completed_bookings = Booking.query.filter_by(service_id=service_id, status='completed').count()
        
        service_data = service.to_dict()
        service_data['statistics'] = {
            'total_bookings': total_bookings,
            'completed_bookings': completed_bookings,
            'completion_rate': round((completed_bookings / total_bookings * 100), 2) if total_bookings > 0 else 0
        }

        return jsonify({'service': service_data}), 200

    except Exception as e:
        return jsonify({'error': f'서비스 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@service_bp.route('/services/<int:service_id>', methods=['PUT'])
def update_service(service_id):
    """서비스 정보 수정 (관리자/매니저만 가능)"""
    auth_error = require_permission('write')
    if auth_error:
        return auth_error
    
    try:
        service = Service.query.get(service_id)
        if not service:
            return jsonify({'error': '서비스를 찾을 수 없습니다.'}), 404

        data = request.get_json()

        # 서비스명 중복 확인 (다른 서비스와)
        if 'name' in data and data['name'] != service.name:
            existing_service = Service.query.filter_by(name=data['name']).first()
            if existing_service:
                return jsonify({'error': '이미 존재하는 서비스명입니다.'}), 400

        # 가격 유효성 검사
        if 'price' in data:
            try:
                price = float(data['price'])
                if price < 0:
                    return jsonify({'error': '가격은 0 이상이어야 합니다.'}), 400
                service.price = price
            except (ValueError, TypeError):
                return jsonify({'error': '올바른 가격을 입력해주세요.'}), 400

        # 필드 업데이트
        if 'name' in data:
            service.name = data['name']
        if 'description' in data:
            service.description = data['description']
        if 'duration' in data:
            service.duration = data['duration']
        if 'is_active' in data:
            service.is_active = data['is_active']

        db.session.commit()

        return jsonify({
            'message': '서비스 정보가 성공적으로 수정되었습니다.',
            'service': service.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'서비스 정보 수정 중 오류가 발생했습니다: {str(e)}'}), 500

@service_bp.route('/services/<int:service_id>', methods=['DELETE'])
def delete_service(service_id):
    """서비스 삭제 (관리자만 가능)"""
    auth_error = require_permission('delete')
    if auth_error:
        return auth_error
    
    try:
        service = Service.query.get(service_id)
        if not service:
            return jsonify({'error': '서비스를 찾을 수 없습니다.'}), 404

        # 예약이 있는 서비스는 삭제할 수 없음
        existing_bookings = Booking.query.filter_by(service_id=service_id).first()
        if existing_bookings:
            return jsonify({'error': '예약 이력이 있는 서비스는 삭제할 수 없습니다. 비활성화를 권장합니다.'}), 400

        db.session.delete(service)
        db.session.commit()

        return jsonify({'message': '서비스가 성공적으로 삭제되었습니다.'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'서비스 삭제 중 오류가 발생했습니다: {str(e)}'}), 500

@service_bp.route('/services/<int:service_id>/toggle-status', methods=['POST'])
def toggle_service_status(service_id):
    """서비스 활성화/비활성화 토글 (관리자/매니저만 가능)"""
    auth_error = require_permission('write')
    if auth_error:
        return auth_error
    
    try:
        service = Service.query.get(service_id)
        if not service:
            return jsonify({'error': '서비스를 찾을 수 없습니다.'}), 404

        service.is_active = not service.is_active
        db.session.commit()

        status = '활성화' if service.is_active else '비활성화'
        return jsonify({
            'message': f'서비스가 {status}되었습니다.',
            'service': service.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'서비스 상태 변경 중 오류가 발생했습니다: {str(e)}'}), 500

@service_bp.route('/services/<int:service_id>/bookings', methods=['GET'])
def get_service_bookings(service_id):
    """서비스별 예약 이력 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        service = Service.query.get(service_id)
        if not service:
            return jsonify({'error': '서비스를 찾을 수 없습니다.'}), 404

        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
        status = request.args.get('status')

        query = Booking.query.filter_by(service_id=service_id)
        
        if status:
            query = query.filter(Booking.status == status)

        bookings = query.order_by(
            Booking.booking_date.desc(), Booking.booking_time.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)

        return jsonify({
            'bookings': [booking.to_dict() for booking in bookings.items],
            'total': bookings.total,
            'pages': bookings.pages,
            'current_page': page,
            'service_info': {
                'id': service.id,
                'name': service.name,
                'price': service.price,
                'duration': service.duration
            }
        }), 200

    except Exception as e:
        return jsonify({'error': f'예약 이력 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@service_bp.route('/services/statistics', methods=['GET'])
def get_services_statistics():
    """서비스별 통계 조회 (관리자/매니저만 가능)"""
    auth_error = require_permission('view_reports')
    if auth_error:
        return auth_error
    
    try:
        services = Service.query.all()
        statistics = []
        
        for service in services:
            total_bookings = Booking.query.filter_by(service_id=service.id).count()
            completed_bookings = Booking.query.filter_by(service_id=service.id, status='completed').count()
            total_revenue = db.session.query(db.func.sum(Booking.total_price)).filter(
                Booking.service_id == service.id,
                Booking.status == 'completed'
            ).scalar() or 0
            
            statistics.append({
                'service_id': service.id,
                'service_name': service.name,
                'price': service.price,
                'is_active': service.is_active,
                'total_bookings': total_bookings,
                'completed_bookings': completed_bookings,
                'completion_rate': round((completed_bookings / total_bookings * 100), 2) if total_bookings > 0 else 0,
                'total_revenue': float(total_revenue)
            })
        
        # 인기 서비스 순으로 정렬
        statistics.sort(key=lambda x: x['total_bookings'], reverse=True)

        return jsonify({
            'statistics': statistics,
            'summary': {
                'total_services': len(services),
                'active_services': len([s for s in services if s.is_active]),
                'total_revenue': sum([s['total_revenue'] for s in statistics])
            }
        }), 200

    except Exception as e:
        return jsonify({'error': f'통계 조회 중 오류가 발생했습니다: {str(e)}'}), 500

