from flask import Blueprint, request, jsonify, session
from src.models.user import db, Customer, Pet, Booking
from datetime import datetime

customer_bp = Blueprint('customer', __name__)

def require_login():
    """로그인 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    return None

@customer_bp.route('/customers', methods=['GET'])
def get_customers():
    """고객 목록 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        search = request.args.get('search', '')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))

        query = Customer.query
        
        if search:
            query = query.filter(
                Customer.name.contains(search) | 
                Customer.phone.contains(search) |
                Customer.email.contains(search)
            )

        customers = query.order_by(Customer.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )

        return jsonify({
            'customers': [customer.to_dict() for customer in customers.items],
            'total': customers.total,
            'pages': customers.pages,
            'current_page': page
        }), 200

    except Exception as e:
        return jsonify({'error': f'고객 목록 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@customer_bp.route('/customers', methods=['POST'])
def create_customer():
    """새 고객 생성"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        data = request.get_json()
        
        # 필수 필드 확인
        if not data.get('name') or not data.get('phone'):
            return jsonify({'error': '이름과 전화번호는 필수 입력 항목입니다.'}), 400

        # 전화번호 중복 확인
        existing_customer = Customer.query.filter_by(phone=data['phone']).first()
        if existing_customer:
            return jsonify({'error': '이미 등록된 전화번호입니다.'}), 400

        # 이메일 중복 확인 (이메일이 제공된 경우)
        if data.get('email'):
            existing_email = Customer.query.filter_by(email=data['email']).first()
            if existing_email:
                return jsonify({'error': '이미 등록된 이메일입니다.'}), 400

        # 새 고객 생성
        new_customer = Customer(
            name=data['name'],
            phone=data['phone'],
            email=data.get('email', ''),
            address=data.get('address', '')
        )

        db.session.add(new_customer)
        db.session.commit()

        return jsonify({
            'message': '고객이 성공적으로 등록되었습니다.',
            'customer': new_customer.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'고객 등록 중 오류가 발생했습니다: {str(e)}'}), 500

@customer_bp.route('/customers/<int:customer_id>', methods=['GET'])
def get_customer(customer_id):
    """특정 고객 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        customer = Customer.query.get(customer_id)
        if not customer:
            return jsonify({'error': '고객을 찾을 수 없습니다.'}), 404

        # 고객의 반려동물 정보도 함께 조회
        pets = Pet.query.filter_by(customer_id=customer_id).all()
        
        # 고객의 예약 이력도 함께 조회
        bookings = Booking.query.filter_by(customer_id=customer_id).order_by(Booking.booking_date.desc()).limit(10).all()

        customer_data = customer.to_dict()
        customer_data['pets'] = [pet.to_dict() for pet in pets]
        customer_data['recent_bookings'] = [booking.to_dict() for booking in bookings]

        return jsonify({'customer': customer_data}), 200

    except Exception as e:
        return jsonify({'error': f'고객 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@customer_bp.route('/customers/<int:customer_id>', methods=['PUT'])
def update_customer(customer_id):
    """고객 정보 수정"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        customer = Customer.query.get(customer_id)
        if not customer:
            return jsonify({'error': '고객을 찾을 수 없습니다.'}), 404

        data = request.get_json()

        # 전화번호 중복 확인 (다른 고객과)
        if 'phone' in data and data['phone'] != customer.phone:
            existing_customer = Customer.query.filter_by(phone=data['phone']).first()
            if existing_customer:
                return jsonify({'error': '이미 등록된 전화번호입니다.'}), 400

        # 이메일 중복 확인 (다른 고객과)
        if 'email' in data and data['email'] != customer.email:
            existing_email = Customer.query.filter_by(email=data['email']).first()
            if existing_email:
                return jsonify({'error': '이미 등록된 이메일입니다.'}), 400

        # 필드 업데이트
        if 'name' in data:
            customer.name = data['name']
        if 'phone' in data:
            customer.phone = data['phone']
        if 'email' in data:
            customer.email = data['email']
        if 'address' in data:
            customer.address = data['address']

        db.session.commit()

        return jsonify({
            'message': '고객 정보가 성공적으로 수정되었습니다.',
            'customer': customer.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'고객 정보 수정 중 오류가 발생했습니다: {str(e)}'}), 500

@customer_bp.route('/customers/<int:customer_id>', methods=['DELETE'])
def delete_customer(customer_id):
    """고객 삭제"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        customer = Customer.query.get(customer_id)
        if not customer:
            return jsonify({'error': '고객을 찾을 수 없습니다.'}), 404

        # 예약이 있는 고객은 삭제할 수 없음
        existing_bookings = Booking.query.filter_by(customer_id=customer_id).first()
        if existing_bookings:
            return jsonify({'error': '예약 이력이 있는 고객은 삭제할 수 없습니다.'}), 400

        # 반려동물 정보도 함께 삭제
        Pet.query.filter_by(customer_id=customer_id).delete()
        
        db.session.delete(customer)
        db.session.commit()

        return jsonify({'message': '고객이 성공적으로 삭제되었습니다.'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'고객 삭제 중 오류가 발생했습니다: {str(e)}'}), 500

@customer_bp.route('/customers/<int:customer_id>/pets', methods=['GET'])
def get_customer_pets(customer_id):
    """고객의 반려동물 목록 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        customer = Customer.query.get(customer_id)
        if not customer:
            return jsonify({'error': '고객을 찾을 수 없습니다.'}), 404

        pets = Pet.query.filter_by(customer_id=customer_id).all()
        
        return jsonify({
            'pets': [pet.to_dict() for pet in pets]
        }), 200

    except Exception as e:
        return jsonify({'error': f'반려동물 목록 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@customer_bp.route('/customers/<int:customer_id>/pets', methods=['POST'])
def create_customer_pet(customer_id):
    """고객의 새 반려동물 등록"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        customer = Customer.query.get(customer_id)
        if not customer:
            return jsonify({'error': '고객을 찾을 수 없습니다.'}), 404

        data = request.get_json()
        
        if not data.get('name'):
            return jsonify({'error': '반려동물 이름은 필수 입력 항목입니다.'}), 400

        # 새 반려동물 생성
        new_pet = Pet(
            name=data['name'],
            breed=data.get('breed', ''),
            age=data.get('age'),
            weight=data.get('weight'),
            notes=data.get('notes', ''),
            customer_id=customer_id
        )

        db.session.add(new_pet)
        db.session.commit()

        return jsonify({
            'message': '반려동물이 성공적으로 등록되었습니다.',
            'pet': new_pet.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'반려동물 등록 중 오류가 발생했습니다: {str(e)}'}), 500

@customer_bp.route('/customers/<int:customer_id>/bookings', methods=['GET'])
def get_customer_bookings(customer_id):
    """고객의 예약 이력 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        customer = Customer.query.get(customer_id)
        if not customer:
            return jsonify({'error': '고객을 찾을 수 없습니다.'}), 404

        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))

        bookings = Booking.query.filter_by(customer_id=customer_id).order_by(
            Booking.booking_date.desc(), Booking.booking_time.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)

        return jsonify({
            'bookings': [booking.to_dict() for booking in bookings.items],
            'total': bookings.total,
            'pages': bookings.pages,
            'current_page': page
        }), 200

    except Exception as e:
        return jsonify({'error': f'예약 이력 조회 중 오류가 발생했습니다: {str(e)}'}), 500

