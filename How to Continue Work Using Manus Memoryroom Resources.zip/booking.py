from flask import Blueprint, request, jsonify, session
from src.models.user import db, Booking, Customer, Pet, Service, Staff
from datetime import datetime, date, time
from sqlalchemy import and_, or_

booking_bp = Blueprint('booking', __name__)

def require_login():
    """로그인 확인 데코레이터"""
    if 'user_id' not in session:
        return jsonify({'error': '로그인이 필요합니다.'}), 401
    return None

@booking_bp.route('/bookings', methods=['GET'])
def get_bookings():
    """예약 목록 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        # 쿼리 파라미터
        date_param = request.args.get('date')
        staff_param = request.args.get('staff')
        service_param = request.args.get('service')
        search_param = request.args.get('search')

        # 기본 쿼리
        query = Booking.query

        # 날짜 필터
        if date_param:
            try:
                filter_date = datetime.strptime(date_param, '%Y-%m-%d').date()
                query = query.filter(Booking.booking_date == filter_date)
            except ValueError:
                return jsonify({'error': '잘못된 날짜 형식입니다. YYYY-MM-DD 형식을 사용해주세요.'}), 400

        # 직원 필터
        if staff_param:
            query = query.filter(Booking.staff_id == staff_param)

        # 서비스 필터
        if service_param:
            query = query.filter(Booking.service_id == service_param)

        # 검색 필터 (고객명, 반려동물명)
        if search_param:
            query = query.join(Customer).join(Pet, Booking.pet_id == Pet.id, isouter=True).filter(
                or_(
                    Customer.name.contains(search_param),
                    Pet.name.contains(search_param)
                )
            )

        bookings = query.order_by(Booking.booking_date, Booking.booking_time).all()
        
        return jsonify({
            'bookings': [booking.to_dict() for booking in bookings]
        }), 200

    except Exception as e:
        return jsonify({'error': f'예약 목록 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@booking_bp.route('/bookings', methods=['POST'])
def create_booking():
    """새 예약 생성"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        data = request.get_json()
        
        # 필수 필드 확인
        required_fields = ['customer_id', 'service_id', 'booking_date', 'booking_time']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'{field}는 필수 입력 항목입니다.'}), 400

        # 날짜/시간 파싱
        try:
            booking_date = datetime.strptime(data['booking_date'], '%Y-%m-%d').date()
            booking_time = datetime.strptime(data['booking_time'], '%H:%M').time()
        except ValueError:
            return jsonify({'error': '잘못된 날짜 또는 시간 형식입니다.'}), 400

        # 고객 존재 확인
        customer = Customer.query.get(data['customer_id'])
        if not customer:
            return jsonify({'error': '존재하지 않는 고객입니다.'}), 404

        # 서비스 존재 확인
        service = Service.query.get(data['service_id'])
        if not service:
            return jsonify({'error': '존재하지 않는 서비스입니다.'}), 404

        # 반려동물 확인 (선택사항)
        pet = None
        if data.get('pet_id'):
            pet = Pet.query.get(data['pet_id'])
            if not pet or pet.customer_id != customer.id:
                return jsonify({'error': '잘못된 반려동물 정보입니다.'}), 400

        # 직원 확인 (선택사항)
        staff = None
        if data.get('staff_id'):
            staff = Staff.query.get(data['staff_id'])
            if not staff or not staff.is_active:
                return jsonify({'error': '잘못된 직원 정보입니다.'}), 400

        # 중복 예약 확인
        existing_booking = Booking.query.filter(
            and_(
                Booking.booking_date == booking_date,
                Booking.booking_time == booking_time,
                Booking.staff_id == data.get('staff_id'),
                Booking.status != 'cancelled'
            )
        ).first()

        if existing_booking:
            return jsonify({'error': '해당 시간에 이미 예약이 있습니다.'}), 400

        # 새 예약 생성
        new_booking = Booking(
            customer_id=data['customer_id'],
            pet_id=data.get('pet_id'),
            service_id=data['service_id'],
            staff_id=data.get('staff_id'),
            booking_date=booking_date,
            booking_time=booking_time,
            notes=data.get('notes', ''),
            total_price=service.price,
            status='confirmed'
        )

        db.session.add(new_booking)
        db.session.commit()

        return jsonify({
            'message': '예약이 성공적으로 생성되었습니다.',
            'booking': new_booking.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'예약 생성 중 오류가 발생했습니다: {str(e)}'}), 500

@booking_bp.route('/bookings/<int:booking_id>', methods=['GET'])
def get_booking(booking_id):
    """특정 예약 조회"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        booking = Booking.query.get(booking_id)
        if not booking:
            return jsonify({'error': '예약을 찾을 수 없습니다.'}), 404

        return jsonify({'booking': booking.to_dict()}), 200

    except Exception as e:
        return jsonify({'error': f'예약 조회 중 오류가 발생했습니다: {str(e)}'}), 500

@booking_bp.route('/bookings/<int:booking_id>', methods=['PUT'])
def update_booking(booking_id):
    """예약 수정"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        booking = Booking.query.get(booking_id)
        if not booking:
            return jsonify({'error': '예약을 찾을 수 없습니다.'}), 404

        data = request.get_json()

        # 날짜/시간 업데이트
        if 'booking_date' in data:
            try:
                booking.booking_date = datetime.strptime(data['booking_date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': '잘못된 날짜 형식입니다.'}), 400

        if 'booking_time' in data:
            try:
                booking.booking_time = datetime.strptime(data['booking_time'], '%H:%M').time()
            except ValueError:
                return jsonify({'error': '잘못된 시간 형식입니다.'}), 400

        # 기타 필드 업데이트
        if 'service_id' in data:
            service = Service.query.get(data['service_id'])
            if not service:
                return jsonify({'error': '존재하지 않는 서비스입니다.'}), 404
            booking.service_id = data['service_id']
            booking.total_price = service.price

        if 'staff_id' in data:
            if data['staff_id']:
                staff = Staff.query.get(data['staff_id'])
                if not staff or not staff.is_active:
                    return jsonify({'error': '잘못된 직원 정보입니다.'}), 400
            booking.staff_id = data['staff_id']

        if 'pet_id' in data:
            if data['pet_id']:
                pet = Pet.query.get(data['pet_id'])
                if not pet or pet.customer_id != booking.customer_id:
                    return jsonify({'error': '잘못된 반려동물 정보입니다.'}), 400
            booking.pet_id = data['pet_id']

        if 'notes' in data:
            booking.notes = data['notes']

        if 'status' in data:
            if data['status'] in ['confirmed', 'completed', 'cancelled']:
                booking.status = data['status']
            else:
                return jsonify({'error': '잘못된 상태값입니다.'}), 400

        booking.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify({
            'message': '예약이 성공적으로 수정되었습니다.',
            'booking': booking.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'예약 수정 중 오류가 발생했습니다: {str(e)}'}), 500

@booking_bp.route('/bookings/<int:booking_id>', methods=['DELETE'])
def delete_booking(booking_id):
    """예약 삭제"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        booking = Booking.query.get(booking_id)
        if not booking:
            return jsonify({'error': '예약을 찾을 수 없습니다.'}), 404

        db.session.delete(booking)
        db.session.commit()

        return jsonify({'message': '예약이 성공적으로 삭제되었습니다.'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'예약 삭제 중 오류가 발생했습니다: {str(e)}'}), 500

@booking_bp.route('/bookings/<int:booking_id>/cancel', methods=['POST'])
def cancel_booking(booking_id):
    """예약 취소"""
    auth_error = require_login()
    if auth_error:
        return auth_error
    
    try:
        booking = Booking.query.get(booking_id)
        if not booking:
            return jsonify({'error': '예약을 찾을 수 없습니다.'}), 404

        if booking.status == 'cancelled':
            return jsonify({'error': '이미 취소된 예약입니다.'}), 400

        booking.status = 'cancelled'
        booking.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify({
            'message': '예약이 취소되었습니다.',
            'booking': booking.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'예약 취소 중 오류가 발생했습니다: {str(e)}'}), 500

