# Manus Agent 실제 서버 이전 계획

## 1. 개요

본 문서는 Manus Agent를 현재의 가상 환경에서 실제 운영 서버 환경으로 이전하기 위한 상세 계획을 기술합니다. 안정적이고 효율적인 서비스 운영을 위해 필요한 서버 구성, 소프트웨어 설치, 자동화 스크립트, 그리고 보안 설정에 대한 지침을 제공합니다.

## 2. 목표

*   Manus Agent의 실제 서버 환경으로의 성공적인 이전 및 배포.
*   안정적인 서비스 운영을 위한 최적화된 서버 환경 구축.
*   보안 강화를 통한 데이터 및 서비스 보호.
*   AIIN 및 Gabriel 실행기와의 직접적인 통신 환경 구축.

## 3. 서버 환경 요구사항

Manus Agent는 Docker 컨테이너 기반으로 동작하므로, Docker 및 Docker Compose가 설치 가능한 Linux 기반 서버 환경을 권장합니다. 최소 요구사항은 다음과 같습니다.

*   **운영체제:** Ubuntu 22.04 LTS (권장) 또는 CentOS 7/8, Debian 11/12 등 Docker를 지원하는 Linux 배포판.
*   **CPU:** 2 vCPU 이상
*   **메모리:** 4GB RAM 이상
*   **저장 공간:** 20GB 이상 (로그 및 데이터 저장 공간 포함)
*   **네트워크:** 안정적인 인터넷 연결 및 고정 IP 주소 (선택 사항이나 권장)

## 4. 구성 요소별 상세 계획

### 4.1. 채팅 웹 서버 (IP/도메인)

Manus Agent는 RESTful API를 통해 외부와 통신하므로, 별도의 채팅 웹 서버가 필요합니다. 이 웹 서버는 AIIN 및 Gabriel 실행기와의 통신을 중계하고, 사용자 인터페이스를 제공할 수 있습니다. 현재 Manus Agent는 자체적으로 Flask 웹 서버를 내장하고 있으나, 실제 운영 환경에서는 Nginx와 같은 웹 서버를 리버스 프록시로 사용하여 안정성과 성능을 확보하는 것이 일반적입니다.

**계획:**

1.  **도메인 확보:** Manus Agent에 접근할 수 있는 전용 도메인 (예: `manus-agent.yourdomain.com`)을 확보합니다. 이는 AIIN 및 Gabriel 실행기에서 일관된 엔드포인트를 사용할 수 있도록 합니다.
2.  **DNS 설정:** 확보한 도메인을 실제 서버의 공인 IP 주소에 연결하도록 DNS A 레코드를 설정합니다.
3.  **Nginx 설치 및 설정:**
    *   Nginx를 설치하고, Manus Agent 컨테이너의 8080 포트로 요청을 전달하는 리버스 프록시 설정을 구성합니다.
    *   HTTP/2를 활성화하여 통신 성능을 향상시킵니다.

### 4.2. 필요한 OS/패키지 설치

선택된 운영체제에 따라 필요한 패키지를 설치합니다. Ubuntu 22.04 LTS를 기준으로 설명합니다.

**계획:**

1.  **운영체제 업데이트:** 서버 설치 후 최신 패키지로 업데이트합니다.
    ```bash
    sudo apt update && sudo apt upgrade -y
    ```
2.  **Docker 설치:** Docker 공식 문서를 참조하여 Docker Engine을 설치합니다.
    ```bash
    # Docker 설치 스크립트 예시 (공식 문서 참조)
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    newgrp docker
    ```
3.  **Docker Compose 설치:** Docker Compose V2 (docker compose)를 설치합니다.
    ```bash
    sudo apt install docker-compose-plugin -y
    ```
4.  **기타 유틸리티 설치:** `curl`, `git` 등 필요한 유틸리티를 설치합니다.
    ```bash
    sudo apt install curl git -y
    ```

### 4.3. Manus Agent 자동 실행 스크립트

서버 재부팅 시 Manus Agent 컨테이너가 자동으로 실행되도록 설정합니다. Docker Compose를 사용하면 `restart: always` 옵션을 통해 쉽게 자동 재시작을 구성할 수 있습니다.

**계획:**

1.  **Docker Compose 파일 준비:** 현재 가상 환경에서 사용 중인 `docker-compose.yml` 파일을 실제 서버로 복사합니다.
2.  **자동 재시작 설정 확인:** `docker-compose.yml` 파일 내 `manus-agent` 서비스에 `restart: always` 옵션이 설정되어 있는지 확인합니다.
3.  **서비스 시작 스크립트:** 서버 부팅 시 Docker Compose 프로젝트가 자동으로 시작되도록 systemd 서비스를 구성하거나, `cron` 작업을 활용할 수 있습니다. Docker Compose의 `restart: always` 옵션만으로도 충분한 경우가 많습니다.

### 4.4. 보안 (방화벽 / 인증 / SSL) 설정

실제 운영 환경에서는 보안이 매우 중요합니다. 외부 공격으로부터 서버와 서비스를 보호하기 위한 조치를 취해야 합니다.

**계획:**

1.  **방화벽 설정 (UFW 권장):**
    *   SSH (22/tcp), HTTP (80/tcp), HTTPS (443/tcp) 포트만 외부에서 접근 가능하도록 설정합니다.
    *   Manus Agent 컨테이너 내부 포트 (8080/tcp)는 외부에서 직접 접근할 필요 없이 Nginx를 통해서만 접근하도록 합니다.
    ```bash
    sudo ufw allow ssh
    sudo ufw allow http
    sudo ufw allow https
    sudo ufw enable
    ```
2.  **SSL/TLS 인증서 적용 (Let's Encrypt 권장):**
    *   확보한 도메인에 대해 Let's Encrypt를 사용하여 무료 SSL/TLS 인증서를 발급받습니다. Certbot을 사용하면 Nginx 설정과 연동하여 쉽게 적용할 수 있습니다.
    *   HTTPS를 통해 모든 통신이 암호화되도록 강제합니다.
3.  **인증 및 접근 제어:**
    *   Manus Agent API에 대한 접근 제어 방안을 마련합니다. API 키, OAuth2, 또는 JWT(JSON Web Token) 등을 활용하여 인증된 클라이언트만 API를 호출할 수 있도록 합니다.
    *   현재 Manus Agent 코드에는 별도의 인증 로직이 없으므로, 필요에 따라 `manus_main.py`에 인증 미들웨어를 추가해야 합니다.
4.  **SSH 보안 강화:**
    *   SSH 비밀번호 인증 대신 키 기반 인증을 사용합니다.
    *   기본 SSH 포트(22)를 변경합니다.
    *   root 계정 SSH 접속을 비활성화합니다.

## 5. 배포 및 검증 절차

1.  **서버 준비:** 위 3, 4.1, 4.2 섹션의 계획에 따라 서버를 준비합니다.
2.  **코드 복사:** Manus Agent 관련 파일 (manus-agent 디렉토리, docker-compose.yml, .env 파일 등)을 실제 서버의 적절한 위치로 복사합니다.
3.  **환경 변수 설정:** `OPENAI_API_KEY`, `OPENAI_API_BASE` 등 필요한 환경 변수를 서버에 설정합니다.
4.  **Docker Compose 실행:** 복사된 디렉토리에서 `sudo docker compose up -d` 명령을 실행하여 Manus Agent 컨테이너를 배포합니다.
5.  **테스트 및 검증:**
    *   `curl https://manus-agent.yourdomain.com` 으로 기본 웹 페이지 접속 확인.
    *   `curl https://manus-agent.yourdomain.com/api/manus/status` 로 API 상태 확인.
    *   AIIN 및 Gabriel 실행기에서 실제 서버의 Manus Agent API로 테스트 요청을 보내고 응답 확인.
    *   로그 (`/app/logs/gemini_agent.log` 또는 Docker logs)를 통해 정상 작동 여부 확인.

## 6. 향후 고려사항

*   **모니터링 및 로깅:** 실제 운영 환경에서는 Manus Agent의 성능 및 상태를 지속적으로 모니터링하고, 상세한 로그를 수집하여 문제 발생 시 신속하게 대응할 수 있는 시스템을 구축해야 합니다. Prometheus, Grafana, ELK Stack 등을 고려할 수 있습니다.
*   **백업 전략:** Manus Agent가 생성하거나 사용하는 중요한 데이터에 대한 정기적인 백업 전략을 수립합니다.
*   **CI/CD 파이프라인:** 코드 변경 시 자동으로 빌드, 테스트, 배포가 이루어지는 CI/CD 파이프라인을 구축하여 개발 및 운영 효율성을 높일 수 있습니다.

--- 

**작성자:** Manus AI
**작성일:** 2025년 7월 27일


