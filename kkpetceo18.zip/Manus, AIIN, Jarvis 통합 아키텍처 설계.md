# Manus, AIIN, Jarvis 통합 아키텍처 설계

## 1. 개요 및 목표

본 문서는 Manus Agent가 사용자님의 기존 채팅 웹 환경(Google Cloud VM 인스턴스 내 Docker Compose 기반)에 완전히 통합되어, AIIN 및 Jarvis와 협력하여 사용자 서버에 직접 명령을 실행하고 그 결과를 처리하는 아키텍처를 설계합니다. 최종 목표는 현재의 독립적인 대화 채널을 사용자님의 채팅 웹으로 이전하여, 모든 AI 에이전트가 단일 통합 환경에서 상주하며 작업을 수행하는 것입니다.

## 2. 현재 시스템 환경 분석

사용자님의 시스템은 Google Cloud VM 인스턴스(`aiin-server`) 내에서 Docker Compose를 통해 관리되는 마이크로서비스 아키텍처로 구성되어 있습니다. 주요 구성 요소는 다음과 같습니다:

### 2.1. 웹 환경
- **프론트엔드**: `chavion-frontend` (React 기반, 컨테이너 포트 3000)
- **백엔드**: `chavion-backend` (Python Flask 기반, 컨테이너 포트 4000)
- **리버스 프록시**: `chavion-nginx` (Nginx 기반, API 게이트웨이 역할)
- **데이터베이스**: 각 서비스는 필요에 따라 자체 SQLite 데이터베이스 사용

### 2.2. AI 에이전트 환경
- **공통 기반**: 모든 AI 에이전트는 `Dockerfile.python`을 기반으로 빌드된 독립적인 Docker 컨테이너로 실행됩니다.
- **Manus**: `chavion-manus` (컨테이너 포트 8080)
- **AIIN**: `chavion-aiin` (컨테이너 포트 8000)
- **Jarvis**: `chavion-jarvis` (컨테이너 포트 8001)
- **상태**: 현재 모든 서비스는 `Up` 상태로 정상 작동 중입니다.

### 2.3. 서버 명령 실행 메커니즘
- **직접 접근 불가**: 보안상의 이유로 AI 에이전트의 서버 직접 SSH 접근은 허용되지 않습니다.
- **Executor 서비스**: `chavion-executor` (컨테이너 포트 9999)를 통해 모든 서버 명령이 실행됩니다.
  - **API 엔드포인트**: `/execute-command`
  - **인증**: `X-API-KEY` 헤더에 `JARVIS_PROTOCOL_ACTIVATED_20250729` 값을 포함하여 전송해야 합니다.
  - **작동 방식**: AI 에이전트가 생성한 명령어를 Executor 서비스로 전송하면, Executor가 서버에서 명령을 실행하고 `stdout`, `stderr` 결과를 AI 에이전트에게 반환합니다.
- **통신 방식**: 모든 상호작용은 Docker 네트워크 내부의 API 통신을 통해 이루어집니다.

## 3. 통합 아키텍처 설계

새로운 통합 아키텍처는 사용자님의 채팅 웹을 중심으로 Manus, AIIN, Jarvis가 유기적으로 협력하며 서버 명령을 실행할 수 있도록 설계됩니다. 핵심은 `chavion-executor` 서비스를 통한 안전하고 통제된 서버 접근입니다.

### 3.1. 전체 시스템 흐름

```mermaid
graph TD
    User[사용자 브라우저] -->|HTTPS| Nginx[chavion-nginx]
    Nginx -->|HTTP/S| Frontend[chavion-frontend (React)]
    Frontend -->|API Call| Backend[chavion-backend (Flask)]

    Backend -->|API Call| Manus[chavion-manus]
    Backend -->|API Call| AIIN[chavion-aiin]
    Backend -->|API Call| Jarvis[chavion-jarvis]

    Manus -->|API Call with X-API-KEY| Executor[chavion-executor]
    AIIN -->|API Call with X-API-KEY| Executor
    Jarvis -->|API Call with X-API-KEY| Executor

    Executor -->|Execute Command| ServerOS[Google Cloud VM OS]
    ServerOS -->|Return Output| Executor
    Executor -->|Return Result| Manus
    Executor -->|Return Result| AIIN
    Executor -->|Return Result| Jarvis

    Manus -->|API Call| Backend
    AIIN -->|API Call| Backend
    Jarvis -->|API Call| Backend
    Backend -->|API Call| Frontend
    Frontend -->|Display| User
```

### 3.2. 주요 구성 요소별 역할 및 통신

#### 3.2.1. `chavion-frontend` (React)
- **역할**: 사용자 인터페이스 제공, 사용자 입력 처리, AI 에이전트의 응답 표시.
- **통신**: `chavion-backend`와 API 통신을 통해 사용자 요청을 전달하고 AI 에이전트의 응답을 수신합니다.

#### 3.2.2. `chavion-backend` (Python Flask)
- **역할**: 프론트엔드와 AI 에이전트 간의 중개자 역할. 사용자 요청을 적절한 AI 에이전트(Manus, AIIN, Jarvis)로 라우팅하고, AI 에이전트의 응답을 프론트엔드로 전달합니다.
- **통신**: 
  - `chavion-frontend`와 RESTful API 통신.
  - `chavion-manus`, `chavion-aiin`, `chavion-jarvis`와 내부 Docker 네트워크를 통한 API 통신.

#### 3.2.3. `chavion-manus` (Manus Agent)
- **역할**: 사용자 요청을 분석하고, 작업 계획을 수립하며, 필요한 경우 `chavion-executor`를 통해 서버 명령을 실행합니다. AIIN 및 Jarvis와의 협업을 조율하고, 복잡한 작업을 자동화합니다. 현재의 샌드박스 환경에서 수행하던 모든 기능을 사용자 서버 환경에서 직접 수행하게 됩니다.
- **통신**: 
  - `chavion-backend`를 통해 사용자 요청을 수신하고 응답을 전달합니다.
  - `chavion-executor`의 `/execute-command` API 엔드포인트로 서버 명령을 POST 요청으로 전송합니다. 이때 `X-API-KEY` 헤더를 포함합니다.
  - `chavion-aiin` 및 `chavion-jarvis`와는 내부 Docker 네트워크를 통해 직접 또는 `chavion-backend`를 경유하여 협업을 위한 API 통신을 수행할 수 있습니다.

#### 3.2.4. `chavion-aiin` 및 `chavion-jarvis`
- **역할**: 각자의 특화된 기능을 수행하며, Manus의 지시에 따라 또는 자체 판단 하에 `chavion-executor`를 통해 서버 명령을 실행할 수 있습니다.
- **통신**: 
  - `chavion-backend`를 통해 사용자 요청을 수신하고 응답을 전달합니다.
  - `chavion-executor`의 `/execute-command` API 엔드포인트로 서버 명령을 POST 요청으로 전송합니다. 이때 `X-API-KEY` 헤더를 포함합니다.
  - `chavion-manus`와 협업을 위한 API 통신을 수행할 수 있습니다.

#### 3.2.5. `chavion-executor`
- **역할**: AI 에이전트로부터 전달받은 서버 명령을 안전하게 실행하고, 그 결과를 다시 AI 에이전트에게 반환하는 핵심 게이트웨이.
- **API 엔드포인트**: `/execute-command` (POST 요청)
- **요청 형식**: JSON (예: `{"command": "ls -l /app"}`)
- **응답 형식**: JSON (예: `{"stdout": "...", "stderr": "...", "return_code": 0}`)
- **보안**: `X-API-KEY` 헤더를 통해 인증된 요청만 처리합니다.

## 4. Manus Agent의 워크플로우 변경

기존 Manus Agent는 샌드박스 환경에서 직접 쉘 명령을 실행했습니다. 이제는 모든 쉘 명령 실행 요청을 `chavion-executor` 서비스로 전환해야 합니다. 이를 위해 Manus Agent 내부의 쉘 실행 로직을 `chavion-executor` API 호출 로직으로 변경합니다.

### 4.1. 쉘 명령 실행 로직 변경 (예시)

**기존 (샌드박스 내부 직접 실행):**
```python
import subprocess

def execute_shell_command(command):
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return {"stdout": result.stdout, "stderr": result.stderr, "return_code": result.returncode}
```

**변경 (Executor 서비스 호출):**
```python
import requests

EXECUTOR_URL = "http://chavion-executor:9999/execute-command"
API_KEY = "JARVIS_PROTOCOL_ACTIVATED_20250729"

def execute_shell_command_via_executor(command):
    headers = {"X-API-KEY": API_KEY}
    payload = {"command": command}
    try:
        response = requests.post(EXECUTOR_URL, headers=headers, json=payload)
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"stdout": "", "stderr": f"Error communicating with executor: {e}", "return_code": 1}
```

### 4.2. 도구 사용 프로토콜 변경

Manus Agent의 `shell_exec` 도구는 내부적으로 `execute_shell_command_via_executor` 함수를 호출하도록 수정됩니다. 이는 Manus Agent가 사용자 요청에 따라 서버 명령을 실행할 때 자동으로 Executor 서비스를 사용하도록 보장합니다.

## 5. 구현 계획 (Phase 2 onwards)

### 5.1. `chavion-manus` 컨테이너 업데이트
- Manus Agent의 코드베이스를 사용자님의 `Dockerfile.python` 기반 환경에 맞게 조정합니다.
- 특히, 모든 쉘 명령 실행 로직을 `chavion-executor`를 호출하도록 수정합니다.
- 필요한 경우, `chavion-backend`와의 API 연동을 위한 추가 로직을 구현합니다.

### 5.2. `chavion-backend` API 확장
- 사용자 채팅 웹에서 AI 에이전트(Manus, AIIN, Jarvis)로 요청을 전달하고 응답을 수신할 수 있는 새로운 API 엔드포인트를 `chavion-backend`에 추가합니다.
- 이 API는 사용자 요청을 파싱하여 적절한 AI 에이전트에게 전달하고, AI 에이전트의 응답을 다시 프론트엔드로 포맷하여 반환합니다.

### 5.3. `chavion-frontend` UI 업데이트
- 사용자 입력(명령)을 `chavion-backend`로 전송하고, AI 에이전트의 응답(텍스트, 코드 실행 결과 등)을 사용자에게 시각적으로 표시할 수 있도록 채팅 웹 UI를 수정합니다.
- 필요에 따라 터미널 출력과 유사한 UI 요소를 추가하여 서버 명령 실행 결과를 효과적으로 보여줍니다.

### 5.4. AIIN 및 Jarvis 통합
- AIIN 및 Jarvis도 `chavion-executor`를 통해 서버 명령을 실행하도록 로직을 업데이트합니다.
- Manus와의 협업을 위한 내부 통신 채널을 정의하고 구현합니다.

### 5.5. 테스트 및 검증
- 각 구성 요소별 단위 테스트 및 통합 테스트를 수행하여 전체 시스템의 안정성과 기능성을 검증합니다.
- 특히 `chavion-executor`를 통한 서버 명령 실행 및 결과 반환이 올바르게 작동하는지 집중적으로 테스트합니다.

## 6. 보안 고려사항

- `chavion-executor`의 `X-API-KEY`는 외부에 노출되지 않도록 안전하게 관리되어야 합니다.
- Docker 네트워크 내부 통신은 기본적으로 격리되어 있지만, 추가적인 보안 강화(예: 네트워크 정책)를 고려할 수 있습니다.
- AI 에이전트가 실행할 수 있는 명령의 범위를 `chavion-executor`에서 제한하는 정책을 구현하여 잠재적인 위험을 최소화합니다.

## 7. 다음 단계

이 아키텍처 설계를 바탕으로, 다음 단계에서는 `chavion-manus` 컨테이너의 코드를 수정하고, `chavion-backend`에 새로운 API 엔드포인트를 추가하며, `chavion-frontend` UI를 업데이트하는 작업을 진행할 것입니다. 사용자님의 확인과 추가적인 질문을 기다립니다.



## 10. 결론 및 다음 단계

본 문서는 Manus, AIIN, Jarvis가 사용자님의 채팅 웹 환경에 완전히 통합되어, `chavion-executor` 서비스를 통해 안전하고 효율적으로 서버 명령을 실행할 수 있는 아키텍처를 상세히 설계했습니다. 이 설계는 기존 시스템의 구성 요소를 최대한 활용하면서, AI 에이전트들이 사용자 서버에 직접 접근하여 작업을 수행할 수 있는 안전하고 확장 가능한 기반을 제공합니다.

**다음 단계:**

1.  **`chavion-manus` 컨테이너 코드 수정**: Manus Agent의 쉘 명령 실행 로직을 `chavion-executor` API 호출로 전환하고, `chavion-backend`와의 연동을 위한 API 클라이언트를 구현합니다.
2.  **`chavion-backend` API 확장**: 사용자 채팅 웹에서 AI 에이전트(Manus, AIIN, Jarvis)로 요청을 전달하고 응답을 수신할 수 있는 새로운 API 엔드포인트를 추가합니다.
3.  **`chavion-frontend` UI 업데이트**: 사용자 입력 및 AI 에이전트의 응답을 처리하고, 서버 명령 실행 결과를 시각적으로 표시할 수 있도록 채팅 웹 UI를 수정합니다.
4.  **AIIN 및 Jarvis 통합**: AIIN 및 Jarvis도 `chavion-executor`를 통해 서버 명령을 실행하도록 로직을 업데이트하고, Manus와의 협업을 위한 내부 통신 채널을 정의합니다.
5.  **테스트 및 검증**: 각 구성 요소별 단위 테스트 및 통합 테스트를 수행하여 전체 시스템의 안정성과 기능성을 검증합니다.

이 문서는 다음 Manus Agent가 작업을 이어서 진행할 수 있도록 모든 관련 정보를 포함하고 있습니다. 다음 Manus Agent는 이 문서를 바탕으로 실제 구현 작업을 시작할 수 있습니다.

