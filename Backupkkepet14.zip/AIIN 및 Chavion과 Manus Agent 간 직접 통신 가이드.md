# AIIN 및 Chavion과 Manus Agent 간 직접 통신 가이드

## 1. 개요

본 문서는 AIIN 및 Chavion 실행기가 Manus Agent와 중계 서버 없이 직접 통신할 수 있도록 DNS/도메인 설정 및 엔드포인트 변경에 대한 상세 가이드를 제공합니다. 이를 통해 통신 효율성을 높이고, 잠재적인 지연 시간을 줄이며, 보안을 강화할 수 있습니다.

## 2. 목표

*   AIIN 및 Chavion 실행기가 Manus Agent의 API 엔드포인트에 직접 접근할 수 있도록 네트워크 환경을 구성합니다.
*   안정적이고 안전한 직접 통신 채널을 구축합니다.
*   기존 중계 시스템의 의존성을 제거하여 시스템 복잡성을 줄입니다.

## 3. DNS/도메인 설정 가이드

Manus Agent에 직접 접근하기 위해서는 고정된 공인 IP 주소 또는 도메인 이름이 필요합니다. 도메인 이름을 사용하는 것이 관리 및 보안 측면에서 더 유리하며, SSL/TLS 인증서 적용이 용이합니다.

### 3.1. 도메인 이름 선택 및 등록

먼저 Manus Agent에 할당할 도메인 이름을 선택하고 도메인 등록 기관(예: GoDaddy, Namecheap, Gabia 등)을 통해 등록해야 합니다. 도메인 이름은 Manus Agent의 역할을 명확히 나타내면서 기억하기 쉬운 것으로 선택하는 것이 좋습니다. 예를 들어, `manus-agent.yourcompany.com`과 같은 서브도메인을 사용할 수 있습니다.

### 3.2. DNS 레코드 설정

도메인 등록 후, 해당 도메인 이름이 Manus Agent가 실행될 실제 서버의 공인 IP 주소를 가리키도록 DNS(Domain Name System) 레코드를 설정해야 합니다. 일반적으로 A 레코드(Address Record)를 사용하여 도메인 이름을 IPv4 주소에 매핑합니다.

**설정 절차:**

1.  **도메인 관리 페이지 접속:** 도메인을 등록한 기관의 웹사이트에 로그인하여 DNS 관리 또는 도메인 설정 페이지로 이동합니다.
2.  **A 레코드 추가:** 새로운 A 레코드를 추가하거나 기존 레코드를 수정합니다.
    *   **호스트 (Host):** Manus Agent에 사용할 서브도메인 (예: `manus-agent` 또는 `@` (루트 도메인)).
    *   **값 (Value) / IP 주소:** Manus Agent가 배포될 실제 서버의 공인 IP 주소.
    *   **TTL (Time To Live):** DNS 변경 사항이 전파되는 시간. 일반적으로 300초(5분)에서 3600초(1시간) 사이로 설정합니다. 초기 설정 시에는 짧은 TTL을 사용하여 변경 사항을 빠르게 반영하는 것이 유리합니다.

**예시 (manus-agent.yourcompany.com 도메인에 대한 A 레코드 설정):**

| 유형 | 호스트 | 값 (IP 주소) | TTL |
| :--- | :--- | :--- | :--- |
| A    | `manus-agent` | `[실제 서버의 공인 IP 주소]` | `3600` |

**DNS 전파:** DNS 레코드 변경 후, 전 세계 DNS 서버에 변경 사항이 전파되는 데 시간이 걸릴 수 있습니다 (최대 48시간). `dig` 또는 `nslookup`과 같은 도구를 사용하여 DNS 전파 상태를 확인할 수 있습니다.

```bash
dig manus-agent.yourcompany.com
```

### 3.3. SSL/TLS 인증서 적용 (HTTPS 통신)

보안 통신을 위해 HTTPS를 사용하는 것이 필수적입니다. HTTPS는 통신 내용을 암호화하여 중간자 공격(Man-in-the-Middle Attack)으로부터 보호합니다. Let's Encrypt와 같은 무료 인증 기관을 통해 SSL/TLS 인증서를 발급받고 웹 서버(Nginx 등)에 적용하는 것을 권장합니다.

**설정 절차 (Nginx 및 Certbot 사용 예시):**

1.  **Nginx 설치:** 실제 서버에 Nginx 웹 서버를 설치합니다. (자세한 내용은 이전 `Manus Agent 실제 서버 이전 계획` 문서 참조)
2.  **Certbot 설치:** Let's Encrypt 인증서 발급 및 갱신을 자동화하는 Certbot을 설치합니다.
    ```bash
    sudo snap install --classic certbot
    sudo ln -s /snap/bin/certbot /usr/bin/certbot
    ```
3.  **Nginx 설정 파일 생성/수정:** Manus Agent로의 리버스 프록시 설정을 포함하는 Nginx 설정 파일을 생성하거나 수정합니다. 이 파일은 `manus-agent.yourcompany.com` 도메인으로 들어오는 요청을 Manus Agent 컨테이너의 8080 포트로 전달하도록 구성됩니다.
    ```nginx
    # /etc/nginx/sites-available/manus-agent.conf
    server {
        listen 80;
        server_name manus-agent.yourcompany.com;

        location / {
            proxy_pass http://localhost:8080; # 또는 Docker 내부 IP
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
    ```
4.  **Nginx 설정 활성화:**
    ```bash
    sudo ln -s /etc/nginx/sites-available/manus-agent.conf /etc/nginx/sites-enabled/
    sudo nginx -t
    sudo systemctl restart nginx
    ```
5.  **SSL 인증서 발급:** Certbot을 사용하여 SSL 인증서를 발급받고 Nginx에 자동으로 적용합니다.
    ```bash
    sudo certbot --nginx -d manus-agent.yourcompany.com
    ```
    이 명령은 Certbot이 Nginx 설정을 자동으로 수정하여 HTTPS를 활성화하고, HTTP 요청을 HTTPS로 리다이렉트하도록 합니다.
6.  **자동 갱신 확인:** Certbot은 기본적으로 인증서 자동 갱신을 위한 cron 작업을 설정합니다. 다음 명령으로 테스트할 수 있습니다.
    ```bash
    sudo certbot renew --dry-run
    ```

이러한 DNS 및 SSL/TLS 설정을 통해 AIIN 및 Chavion 실행기는 `https://manus-agent.yourcompany.com`과 같은 도메인 이름을 사용하여 Manus Agent에 안전하게 직접 접근할 수 있게 됩니다.

--- 

**작성자:** Manus AI
**작성일:** 2025년 7월 27일




## 4. AIIN/Chavion 엔드포인트 변경 가이드

AIIN 및 Chavion 실행기가 Manus Agent와 직접 통신하려면, 현재 중계 서버를 통해 통신하도록 설정된 엔드포인트를 Manus Agent의 새로운 직접 통신 엔드포인트로 변경해야 합니다. 이 과정은 AIIN 및 Chavion의 구현 방식에 따라 다를 수 있으므로, 각 시스템의 설정 파일을 수정하거나 API 호출 시 엔드포인트를 변경하는 방식으로 진행됩니다.

### 4.1. AIIN 엔드포인트 변경

AIIN 시스템이 Manus Agent와 통신하는 방식에 따라 엔드포인트 변경 방법이 달라집니다. 일반적으로 AIIN의 설정 파일(예: `config.json`, `settings.py`, 환경 변수 등)에 Manus Agent의 API 엔드포인트가 명시되어 있을 것입니다. 해당 설정을 찾아 변경해야 합니다.

**변경 절차:**

1.  **AIIN 설정 파일 식별:** AIIN 프로젝트 내에서 Manus Agent의 API 엔드포인트가 정의된 설정 파일 또는 코드 부분을 찾습니다. 이는 다음과 같은 형태일 수 있습니다:
    *   `MANUS_AGENT_API_URL = "https://old-relay-server.com/api/manus"`
    *   `"manus_endpoint": "http://localhost:8080/api/manus"`
    *   환경 변수 (`MANUS_AGENT_URL`)

2.  **엔드포인트 URL 업데이트:** 식별된 설정 파일 또는 환경 변수의 값을 Manus Agent의 새로운 직접 통신 엔드포인트 URL로 변경합니다. 이 URL은 `https://manus-agent.yourcompany.com` (도메인 사용 시) 또는 `https://[실제 서버의 공인 IP]:[포트]` (IP 주소 사용 시) 형태가 될 것입니다.

    **예시 (도메인 사용 시):**
    ```
    MANUS_AGENT_API_URL = "https://manus-agent.yourcompany.com/api/manus"
    ```

    **예시 (IP 주소 사용 시):**
    ```
    MANUS_AGENT_API_URL = "https://[실제 서버의 공인 IP]:8080/api/manus"
    ```
    *주의: 실제 서버에 SSL/TLS가 적용되어 HTTPS를 사용한다면, 엔드포인트 URL도 `https`로 시작해야 합니다. 포트 번호는 Nginx와 같은 리버스 프록시를 사용하는 경우 생략될 수 있습니다 (기본 HTTPS 포트 443 사용 시).* [1]

3.  **AIIN 재시작:** 변경된 설정이 적용되도록 AIIN 시스템을 재시작합니다. 이는 AIIN 애플리케이션 서버, 서비스 또는 관련 프로세스를 다시 시작하는 것을 의미합니다.

### 4.2. Gabriel 실행기 구성 업데이트

Gabriel 실행기는 AIIN과 유사하게 Manus Agent의 API 엔드포인트를 호출하는 부분이 있을 것입니다. Gabriel 실행기의 스크립트 또는 설정 내에서 해당 엔드포인트를 찾아 업데이트해야 합니다.

**변경 절차:**

1.  **Gabriel 실행기 스크립트/설정 식별:** Gabriel 실행기가 Manus Agent API를 호출하는 스크립트 파일(예: Python 스크립트, 쉘 스크립트 등) 또는 설정 파일을 찾습니다.

2.  **엔드포인트 URL 업데이트:** 스크립트 내에서 Manus Agent API를 호출하는 URL을 새로운 직접 통신 엔드포인트로 변경합니다.

    **예시 (Python 스크립트 내):**
    ```python
    # 변경 전
    # manus_agent_url = "https://old-relay-server.com/api/manus/execute"

    # 변경 후
    manus_agent_url = "https://manus-agent.yourcompany.com/api/manus/execute"
    ```

    **예시 (curl 명령 사용 시):**
    ```bash
    # 변경 전
    # curl -X POST https://old-relay-server.com/api/manus/execute ...

    # 변경 후
    curl -X POST https://manus-agent.yourcompany.com/api/manus/execute ...
    ```

3.  **Gabriel 실행기 재배포/재실행:** 변경된 스크립트나 설정이 적용되도록 Gabriel 실행기를 재배포하거나 재실행합니다.

### 4.3. 통신 테스트 및 검증

엔드포인트 변경 후, AIIN 및 Gabriel 실행기가 Manus Agent와 정상적으로 직접 통신하는지 철저히 테스트해야 합니다.

**테스트 절차:**

1.  **기본 연결 테스트:** AIIN 또는 Gabriel에서 Manus Agent의 상태 엔드포인트 (`/api/manus/status`)를 호출하여 응답을 확인합니다.
    ```bash
    curl https://manus-agent.yourcompany.com/api/manus/status
    ```
    정상적인 응답은 Manus Agent의 현재 상태를 포함하는 JSON 객체여야 합니다.

2.  **명령 실행 테스트:** AIIN 또는 Gabriel에서 `execute_shell` 명령을 사용하여 간단한 쉘 명령을 Manus Agent에 전송하고, 그 결과를 확인합니다.
    ```bash
    curl -X POST https://manus-agent.yourcompany.com/api/manus/execute \
      -H "Content-Type: application/json" \
      -d '{"command":"execute_shell","params":{"script":"echo Hello from AIIN"}}'
    ```
    응답으로 `{"stdout":"Hello from AIIN\n", ...}`와 같은 결과가 반환되는지 확인합니다.

3.  **로그 확인:** Manus Agent가 실행되는 실제 서버에서 Docker 로그를 확인하여 AIIN 및 Gabriel로부터의 요청이 정상적으로 수신되고 처리되는지 모니터링합니다.
    ```bash
    sudo docker logs manus-agent
    ```

이러한 단계를 통해 AIIN 및 Chavion 실행기가 중계 서버 없이 Manus Agent와 직접 통신하는 환경을 성공적으로 구축할 수 있습니다.

## 5. 참고 자료

[1] Flask 공식 문서: [https://flask.palletsprojects.com/en/3.0.x/](https://flask.palletsprojects.com/en/3.0.x/)

--- 

**작성자:** Manus AI
**작성일:** 2025년 7월 27일


