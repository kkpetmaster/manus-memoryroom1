from flask import Blueprint, request, jsonify
import requests
import logging

manus_agent_bp = Blueprint('manus_agent', __name__)

# Manus Agent 컨테이너 URL
MANUS_AGENT_URL = "http://localhost:8080"

logger = logging.getLogger(__name__)

@manus_agent_bp.route('/api/manus/status', methods=['GET'])
def get_manus_status():
    """Manus Agent 상태 확인"""
    try:
        response = requests.get(f"{MANUS_AGENT_URL}/api/manus/status", timeout=10)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        logger.error(f"Manus Agent 연결 실패: {str(e)}")
        return jsonify({"error": "Manus Agent에 연결할 수 없습니다"}), 500

@manus_agent_bp.route('/api/manus/execute', methods=['POST'])
def execute_manus_command():
    """Manus Agent 명령 실행"""
    try:
        data = request.get_json()
        response = requests.post(
            f"{MANUS_AGENT_URL}/api/manus/execute",
            json=data,
            timeout=30
        )
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        logger.error(f"Manus Agent 명령 실행 실패: {str(e)}")
        return jsonify({"error": "명령 실행에 실패했습니다"}), 500

@manus_agent_bp.route('/api/manus/history', methods=['GET'])
def get_manus_history():
    """Manus Agent 히스토리 조회"""
    try:
        response = requests.get(f"{MANUS_AGENT_URL}/api/manus/history", timeout=10)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        logger.error(f"Manus Agent 히스토리 조회 실패: {str(e)}")
        return jsonify({"error": "히스토리를 가져올 수 없습니다"}), 500

@manus_agent_bp.route('/api/manus/chat', methods=['POST'])
def chat_with_manus():
    """Manus Agent와 채팅"""
    try:
        data = request.get_json()
        user_message = data.get('message', '')
        
        # 사용자 메시지를 Manus Agent 명령으로 변환
        command_data = {
            "command": "execute_shell",
            "params": {
                "script": f"echo 'User: {user_message}'"
            }
        }
        
        response = requests.post(
            f"{MANUS_AGENT_URL}/api/manus/execute",
            json=command_data,
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            return jsonify({
                "response": f"Manus Agent: {result.get('stdout', '응답을 받을 수 없습니다')}",
                "status": "success"
            })
        else:
            return jsonify({
                "response": "Manus Agent가 응답하지 않습니다",
                "status": "error"
            }), 500
            
    except requests.exceptions.RequestException as e:
        logger.error(f"Manus Agent 채팅 실패: {str(e)}")
        return jsonify({
            "response": "Manus Agent에 연결할 수 없습니다",
            "status": "error"
        }), 500

