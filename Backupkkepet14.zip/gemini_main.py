#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import logging
import subprocess
import threading
import time
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/app/logs/gemini_agent.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

class GeminiAgent:
    def __init__(self):
        self.status = "active"
        self.last_command = None
        self.command_history = []
        
    def execute_command(self, command, params=None):
        """명령어 실행"""
        try:
            logger.info(f"Executing command: {command} with params: {params}")
            
            # 명령어 히스토리에 추가
            self.last_command = {
                "command": command,
                "params": params,
                "timestamp": datetime.now().isoformat(),
                "status": "executing"
            }
            self.command_history.append(self.last_command)
            
            # 실제 명령어 실행 로직
            if command == "deploy_service":
                result = self._deploy_service(params)
            elif command == "run_automation":
                result = self._run_automation(params)
            elif command == "check_status":
                result = self._check_status()
            elif command == "execute_shell":
                result = self._execute_shell(params.get("script", ""))
            else:
                result = {"error": f"Unknown command: {command}"}
            
            # 결과 업데이트
            self.last_command["status"] = "completed"
            self.last_command["result"] = result
            
            logger.info(f"Command executed successfully: {result}")
            return result
            
        except Exception as e:
            error_msg = f"Error executing command {command}: {str(e)}"
            logger.error(error_msg)
            
            if self.last_command:
                self.last_command["status"] = "error"
                self.last_command["error"] = error_msg
            
            return {"error": error_msg}
    
    def _deploy_service(self, params):
        """서비스 배포"""
        service_name = params.get("service_name", "unknown")
        logger.info(f"Deploying service: {service_name}")
        
        # 실제 배포 로직 구현
        # 여기서는 시뮬레이션
        time.sleep(2)  # 배포 시간 시뮬레이션
        
        return {
            "status": "deployed",
            "service_name": service_name,
            "deployment_time": datetime.now().isoformat()
        }
    
    def _run_automation(self, params):
        """자동화 작업 실행"""
        task_name = params.get("task_name", "unknown")
        logger.info(f"Running automation task: {task_name}")
        
        # 자동화 작업 로직
        time.sleep(1)  # 작업 시간 시뮬레이션
        
        return {
            "status": "completed",
            "task_name": task_name,
            "completion_time": datetime.now().isoformat()
        }
    
    def _check_status(self):
        """상태 확인"""
        return {
            "agent_status": self.status,
            "last_command": self.last_command,
            "command_count": len(self.command_history),
            "uptime": datetime.now().isoformat()
        }
    
    def _execute_shell(self, script):
        """쉘 스크립트 실행"""
        try:
            result = subprocess.run(
                script,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {"error": "Script execution timeout"}
        except Exception as e:
            return {"error": str(e)}

# Gemini Agent 인스턴스 생성
gemini_agent = GeminiAgent()

@app.route('/api/gemini/status', methods=['GET'])
def get_status():
    """상태 확인 엔드포인트"""
    return jsonify(gemini_agent._check_status())

@app.route('/api/gemini/execute', methods=['POST'])
def execute_command():
    """명령어 실행 엔드포인트"""
    try:
        data = request.get_json()
        command = data.get('command')
        params = data.get('params', {})
        
        if not command:
            return jsonify({"error": "Command is required"}), 400
        
        result = gemini_agent.execute_command(command, params)
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error in execute_command endpoint: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/gemini/history', methods=['GET'])
def get_history():
    """명령어 히스토리 조회"""
    return jsonify({
        "history": gemini_agent.command_history,
        "total_commands": len(gemini_agent.command_history)
    })

@app.route('/health', methods=['GET'])
def health_check():
    """헬스 체크"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat()
    })

if __name__ == '__main__':
    logger.info("Starting Gemini Agent...")
    app.run(host='0.0.0.0', port=8080, debug=False)

