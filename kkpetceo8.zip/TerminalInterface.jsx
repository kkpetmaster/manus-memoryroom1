import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Terminal, Play, Trash2, Download, Upload, AlertTriangle, CheckCircle } from 'lucide-react'

const TerminalInterface = ({ apiBaseUrl, sessionId }) => {
  const [terminalHistory, setTerminalHistory] = useState([])
  const [terminalInput, setTerminalInput] = useState('')
  const [currentDirectory, setCurrentDirectory] = useState('~')
  const [isExecuting, setIsExecuting] = useState(false)
  const terminalEndRef = useRef(null)

  const scrollToBottom = () => {
    terminalEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [terminalHistory])

  useEffect(() => {
    // 초기 환영 메시지
    setTerminalHistory([{
      id: 'welcome',
      type: 'system',
      content: 'Interactive Terminal Web - Ready',
      timestamp: new Date().toLocaleTimeString()
    }])
  }, [])

  const executeCommand = async () => {
    if (!terminalInput.trim() || isExecuting) return

    const commandEntry = {
      id: Date.now(),
      type: 'command',
      content: terminalInput,
      directory: currentDirectory,
      timestamp: new Date().toLocaleTimeString()
    }

    setTerminalHistory(prev => [...prev, commandEntry])
    const command = terminalInput
    setTerminalInput('')
    setIsExecuting(true)

    try {
      const response = await fetch(`${apiBaseUrl}/terminal/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          command: command,
          session_id: sessionId
        })
      })

      const data = await response.json()

      const resultEntry = {
        id: Date.now() + 1,
        type: 'result',
        success: data.success,
        output: data.output,
        error: data.error,
        directory: data.directory,
        timestamp: new Date().toLocaleTimeString(),
        returnCode: data.return_code
      }

      setTerminalHistory(prev => [...prev, resultEntry])
      
      if (data.directory) {
        setCurrentDirectory(data.directory)
      }
    } catch (error) {
      const errorEntry = {
        id: Date.now() + 1,
        type: 'error',
        content: `네트워크 오류: ${error.message}`,
        timestamp: new Date().toLocaleTimeString()
      }
      setTerminalHistory(prev => [...prev, errorEntry])
    } finally {
      setIsExecuting(false)
    }
  }

  const clearTerminal = () => {
    setTerminalHistory([{
      id: Date.now(),
      type: 'system',
      content: 'Terminal cleared',
      timestamp: new Date().toLocaleTimeString()
    }])
  }

  const quickCommands = [
    { label: 'List Files', command: 'ls -la' },
    { label: 'Current Dir', command: 'pwd' },
    { label: 'Disk Usage', command: 'df -h' },
    { label: 'Memory Info', command: 'free -h' },
    { label: 'Process List', command: 'ps aux' },
    { label: 'System Info', command: 'uname -a' }
  ]

  const executeQuickCommand = (command) => {
    setTerminalInput(command)
  }

  const downloadHistory = () => {
    const historyText = terminalHistory
      .filter(entry => entry.type !== 'system')
      .map(entry => {
        if (entry.type === 'command') {
          return `[${entry.timestamp}] ${entry.directory} $ ${entry.content}`
        } else if (entry.type === 'result') {
          let result = ''
          if (entry.output) result += entry.output
          if (entry.error) result += `ERROR: ${entry.error}`
          return result
        }
        return entry.content
      })
      .join('\n')

    const blob = new Blob([historyText], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `terminal-history-${new Date().toISOString().slice(0, 19)}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="flex flex-col h-full">
      {/* 헤더 */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <Terminal className="h-6 w-6 text-green-400" />
          <div>
            <h3 className="font-semibold">Terminal</h3>
            <p className="text-xs text-gray-400">Interactive Shell</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="text-xs">
            {currentDirectory}
          </Badge>
          <Button variant="ghost" size="sm" onClick={downloadHistory}>
            <Download className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={clearTerminal}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* 빠른 명령어 */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex flex-wrap gap-2">
          {quickCommands.map((cmd, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              onClick={() => executeQuickCommand(cmd.command)}
              className="text-xs"
            >
              {cmd.label}
            </Button>
          ))}
        </div>
      </div>

      {/* 터미널 출력 */}
      <ScrollArea className="flex-1 p-4">
        <div className="font-mono text-sm bg-black rounded-lg p-4 min-h-full">
          {terminalHistory.map((entry) => (
            <div key={entry.id} className="mb-2">
              {entry.type === 'command' && (
                <div className="flex items-center">
                  <span className="text-blue-400">{entry.directory}</span>
                  <span className="text-white mx-2">$</span>
                  <span className="text-green-400">{entry.content}</span>
                  <span className="text-gray-500 ml-auto text-xs">{entry.timestamp}</span>
                </div>
              )}
              
              {entry.type === 'result' && (
                <div className="ml-4 mb-2">
                  {entry.output && (
                    <pre className="whitespace-pre-wrap text-gray-300 mb-1">
                      {entry.output}
                    </pre>
                  )}
                  {entry.error && (
                    <pre className="whitespace-pre-wrap text-red-400 mb-1">
                      {entry.error}
                    </pre>
                  )}
                  <div className="flex items-center space-x-2 text-xs text-gray-500">
                    {entry.success ? (
                      <CheckCircle className="h-3 w-3 text-green-400" />
                    ) : (
                      <AlertTriangle className="h-3 w-3 text-red-400" />
                    )}
                    <span>Exit code: {entry.returnCode || 0}</span>
                    <span>{entry.timestamp}</span>
                  </div>
                </div>
              )}
              
              {entry.type === 'error' && (
                <div className="text-red-400 ml-4">
                  <AlertTriangle className="h-4 w-4 inline mr-2" />
                  {entry.content}
                </div>
              )}
              
              {entry.type === 'system' && (
                <div className="text-yellow-400 text-center py-2">
                  {entry.content}
                </div>
              )}
            </div>
          ))}
          
          {isExecuting && (
            <div className="flex items-center text-yellow-400">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-yellow-400 mr-2"></div>
              <span>Executing...</span>
            </div>
          )}
          
          <div ref={terminalEndRef} />
        </div>
      </ScrollArea>

      {/* 입력 영역 */}
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-2 bg-black rounded-lg p-3 font-mono">
          <span className="text-blue-400">{currentDirectory}</span>
          <span className="text-white">$</span>
          <Input
            value={terminalInput}
            onChange={(e) => setTerminalInput(e.target.value)}
            placeholder="명령어를 입력하세요..."
            onKeyPress={(e) => e.key === 'Enter' && executeCommand()}
            className="bg-transparent border-none text-green-400 p-0 focus:ring-0 flex-1"
            disabled={isExecuting}
          />
          <Button 
            onClick={executeCommand} 
            disabled={isExecuting || !terminalInput.trim()}
            size="sm"
          >
            {isExecuting ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            ) : (
              <Play className="h-4 w-4" />
            )}
          </Button>
        </div>
        
        <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
          <span>Enter로 실행, Ctrl+C로 중단</span>
          <span>{terminalHistory.filter(h => h.type === 'command').length} 명령어 실행됨</span>
        </div>
      </div>
    </div>
  )
}

export default TerminalInterface

