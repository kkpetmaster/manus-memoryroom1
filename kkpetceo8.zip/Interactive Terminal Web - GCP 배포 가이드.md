# Interactive Terminal Web - GCP 배포 가이드

**작성자**: Manus AI  
**작성일**: 2025년 7월 16일  
**버전**: 1.0  

## 개요

본 문서는 Interactive Terminal Web 애플리케이션을 Google Cloud Platform(GCP)에 배포하는 과정을 상세히 설명합니다. 이 애플리케이션은 Manus AI와 실시간으로 대화하며 실제 서버 환경에서 터미널 명령어를 실행할 수 있는 혁신적인 웹 플랫폼입니다.

### 애플리케이션 특징

Interactive Terminal Web은 다음과 같은 핵심 기능을 제공합니다:

- **Manus AI 통합**: 실시간 AI 어시스턴트와의 대화형 인터페이스
- **실제 터미널 실행**: 가상이 아닌 실제 서버 환경에서의 명령어 실행
- **시스템 모니터링**: CPU, 메모리, 디스크, 네트워크 상태 실시간 모니터링
- **보안 강화**: 명령어 실행 권한 관리 및 세션 기반 보안
- **반응형 UI**: 데스크톱과 모바일 환경 모두 지원

이러한 기능들은 개발자, 시스템 관리자, DevOps 엔지니어들에게 강력한 도구를 제공하며, 특히 원격 서버 관리와 AI 기반 자동화 작업에 매우 유용합니다.




## 시스템 요구사항

### 최소 하드웨어 요구사항

Interactive Terminal Web을 안정적으로 운영하기 위해서는 다음과 같은 최소 하드웨어 사양이 필요합니다:

**CPU**: 최소 2 vCPU (권장 4 vCPU 이상)  
**메모리**: 최소 4GB RAM (권장 8GB 이상)  
**스토리지**: 최소 20GB SSD (권장 50GB 이상)  
**네트워크**: 최소 1Gbps 대역폭

이러한 요구사항은 애플리케이션의 특성상 실제 터미널 명령어를 실행하고 AI 모델과의 통신을 처리해야 하기 때문입니다. 특히 메모리 요구사항이 높은 이유는 Node.js 기반의 React 애플리케이션과 Python Flask 백엔드가 동시에 실행되며, 시스템 모니터링 기능이 지속적으로 시스템 리소스를 수집하기 때문입니다.

### 권장 GCP 인스턴스 타입

Google Cloud Platform에서는 다음과 같은 인스턴스 타입을 권장합니다:

**개발/테스트 환경**: e2-standard-2 (2 vCPU, 8GB RAM)  
**프로덕션 환경**: e2-standard-4 (4 vCPU, 16GB RAM)  
**고성능 환경**: c2-standard-4 (4 vCPU, 16GB RAM, 고성능 CPU)

e2 시리즈는 비용 효율적이면서도 안정적인 성능을 제공하므로 대부분의 사용 사례에 적합합니다. c2 시리즈는 CPU 집약적인 작업이 많은 경우에 권장되며, 특히 복잡한 터미널 명령어를 자주 실행하거나 AI 모델과의 통신이 빈번한 환경에서 유용합니다.

### 운영체제 및 소프트웨어 요구사항

**운영체제**: Ubuntu 22.04 LTS (권장) 또는 Ubuntu 20.04 LTS  
**Node.js**: 버전 20.x 이상  
**Python**: 버전 3.11 이상  
**Nginx**: 최신 안정 버전  
**Git**: 최신 버전

Ubuntu 22.04 LTS를 권장하는 이유는 장기 지원(Long Term Support)이 제공되며, 최신 보안 패치와 안정성이 보장되기 때문입니다. 또한 본 애플리케이션의 개발과 테스트가 Ubuntu 22.04 환경에서 이루어졌으므로 호환성 문제를 최소화할 수 있습니다.

### 네트워크 및 보안 요구사항

**방화벽 포트**: 80 (HTTP), 443 (HTTPS), 22 (SSH)  
**SSL/TLS**: Let's Encrypt 또는 상용 SSL 인증서  
**도메인**: 사용자 정의 도메인 (선택사항)

보안은 특히 중요한 고려사항입니다. 이 애플리케이션은 실제 서버에서 터미널 명령어를 실행할 수 있는 기능을 제공하므로, 적절한 보안 조치 없이는 심각한 보안 위험을 초래할 수 있습니다. 따라서 HTTPS 사용은 필수이며, 강력한 인증 메커니즘과 명령어 실행 권한 제한이 반드시 구현되어야 합니다.


## GCP 환경 설정

### 1. GCP 프로젝트 생성 및 설정

Google Cloud Platform에서 새로운 프로젝트를 생성하는 것부터 시작합니다. 이는 모든 리소스를 체계적으로 관리하고 비용을 추적하는 데 필수적입니다.

먼저 [Google Cloud Console](https://console.cloud.google.com)에 접속하여 새 프로젝트를 생성합니다. 프로젝트 이름은 "interactive-terminal-web" 또는 이와 유사한 의미 있는 이름으로 설정하는 것이 좋습니다. 프로젝트 ID는 전역적으로 고유해야 하므로, 조직명이나 개인 식별자를 포함하여 중복을 방지해야 합니다.

프로젝트 생성 후에는 필요한 API를 활성화해야 합니다. 다음 API들이 필수적으로 활성화되어야 합니다:

**Compute Engine API**: 가상 머신 인스턴스 생성 및 관리를 위해 필요합니다. 이 API 없이는 VM 인스턴스를 생성할 수 없으므로 가장 먼저 활성화해야 합니다.

**Cloud DNS API**: 사용자 정의 도메인을 사용할 경우 DNS 관리를 위해 필요합니다. 도메인 기반 접근을 계획하고 있다면 반드시 활성화해야 합니다.

**Cloud Storage API**: 애플리케이션 파일 저장 및 백업을 위해 사용됩니다. 특히 사용자가 업로드하는 파일이나 시스템 로그를 저장하는 데 유용합니다.

**Identity and Access Management (IAM) API**: 사용자 권한 관리 및 서비스 계정 관리를 위해 필요합니다. 보안이 중요한 이 애플리케이션에서는 필수적인 API입니다.

### 2. 서비스 계정 생성 및 권한 설정

서비스 계정은 애플리케이션이 GCP 리소스에 안전하게 접근할 수 있도록 하는 중요한 보안 메커니즘입니다. Interactive Terminal Web 애플리케이션을 위한 전용 서비스 계정을 생성해야 합니다.

IAM 및 관리자 콘솔에서 새 서비스 계정을 생성합니다. 서비스 계정 이름은 "interactive-terminal-service" 또는 이와 유사한 명확한 이름으로 설정합니다. 이 서비스 계정에는 다음과 같은 최소 권한이 부여되어야 합니다:

**Compute Engine Instance Admin (v1)**: VM 인스턴스의 생성, 수정, 삭제 권한을 제공합니다. 이는 애플리케이션이 필요에 따라 추가 인스턴스를 생성하거나 기존 인스턴스를 관리할 수 있게 합니다.

**Storage Object Admin**: Cloud Storage 버킷에 대한 읽기/쓰기 권한을 제공합니다. 사용자 파일 업로드, 로그 저장, 백업 등의 기능을 위해 필요합니다.

**Monitoring Metric Writer**: 시스템 모니터링 데이터를 Cloud Monitoring에 전송하기 위한 권한입니다. 애플리케이션의 시스템 모니터링 기능이 정상적으로 작동하려면 필수적입니다.

**Logging Writer**: 애플리케이션 로그를 Cloud Logging에 전송하기 위한 권한입니다. 디버깅과 모니터링을 위해 중요합니다.

서비스 계정 키를 JSON 형식으로 다운로드하여 안전한 위치에 저장해야 합니다. 이 키 파일은 애플리케이션이 GCP 서비스에 인증할 때 사용되므로 절대 공개되어서는 안 됩니다.

### 3. VPC 네트워크 구성

Virtual Private Cloud(VPC) 네트워크는 애플리케이션의 네트워크 보안과 성능에 직접적인 영향을 미치는 중요한 구성 요소입니다. 기본 VPC를 사용할 수도 있지만, 보안과 관리의 편의성을 위해 전용 VPC를 생성하는 것을 강력히 권장합니다.

새 VPC 네트워크를 생성할 때는 다음과 같은 설정을 고려해야 합니다:

**서브넷 모드**: 커스텀 모드를 선택하여 IP 주소 범위를 직접 제어할 수 있도록 합니다. 이는 향후 네트워크 확장이나 다른 서비스와의 통합 시 유연성을 제공합니다.

**IP 주소 범위**: 일반적으로 10.0.0.0/16 또는 192.168.0.0/16과 같은 사설 IP 범위를 사용합니다. 조직 내 다른 네트워크와의 충돌을 방지하기 위해 신중히 선택해야 합니다.

**방화벽 규칙**: 기본적으로 모든 트래픽을 차단하고 필요한 포트만 선택적으로 열어야 합니다. Interactive Terminal Web의 경우 다음 포트들이 필요합니다:
- 포트 22 (SSH): 서버 관리를 위한 SSH 접근
- 포트 80 (HTTP): 웹 애플리케이션 접근 (HTTPS로 리다이렉트)
- 포트 443 (HTTPS): 보안 웹 애플리케이션 접근
- 포트 5000 (내부): Flask 백엔드 API (내부 통신용)
- 포트 5173 (개발): React 개발 서버 (개발 환경에서만)

### 4. 외부 IP 주소 예약

정적 외부 IP 주소를 예약하는 것은 도메인 연결과 SSL 인증서 설정을 위해 필수적입니다. 동적 IP 주소를 사용할 경우 인스턴스 재시작 시마다 IP가 변경되어 DNS 설정과 SSL 인증서에 문제가 발생할 수 있습니다.

VPC 네트워크 > 외부 IP 주소 메뉴에서 새 정적 IP 주소를 예약합니다. 지역은 VM 인스턴스를 생성할 지역과 동일하게 설정해야 합니다. IP 주소 이름은 "interactive-terminal-ip" 또는 이와 유사한 명확한 이름으로 설정합니다.

정적 IP 주소는 추가 비용이 발생하지만, 프로덕션 환경에서는 필수적인 투자입니다. 특히 사용자가 도메인을 통해 접근하는 웹 애플리케이션의 경우 IP 주소 변경으로 인한 서비스 중단을 방지할 수 있습니다.


## VM 인스턴스 생성 및 초기 설정

### 1. Compute Engine 인스턴스 생성

VM 인스턴스 생성은 Interactive Terminal Web 배포의 핵심 단계입니다. 올바른 설정은 애플리케이션의 성능과 안정성에 직접적인 영향을 미치므로 각 옵션을 신중히 선택해야 합니다.

Compute Engine 콘솔에서 "인스턴스 만들기"를 클릭하여 새 VM을 생성합니다. 인스턴스 이름은 "interactive-terminal-web-vm" 또는 이와 유사한 명확한 이름으로 설정합니다. 이름은 나중에 변경할 수 없으므로 신중히 선택해야 합니다.

**지역 및 영역 선택**은 사용자의 지리적 위치와 지연 시간을 고려하여 결정해야 합니다. 한국 사용자를 대상으로 하는 경우 asia-northeast3 (서울) 지역을 선택하는 것이 최적입니다. 이는 네트워크 지연 시간을 최소화하고 사용자 경험을 향상시킵니다. 글로벌 서비스를 계획하는 경우에는 주요 사용자층이 위치한 지역을 우선적으로 고려해야 합니다.

**머신 구성**에서는 앞서 언급한 권장 사양에 따라 적절한 머신 타입을 선택합니다. 개발 및 테스트 목적이라면 e2-standard-2를 선택하고, 프로덕션 환경에서는 e2-standard-4 이상을 권장합니다. 머신 타입은 나중에 변경할 수 있지만, 인스턴스를 중지해야 하므로 서비스 중단이 발생합니다.

**부팅 디스크 설정**은 운영체제와 스토리지 타입을 결정하는 중요한 단계입니다. 운영체제는 Ubuntu 22.04 LTS를 선택하고, 부팅 디스크 타입은 SSD 영구 디스크를 선택합니다. 디스크 크기는 최소 20GB로 설정하되, 로그 파일과 사용자 데이터를 고려하여 50GB 이상을 권장합니다. SSD는 HDD보다 비용이 높지만, 애플리케이션의 응답 속도와 전반적인 성능에 큰 차이를 만듭니다.

### 2. 네트워크 및 보안 설정

**네트워크 인터페이스 설정**에서는 앞서 생성한 VPC 네트워크와 서브넷을 선택합니다. 외부 IP는 앞서 예약한 정적 IP 주소를 할당합니다. 이는 도메인 연결과 SSL 인증서 설정을 위해 필수적입니다.

**방화벽 설정**에서는 "HTTP 트래픽 허용"과 "HTTPS 트래픽 허용" 옵션을 체크합니다. 이는 웹 애플리케이션에 대한 외부 접근을 허용하기 위해 필요합니다. 추가적인 보안 설정은 인스턴스 생성 후 방화벽 규칙을 통해 세밀하게 조정할 수 있습니다.

**SSH 키 설정**은 보안 접근을 위해 매우 중요합니다. 기본 SSH 키를 사용하거나 사용자 정의 SSH 키를 업로드할 수 있습니다. 보안을 위해 강력한 SSH 키를 생성하고 개인 키는 안전한 위치에 저장해야 합니다. SSH 키는 서버에 대한 관리자 접근을 제어하므로 절대 공유하거나 공개해서는 안 됩니다.

### 3. 고급 옵션 설정

**메타데이터 설정**에서는 인스턴스 시작 시 자동으로 실행될 스크립트를 정의할 수 있습니다. 이는 초기 소프트웨어 설치와 설정을 자동화하는 데 유용합니다. 다음과 같은 시작 스크립트를 사용할 수 있습니다:

```bash
#!/bin/bash
# 시스템 업데이트
apt-get update && apt-get upgrade -y

# 필수 패키지 설치
apt-get install -y curl wget git nginx

# Node.js 20.x 설치
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
apt-get install -y nodejs

# Python 3.11 및 pip 설치
apt-get install -y python3.11 python3.11-venv python3-pip

# 방화벽 설정
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# 로그 디렉토리 생성
mkdir -p /var/log/interactive-terminal-web
chown ubuntu:ubuntu /var/log/interactive-terminal-web
```

이 스크립트는 인스턴스가 처음 시작될 때 자동으로 실행되어 기본적인 환경 설정을 완료합니다. 수동으로 설정하는 시간을 절약하고 설정 오류를 방지할 수 있습니다.

**서비스 계정 설정**에서는 앞서 생성한 서비스 계정을 선택합니다. 이는 인스턴스가 다른 GCP 서비스에 접근할 때 사용할 권한을 정의합니다. 올바른 서비스 계정을 선택하지 않으면 애플리케이션이 필요한 GCP 서비스에 접근할 수 없어 기능이 제한될 수 있습니다.

### 4. 인스턴스 생성 및 초기 접속

모든 설정을 완료한 후 "만들기" 버튼을 클릭하여 인스턴스를 생성합니다. 인스턴스 생성에는 보통 1-2분이 소요되며, 생성이 완료되면 Compute Engine 콘솔에서 인스턴스 상태를 확인할 수 있습니다.

인스턴스가 실행 상태가 되면 SSH를 통해 접속할 수 있습니다. GCP 콘솔에서 제공하는 브라우저 기반 SSH 터미널을 사용하거나, 로컬 터미널에서 SSH 클라이언트를 사용할 수 있습니다. 로컬 터미널을 사용하는 경우 다음과 같은 명령어를 사용합니다:

```bash
ssh -i /path/to/private-key ubuntu@EXTERNAL_IP_ADDRESS
```

여기서 EXTERNAL_IP_ADDRESS는 인스턴스에 할당된 정적 외부 IP 주소입니다.

첫 접속 후에는 시스템 상태를 확인하고 시작 스크립트가 정상적으로 실행되었는지 확인해야 합니다. 다음 명령어들을 사용하여 설치된 소프트웨어 버전을 확인할 수 있습니다:

```bash
node --version
python3.11 --version
nginx -v
git --version
```

모든 소프트웨어가 정상적으로 설치되었다면 다음 단계인 애플리케이션 배포를 진행할 수 있습니다.


## 애플리케이션 배포

### 1. 소스 코드 다운로드 및 설정

Interactive Terminal Web 애플리케이션의 배포는 소스 코드를 서버에 복사하고 필요한 의존성을 설치하는 것부터 시작됩니다. 이 과정은 애플리케이션의 안정적인 운영을 위해 매우 중요하므로 각 단계를 정확히 수행해야 합니다.

먼저 애플리케이션 파일을 저장할 디렉토리를 생성합니다. 일반적으로 `/opt` 디렉토리 하위에 애플리케이션별 디렉토리를 생성하는 것이 Linux 시스템의 관례입니다:

```bash
sudo mkdir -p /opt/interactive-terminal-web
sudo chown ubuntu:ubuntu /opt/interactive-terminal-web
cd /opt/interactive-terminal-web
```

샌드박스 환경에서 개발된 소스 코드를 GCP 인스턴스로 전송하는 방법은 여러 가지가 있습니다. 가장 일반적인 방법은 Git 저장소를 사용하는 것이지만, 개발 중인 코드의 경우 직접 파일 전송이 필요할 수 있습니다.

**Git 저장소를 사용하는 경우**:
```bash
git clone https://github.com/your-username/interactive-terminal-web.git .
```

**직접 파일 전송을 사용하는 경우**, 로컬 머신에서 scp 명령어를 사용하여 파일을 전송할 수 있습니다:
```bash
# 백엔드 파일 전송
scp -r -i /path/to/private-key ./interactive-terminal-backend ubuntu@EXTERNAL_IP:/opt/interactive-terminal-web/

# 프론트엔드 파일 전송
scp -r -i /path/to/private-key ./interactive-terminal-web ubuntu@EXTERNAL_IP:/opt/interactive-terminal-web/
```

### 2. 백엔드 설정 및 배포

Flask 백엔드는 Python 가상 환경을 사용하여 의존성을 격리하고 관리해야 합니다. 이는 시스템 Python 환경과의 충돌을 방지하고 애플리케이션별 패키지 관리를 가능하게 합니다.

백엔드 디렉토리로 이동하여 Python 가상 환경을 생성합니다:
```bash
cd /opt/interactive-terminal-web/interactive-terminal-backend
python3.11 -m venv venv
source venv/bin/activate
```

가상 환경이 활성화된 상태에서 필요한 Python 패키지들을 설치합니다:
```bash
pip install --upgrade pip
pip install flask flask-cors psutil requests python-dotenv gunicorn
```

환경 변수 설정을 위한 `.env` 파일을 생성합니다. 이 파일에는 Manus AI API 키와 기타 중요한 설정 정보가 포함됩니다:
```bash
cat > .env << EOF
MANUS_API_KEY=your_manus_api_key_here
MANUS_API_URL=https://api.manus.chat/v1/chat/completions
FLASK_ENV=production
FLASK_DEBUG=False
SECRET_KEY=$(python -c 'import secrets; print(secrets.token_hex(32))')
EOF
```

보안을 위해 `.env` 파일의 권한을 제한합니다:
```bash
chmod 600 .env
```

프로덕션 환경에서는 Flask 개발 서버 대신 Gunicorn과 같은 WSGI 서버를 사용해야 합니다. Gunicorn 설정 파일을 생성합니다:
```bash
cat > gunicorn.conf.py << EOF
bind = "127.0.0.1:5000"
workers = 4
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2
max_requests = 1000
max_requests_jitter = 100
preload_app = True
user = "ubuntu"
group = "ubuntu"
daemon = False
pidfile = "/var/run/gunicorn.pid"
accesslog = "/var/log/interactive-terminal-web/gunicorn-access.log"
errorlog = "/var/log/interactive-terminal-web/gunicorn-error.log"
loglevel = "info"
EOF
```

### 3. 프론트엔드 빌드 및 설정

React 프론트엔드는 프로덕션용으로 빌드하여 정적 파일로 제공해야 합니다. 이는 개발 서버보다 훨씬 빠른 성능과 안정성을 제공합니다.

프론트엔드 디렉토리로 이동하여 의존성을 설치합니다:
```bash
cd /opt/interactive-terminal-web/interactive-terminal-web
npm install
```

프로덕션 환경에 맞게 API URL을 수정해야 합니다. `src/App.jsx` 파일에서 API_BASE_URL을 실제 서버 주소로 변경합니다:
```javascript
const API_BASE_URL = 'https://your-domain.com/api'
// 또는 IP 주소를 사용하는 경우
// const API_BASE_URL = 'https://YOUR_EXTERNAL_IP/api'
```

프로덕션 빌드를 생성합니다:
```bash
npm run build
```

빌드가 완료되면 `dist` 디렉토리에 최적화된 정적 파일들이 생성됩니다. 이 파일들을 Nginx가 서비스할 수 있도록 적절한 위치에 복사합니다:
```bash
sudo mkdir -p /var/www/interactive-terminal-web
sudo cp -r dist/* /var/www/interactive-terminal-web/
sudo chown -R www-data:www-data /var/www/interactive-terminal-web
```

### 4. 시스템 서비스 설정

애플리케이션이 시스템 부팅 시 자동으로 시작되고 장애 시 자동으로 재시작되도록 systemd 서비스를 설정해야 합니다. 이는 프로덕션 환경에서 서비스의 안정성과 가용성을 보장하는 중요한 단계입니다.

Flask 백엔드를 위한 systemd 서비스 파일을 생성합니다:
```bash
sudo cat > /etc/systemd/system/interactive-terminal-backend.service << EOF
[Unit]
Description=Interactive Terminal Web Backend
After=network.target

[Service]
Type=exec
User=ubuntu
Group=ubuntu
WorkingDirectory=/opt/interactive-terminal-web/interactive-terminal-backend
Environment=PATH=/opt/interactive-terminal-web/interactive-terminal-backend/venv/bin
ExecStart=/opt/interactive-terminal-web/interactive-terminal-backend/venv/bin/gunicorn -c gunicorn.conf.py src.main:app
ExecReload=/bin/kill -s HUP \$MAINPID
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=interactive-terminal-backend

[Install]
WantedBy=multi-user.target
EOF
```

서비스를 활성화하고 시작합니다:
```bash
sudo systemctl daemon-reload
sudo systemctl enable interactive-terminal-backend
sudo systemctl start interactive-terminal-backend
```

서비스 상태를 확인하여 정상적으로 실행되고 있는지 확인합니다:
```bash
sudo systemctl status interactive-terminal-backend
```

로그를 확인하여 오류가 없는지 점검합니다:
```bash
sudo journalctl -u interactive-terminal-backend -f
```

### 5. 데이터베이스 및 스토리지 설정 (선택사항)

Interactive Terminal Web 애플리케이션은 기본적으로 상태를 메모리에 저장하지만, 프로덕션 환경에서는 영구 저장소를 사용하는 것이 좋습니다. 사용자 세션, 명령어 히스토리, 시스템 로그 등을 저장하기 위해 데이터베이스나 파일 시스템을 활용할 수 있습니다.

**파일 기반 저장소 설정**:
```bash
sudo mkdir -p /var/lib/interactive-terminal-web/{sessions,logs,uploads}
sudo chown -R ubuntu:ubuntu /var/lib/interactive-terminal-web
```

**SQLite 데이터베이스 설정** (간단한 설정의 경우):
```bash
cd /opt/interactive-terminal-web/interactive-terminal-backend
source venv/bin/activate
pip install sqlite3
```

**PostgreSQL 설정** (고성능이 필요한 경우):
```bash
sudo apt-get install -y postgresql postgresql-contrib
sudo -u postgres createuser --interactive ubuntu
sudo -u postgres createdb interactive_terminal_web
```

데이터베이스를 사용하는 경우 백엔드 코드에서 적절한 데이터베이스 연결 설정을 추가해야 합니다. 이는 사용자 요구사항과 예상 트래픽에 따라 결정해야 합니다.


## Nginx 설정 및 SSL 인증서

### 1. Nginx 기본 설정

Nginx는 Interactive Terminal Web 애플리케이션의 웹 서버 역할을 담당하며, 정적 파일 서비스, 리버스 프록시, SSL 터미네이션 등의 중요한 기능을 수행합니다. 올바른 Nginx 설정은 애플리케이션의 성능과 보안에 직접적인 영향을 미치므로 신중하게 구성해야 합니다.

먼저 기존의 기본 Nginx 설정을 백업하고 새로운 설정을 생성합니다:
```bash
sudo cp /etc/nginx/sites-available/default /etc/nginx/sites-available/default.backup
sudo rm /etc/nginx/sites-available/default
sudo rm /etc/nginx/sites-enabled/default
```

Interactive Terminal Web을 위한 새로운 Nginx 설정 파일을 생성합니다:
```bash
sudo cat > /etc/nginx/sites-available/interactive-terminal-web << 'EOF'
# HTTP 서버 (HTTPS로 리다이렉트)
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    # Let's Encrypt 인증서 갱신을 위한 경로
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    
    # 모든 HTTP 요청을 HTTPS로 리다이렉트
    location / {
        return 301 https://$server_name$request_uri;
    }
}

# HTTPS 서버
server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;
    
    # SSL 인증서 설정 (Let's Encrypt 사용 시)
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
    
    # SSL 보안 설정
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # 보안 헤더
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    
    # 정적 파일 서비스 (React 빌드 파일)
    location / {
        root /var/www/interactive-terminal-web;
        index index.html;
        try_files $uri $uri/ /index.html;
        
        # 캐시 설정
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }
    
    # API 요청을 Flask 백엔드로 프록시
    location /api/ {
        proxy_pass http://127.0.0.1:5000/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # 타임아웃 설정 (터미널 명령어 실행 시간 고려)
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # 버퍼링 설정
        proxy_buffering off;
        proxy_request_buffering off;
    }
    
    # 웹소켓 지원 (향후 실시간 기능을 위해)
    location /ws/ {
        proxy_pass http://127.0.0.1:5000/ws/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # 로그 설정
    access_log /var/log/nginx/interactive-terminal-web.access.log;
    error_log /var/log/nginx/interactive-terminal-web.error.log;
}
EOF
```

설정 파일에서 `your-domain.com`을 실제 도메인으로 변경해야 합니다. 도메인이 없는 경우 IP 주소를 사용할 수 있지만, SSL 인증서 설정에 제약이 있을 수 있습니다.

설정 파일을 활성화합니다:
```bash
sudo ln -s /etc/nginx/sites-available/interactive-terminal-web /etc/nginx/sites-enabled/
```

Nginx 설정의 문법을 확인합니다:
```bash
sudo nginx -t
```

오류가 없다면 Nginx를 재시작합니다:
```bash
sudo systemctl restart nginx
```

### 2. Let's Encrypt SSL 인증서 설정

HTTPS는 현대 웹 애플리케이션에서 필수적인 보안 요소입니다. 특히 Interactive Terminal Web과 같이 민감한 명령어를 전송하는 애플리케이션에서는 더욱 중요합니다. Let's Encrypt는 무료로 SSL 인증서를 제공하는 인증 기관으로, 자동화된 인증서 발급과 갱신을 지원합니다.

Certbot을 설치합니다:
```bash
sudo apt-get update
sudo apt-get install -y certbot python3-certbot-nginx
```

Let's Encrypt 인증서 발급을 위한 웹루트 디렉토리를 생성합니다:
```bash
sudo mkdir -p /var/www/certbot
sudo chown www-data:www-data /var/www/certbot
```

도메인이 올바르게 설정되어 있는지 확인한 후 인증서를 발급받습니다:
```bash
sudo certbot certonly --webroot -w /var/www/certbot -d your-domain.com -d www.your-domain.com
```

인증서 발급 과정에서 이메일 주소와 약관 동의가 필요합니다. 이메일 주소는 인증서 만료 알림을 받기 위해 사용되므로 정확한 주소를 입력해야 합니다.

인증서가 성공적으로 발급되면 Nginx 설정에서 SSL 인증서 경로를 확인하고 Nginx를 재시작합니다:
```bash
sudo nginx -t
sudo systemctl restart nginx
```

### 3. 인증서 자동 갱신 설정

Let's Encrypt 인증서는 90일마다 만료되므로 자동 갱신을 설정해야 합니다. Certbot은 자동 갱신 기능을 제공하며, cron을 사용하여 정기적으로 실행할 수 있습니다.

자동 갱신 테스트를 수행합니다:
```bash
sudo certbot renew --dry-run
```

테스트가 성공하면 cron 작업을 설정합니다:
```bash
sudo crontab -e
```

다음 라인을 추가합니다:
```bash
0 12 * * * /usr/bin/certbot renew --quiet && /usr/bin/systemctl reload nginx
```

이 설정은 매일 정오에 인증서 갱신을 확인하고, 필요한 경우 갱신 후 Nginx를 다시 로드합니다.

### 4. 방화벽 및 보안 설정

GCP의 방화벽 규칙과 함께 서버 레벨에서도 추가적인 보안 설정을 적용해야 합니다. Ubuntu의 UFW(Uncomplicated Firewall)를 사용하여 로컬 방화벽을 설정합니다:

```bash
# 기본 정책 설정
sudo ufw default deny incoming
sudo ufw default allow outgoing

# 필요한 포트만 허용
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS

# 방화벽 활성화
sudo ufw --force enable
```

추가적인 보안을 위해 fail2ban을 설치하여 무차별 대입 공격을 방지할 수 있습니다:
```bash
sudo apt-get install -y fail2ban

# fail2ban 설정 파일 생성
sudo cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
port = http,https
logpath = /var/log/nginx/error.log
EOF

sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 5. 성능 최적화 설정

Nginx의 성능을 최적화하기 위해 추가적인 설정을 적용할 수 있습니다. `/etc/nginx/nginx.conf` 파일을 편집하여 다음 설정들을 추가하거나 수정합니다:

```bash
sudo cat > /etc/nginx/conf.d/performance.conf << EOF
# 워커 프로세스 수 (CPU 코어 수와 동일하게 설정)
worker_processes auto;

# 워커 연결 수
events {
    worker_connections 1024;
    use epoll;
    multi_accept on;
}

# HTTP 설정
http {
    # 파일 전송 최적화
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    
    # 타임아웃 설정
    keepalive_timeout 65;
    client_max_body_size 100M;
    
    # Gzip 압축
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/javascript
        application/xml+rss
        application/json;
    
    # 로그 형식
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
}
EOF
```

설정 변경 후 Nginx를 재시작합니다:
```bash
sudo nginx -t
sudo systemctl restart nginx
```

이러한 설정들은 애플리케이션의 응답 속도를 향상시키고 동시 접속자 수를 늘리는 데 도움이 됩니다.


## 모니터링 및 로깅

### 1. 시스템 모니터링 설정

Interactive Terminal Web 애플리케이션의 안정적인 운영을 위해서는 포괄적인 모니터링 시스템이 필수적입니다. 시스템 리소스, 애플리케이션 성능, 사용자 활동 등을 실시간으로 모니터링하여 문제를 조기에 발견하고 대응할 수 있어야 합니다.

**Google Cloud Monitoring 에이전트 설치**는 GCP 환경에서 가장 효과적인 모니터링 솔루션입니다. 이 에이전트는 시스템 메트릭을 자동으로 수집하고 Cloud Monitoring 대시보드에서 시각화할 수 있게 해줍니다:

```bash
# Cloud Monitoring 에이전트 설치
curl -sSO https://dl.google.com/cloudagents/add-google-cloud-ops-agent-repo.sh
sudo bash add-google-cloud-ops-agent-repo.sh --also-install

# 에이전트 상태 확인
sudo systemctl status google-cloud-ops-agent
```

에이전트가 설치되면 기본적인 시스템 메트릭(CPU, 메모리, 디스크, 네트워크)이 자동으로 수집됩니다. 추가적으로 애플리케이션별 메트릭을 수집하기 위해 커스텀 설정을 추가할 수 있습니다.

**커스텀 메트릭 설정**을 위해 `/etc/google-cloud-ops-agent/config.yaml` 파일을 생성합니다:

```yaml
logging:
  receivers:
    nginx_access:
      type: nginx_access
      include_paths:
        - /var/log/nginx/interactive-terminal-web.access.log
    nginx_error:
      type: nginx_error
      include_paths:
        - /var/log/nginx/interactive-terminal-web.error.log
    flask_app:
      type: files
      include_paths:
        - /var/log/interactive-terminal-web/gunicorn-*.log
  service:
    pipelines:
      default_pipeline:
        receivers: [nginx_access, nginx_error, flask_app]

metrics:
  receivers:
    nginx:
      type: nginx
      stub_status_url: http://localhost/nginx_status
    postgresql:
      type: postgresql
      endpoint: localhost:5432
      username: monitoring_user
      password: monitoring_password
  service:
    pipelines:
      default_pipeline:
        receivers: [nginx, postgresql]
```

설정 변경 후 에이전트를 재시작합니다:
```bash
sudo systemctl restart google-cloud-ops-agent
```

### 2. 애플리케이션 로깅 설정

효과적인 로깅은 문제 진단과 성능 분석에 필수적입니다. Interactive Terminal Web 애플리케이션의 각 구성 요소별로 적절한 로깅 전략을 수립해야 합니다.

**Flask 백엔드 로깅 설정**을 위해 Python 로깅 모듈을 활용합니다. `src/main.py` 파일에 다음과 같은 로깅 설정을 추가합니다:

```python
import logging
import logging.handlers
from flask import Flask, request
import time

# 로깅 설정
def setup_logging(app):
    if not app.debug:
        # 파일 핸들러 설정
        file_handler = logging.handlers.RotatingFileHandler(
            '/var/log/interactive-terminal-web/app.log',
            maxBytes=10240000,  # 10MB
            backupCount=10
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
        ))
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)
        
        # 시스템 로그 핸들러
        syslog_handler = logging.handlers.SysLogHandler()
        syslog_handler.setLevel(logging.WARNING)
        app.logger.addHandler(syslog_handler)
        
        app.logger.setLevel(logging.INFO)
        app.logger.info('Interactive Terminal Web startup')

# 요청 로깅 미들웨어
@app.before_request
def log_request_info():
    app.logger.info('Request: %s %s', request.method, request.url)
    request.start_time = time.time()

@app.after_request
def log_response_info(response):
    duration = time.time() - request.start_time
    app.logger.info('Response: %s %s - %s (%.3fs)', 
                   request.method, request.url, response.status_code, duration)
    return response
```

**Nginx 로깅 설정**은 앞서 설정한 액세스 로그와 에러 로그를 통해 웹 서버 레벨의 활동을 추적합니다. 로그 로테이션을 설정하여 디스크 공간을 효율적으로 관리해야 합니다:

```bash
sudo cat > /etc/logrotate.d/interactive-terminal-web << EOF
/var/log/nginx/interactive-terminal-web.*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    postrotate
        if [ -f /var/run/nginx.pid ]; then
            kill -USR1 `cat /var/run/nginx.pid`
        fi
    endscript
}

/var/log/interactive-terminal-web/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 ubuntu ubuntu
    postrotate
        systemctl reload interactive-terminal-backend
    endscript
}
EOF
```

### 3. 알림 및 경고 설정

시스템 문제나 성능 저하를 즉시 감지하고 대응하기 위해 알림 시스템을 구축해야 합니다. Google Cloud Monitoring의 알림 정책을 사용하여 다양한 조건에 대한 경고를 설정할 수 있습니다.

**CPU 사용률 알림 설정**:
```bash
# gcloud CLI를 사용한 알림 정책 생성
gcloud alpha monitoring policies create --policy-from-file=cpu-alert-policy.yaml
```

`cpu-alert-policy.yaml` 파일 내용:
```yaml
displayName: "High CPU Usage Alert"
conditions:
  - displayName: "CPU usage above 80%"
    conditionThreshold:
      filter: 'resource.type="gce_instance"'
      comparison: COMPARISON_GREATER_THAN
      thresholdValue: 0.8
      duration: 300s
      aggregations:
        - alignmentPeriod: 60s
          perSeriesAligner: ALIGN_MEAN
          crossSeriesReducer: REDUCE_MEAN
notificationChannels:
  - projects/YOUR_PROJECT_ID/notificationChannels/YOUR_NOTIFICATION_CHANNEL_ID
alertStrategy:
  autoClose: 86400s
```

**메모리 사용률 알림 설정**:
```yaml
displayName: "High Memory Usage Alert"
conditions:
  - displayName: "Memory usage above 85%"
    conditionThreshold:
      filter: 'resource.type="gce_instance" AND metric.type="compute.googleapis.com/instance/memory/utilization"'
      comparison: COMPARISON_GREATER_THAN
      thresholdValue: 0.85
      duration: 300s
```

**애플리케이션 응답 시간 알림 설정**:
```yaml
displayName: "High Response Time Alert"
conditions:
  - displayName: "Response time above 5 seconds"
    conditionThreshold:
      filter: 'resource.type="gce_instance" AND metric.type="nginx/request_time"'
      comparison: COMPARISON_GREATER_THAN
      thresholdValue: 5.0
      duration: 180s
```

### 4. 대시보드 구성

효과적인 모니터링을 위해서는 시각적 대시보드가 필요합니다. Google Cloud Monitoring에서 커스텀 대시보드를 생성하여 중요한 메트릭들을 한눈에 볼 수 있도록 구성합니다.

**시스템 리소스 대시보드**에는 다음 위젯들을 포함해야 합니다:
- CPU 사용률 시계열 차트
- 메모리 사용률 게이지
- 디스크 I/O 차트
- 네트워크 트래픽 차트
- 시스템 로드 평균

**애플리케이션 성능 대시보드**에는 다음 요소들을 포함합니다:
- HTTP 요청 수 및 응답 시간
- API 엔드포인트별 성능 메트릭
- 에러율 및 상태 코드 분포
- 동시 사용자 수
- Manus AI API 호출 통계

**보안 모니터링 대시보드**에는 다음 정보들을 표시합니다:
- 실패한 로그인 시도
- 비정상적인 명령어 실행 패턴
- 방화벽 차단 이벤트
- SSL 인증서 만료 상태

### 5. 로그 분석 및 검색

대량의 로그 데이터에서 유용한 정보를 추출하기 위해 로그 분석 도구를 활용해야 합니다. Google Cloud Logging의 고급 검색 기능을 사용하여 특정 패턴이나 이벤트를 찾을 수 있습니다.

**일반적인 로그 검색 쿼리 예시**:

에러 로그 검색:
```
resource.type="gce_instance"
severity>=ERROR
timestamp>="2025-07-16T00:00:00Z"
```

특정 사용자의 활동 추적:
```
resource.type="gce_instance"
jsonPayload.user_id="user123"
timestamp>="2025-07-16T00:00:00Z"
```

API 응답 시간 분석:
```
resource.type="gce_instance"
jsonPayload.response_time>5.0
httpRequest.requestMethod="POST"
```

보안 이벤트 모니터링:
```
resource.type="gce_instance"
(jsonPayload.command=~"sudo|rm|chmod" OR severity>=WARNING)
timestamp>="2025-07-16T00:00:00Z"
```

이러한 쿼리들을 저장된 검색으로 만들어 정기적으로 실행하거나 알림과 연동할 수 있습니다. 또한 BigQuery와 연동하여 더 복잡한 로그 분석과 리포팅을 수행할 수도 있습니다.


## 보안 고려사항

### 1. 명령어 실행 보안

Interactive Terminal Web 애플리케이션의 가장 중요한 보안 고려사항은 터미널 명령어 실행 기능입니다. 이 기능은 강력한 유용성을 제공하지만 동시에 심각한 보안 위험을 초래할 수 있으므로 다층적인 보안 조치가 필요합니다.

**명령어 화이트리스트 구현**은 가장 기본적이면서도 효과적인 보안 조치입니다. 허용된 명령어만 실행할 수 있도록 제한하여 악의적인 명령어 실행을 방지합니다. Flask 백엔드에서 다음과 같은 화이트리스트를 구현할 수 있습니다:

```python
ALLOWED_COMMANDS = {
    'ls', 'pwd', 'whoami', 'date', 'uptime', 'df', 'free', 'ps',
    'top', 'htop', 'cat', 'head', 'tail', 'grep', 'find', 'which',
    'echo', 'mkdir', 'rmdir', 'cp', 'mv', 'chmod', 'chown', 'ln',
    'git', 'npm', 'pip', 'python', 'node', 'curl', 'wget'
}

DANGEROUS_COMMANDS = {
    'rm', 'sudo', 'su', 'passwd', 'useradd', 'userdel', 'groupadd',
    'mount', 'umount', 'fdisk', 'mkfs', 'dd', 'shutdown', 'reboot',
    'iptables', 'ufw', 'systemctl', 'service', 'crontab', 'at'
}

def validate_command(command):
    cmd_parts = command.strip().split()
    if not cmd_parts:
        return False, "Empty command"
    
    base_command = cmd_parts[0]
    
    if base_command in DANGEROUS_COMMANDS:
        return False, f"Command '{base_command}' is not allowed for security reasons"
    
    if base_command not in ALLOWED_COMMANDS:
        return False, f"Command '{base_command}' is not in the allowed list"
    
    # 추가 검증: 파이프, 리다이렉션, 명령어 체이닝 검사
    dangerous_chars = ['|', '>', '>>', '<', '&&', '||', ';', '`', '$']
    for char in dangerous_chars:
        if char in command:
            return False, f"Character '{char}' is not allowed"
    
    return True, "Command is valid"
```

**사용자 권한 제한**은 또 다른 중요한 보안 조치입니다. 애플리케이션을 실행하는 사용자 계정에 최소한의 권한만 부여하여 시스템 손상 위험을 최소화해야 합니다:

```bash
# 전용 사용자 계정 생성
sudo useradd -r -s /bin/bash -d /opt/interactive-terminal-web -m terminal-web

# 제한된 권한 부여
sudo usermod -aG www-data terminal-web

# sudo 권한 제거 (필요한 경우에만 특정 명령어에 대해 제한적으로 허용)
sudo visudo
# 다음 라인 추가 (매우 신중하게 사용)
# terminal-web ALL=(ALL) NOPASSWD: /bin/systemctl status, /bin/systemctl restart nginx
```

**명령어 실행 환경 격리**를 위해 chroot jail이나 컨테이너를 사용할 수 있습니다. 이는 명령어 실행을 제한된 환경 내에서만 수행하도록 하여 시스템 전체에 대한 접근을 차단합니다:

```bash
# chroot 환경 설정
sudo mkdir -p /var/chroot/terminal-web/{bin,lib,lib64,usr,etc,tmp,var,proc,sys,dev}

# 필요한 바이너리 복사
sudo cp /bin/{bash,ls,cat,echo,pwd} /var/chroot/terminal-web/bin/
sudo cp /usr/bin/{whoami,date,uptime} /var/chroot/terminal-web/usr/bin/

# 라이브러리 의존성 복사 (ldd 명령어로 확인 후)
for binary in /var/chroot/terminal-web/bin/*; do
    ldd $binary | grep -o '/lib[^ ]*' | xargs -I {} sudo cp {} /var/chroot/terminal-web/lib/
done
```

### 2. 인증 및 권한 관리

**다단계 인증(MFA) 구현**은 무단 접근을 방지하는 강력한 보안 조치입니다. Google Authenticator나 Authy와 같은 TOTP(Time-based One-Time Password) 앱을 활용할 수 있습니다:

```python
import pyotp
import qrcode
from flask import session

def generate_mfa_secret():
    secret = pyotp.random_base32()
    return secret

def generate_qr_code(secret, user_email):
    totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(
        name=user_email,
        issuer_name="Interactive Terminal Web"
    )
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(totp_uri)
    qr.make(fit=True)
    return qr.make_image(fill_color="black", back_color="white")

def verify_mfa_token(secret, token):
    totp = pyotp.TOTP(secret)
    return totp.verify(token, valid_window=1)
```

**세션 관리 보안**은 사용자 인증 상태를 안전하게 유지하는 데 필수적입니다:

```python
from flask import Flask, session
import secrets
import datetime

app.config['SECRET_KEY'] = secrets.token_hex(32)
app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(hours=2)

@app.before_request
def check_session_security():
    # 세션 하이재킹 방지를 위한 IP 주소 검증
    if 'user_ip' in session:
        if session['user_ip'] != request.remote_addr:
            session.clear()
            return redirect('/login')
    
    # 세션 만료 시간 검증
    if 'last_activity' in session:
        if datetime.datetime.now() - session['last_activity'] > app.config['PERMANENT_SESSION_LIFETIME']:
            session.clear()
            return redirect('/login')
    
    session['last_activity'] = datetime.datetime.now()
```

**API 키 관리**는 Manus AI와의 통신 보안을 위해 중요합니다:

```python
import os
from cryptography.fernet import Fernet

# 환경 변수에서 암호화 키 로드
ENCRYPTION_KEY = os.environ.get('ENCRYPTION_KEY')
if not ENCRYPTION_KEY:
    ENCRYPTION_KEY = Fernet.generate_key()
    print(f"Generated new encryption key: {ENCRYPTION_KEY.decode()}")

cipher_suite = Fernet(ENCRYPTION_KEY)

def encrypt_api_key(api_key):
    return cipher_suite.encrypt(api_key.encode())

def decrypt_api_key(encrypted_key):
    return cipher_suite.decrypt(encrypted_key).decode()
```

### 3. 네트워크 보안

**DDoS 방어**를 위해 Nginx에서 요청 제한을 설정합니다:

```nginx
# /etc/nginx/conf.d/rate-limiting.conf
http {
    # IP별 요청 제한
    limit_req_zone $binary_remote_addr zone=login:10m rate=5r/m;
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=general:10m rate=1r/s;
    
    # 연결 수 제한
    limit_conn_zone $binary_remote_addr zone=addr:10m;
    
    server {
        # 로그인 페이지 보호
        location /login {
            limit_req zone=login burst=3 nodelay;
            limit_conn addr 5;
        }
        
        # API 엔드포인트 보호
        location /api/ {
            limit_req zone=api burst=20 nodelay;
            limit_conn addr 10;
        }
        
        # 일반 페이지 보호
        location / {
            limit_req zone=general burst=10 nodelay;
            limit_conn addr 20;
        }
    }
}
```

**웹 애플리케이션 방화벽(WAF) 규칙**을 구현하여 일반적인 웹 공격을 차단합니다:

```nginx
# SQL 인젝션 방어
location ~ .*(\.|%2e)(\.|%2e)(%2f|%5c|/|\\) {
    deny all;
}

# XSS 방어
location ~ .*(<|%3c).*script.*(>|%3e) {
    deny all;
}

# 파일 업로드 공격 방어
location ~ \.(php|asp|aspx|jsp)$ {
    deny all;
}

# 숨겨진 파일 접근 차단
location ~ /\. {
    deny all;
}
```

## 문제 해결

### 1. 일반적인 배포 문제

**서비스 시작 실패 문제**는 가장 흔히 발생하는 문제 중 하나입니다. 다음과 같은 단계로 진단할 수 있습니다:

```bash
# 서비스 상태 확인
sudo systemctl status interactive-terminal-backend

# 상세 로그 확인
sudo journalctl -u interactive-terminal-backend -f

# 설정 파일 문법 검사
cd /opt/interactive-terminal-web/interactive-terminal-backend
source venv/bin/activate
python -m py_compile src/main.py

# 포트 사용 상태 확인
sudo netstat -tlnp | grep :5000
```

**권한 문제 해결**:
```bash
# 파일 소유권 확인 및 수정
sudo chown -R ubuntu:ubuntu /opt/interactive-terminal-web
sudo chmod -R 755 /opt/interactive-terminal-web

# 로그 디렉토리 권한 설정
sudo chown -R ubuntu:ubuntu /var/log/interactive-terminal-web
sudo chmod 755 /var/log/interactive-terminal-web
```

**의존성 문제 해결**:
```bash
# Python 가상 환경 재생성
cd /opt/interactive-terminal-web/interactive-terminal-backend
rm -rf venv
python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Node.js 의존성 재설치
cd /opt/interactive-terminal-web/interactive-terminal-web
rm -rf node_modules package-lock.json
npm install
```

### 2. 성능 문제 진단

**높은 CPU 사용률 문제**:
```bash
# 프로세스별 CPU 사용률 확인
top -p $(pgrep -d',' -f 'gunicorn|nginx')

# 시스템 리소스 모니터링
iostat -x 1
vmstat 1

# 애플리케이션 프로파일링
cd /opt/interactive-terminal-web/interactive-terminal-backend
source venv/bin/activate
pip install py-spy
sudo py-spy top --pid $(pgrep -f gunicorn)
```

**메모리 누수 진단**:
```bash
# 메모리 사용량 모니터링
ps aux --sort=-%mem | head -20

# 메모리 맵 분석
sudo pmap -x $(pgrep -f gunicorn)

# 가비지 컬렉션 통계 (Python)
python -c "import gc; print(gc.get_stats())"
```

**네트워크 지연 문제**:
```bash
# 네트워크 연결 상태 확인
ss -tuln

# DNS 해석 시간 측정
dig your-domain.com

# 외부 API 응답 시간 측정
curl -w "@curl-format.txt" -o /dev/null -s "https://api.manus.chat/v1/health"
```

### 3. 보안 사고 대응

**의심스러운 활동 감지 시**:
```bash
# 최근 로그인 기록 확인
last -n 50

# 실행된 명령어 히스토리 확인
sudo grep -r "COMMAND" /var/log/interactive-terminal-web/

# 네트워크 연결 상태 확인
sudo netstat -antup | grep ESTABLISHED

# 프로세스 트리 확인
ps auxf
```

**보안 사고 발생 시 즉시 조치**:
```bash
# 의심스러운 프로세스 종료
sudo pkill -f suspicious_process

# 방화벽으로 특정 IP 차단
sudo ufw deny from SUSPICIOUS_IP

# 서비스 임시 중단
sudo systemctl stop interactive-terminal-backend
sudo systemctl stop nginx

# 로그 백업
sudo tar -czf /tmp/security-logs-$(date +%Y%m%d-%H%M%S).tar.gz /var/log/
```

### 4. 데이터 백업 및 복구

**정기 백업 스크립트**:
```bash
#!/bin/bash
# /opt/scripts/backup.sh

BACKUP_DIR="/opt/backups"
DATE=$(date +%Y%m%d-%H%M%S)

# 애플리케이션 파일 백업
tar -czf "$BACKUP_DIR/app-$DATE.tar.gz" /opt/interactive-terminal-web

# 설정 파일 백업
tar -czf "$BACKUP_DIR/config-$DATE.tar.gz" /etc/nginx /etc/systemd/system/interactive-terminal-backend.service

# 로그 파일 백업
tar -czf "$BACKUP_DIR/logs-$DATE.tar.gz" /var/log/interactive-terminal-web

# 오래된 백업 파일 정리 (30일 이상)
find "$BACKUP_DIR" -name "*.tar.gz" -mtime +30 -delete

# Cloud Storage에 업로드
gsutil cp "$BACKUP_DIR/*-$DATE.tar.gz" gs://your-backup-bucket/
```

**복구 절차**:
```bash
# 서비스 중단
sudo systemctl stop interactive-terminal-backend nginx

# 백업에서 복구
cd /opt
sudo tar -xzf /opt/backups/app-YYYYMMDD-HHMMSS.tar.gz

# 권한 복구
sudo chown -R ubuntu:ubuntu /opt/interactive-terminal-web

# 서비스 재시작
sudo systemctl start interactive-terminal-backend nginx

# 상태 확인
sudo systemctl status interactive-terminal-backend nginx
```

이러한 문제 해결 가이드를 통해 대부분의 일반적인 문제들을 신속하게 진단하고 해결할 수 있습니다. 복잡한 문제의 경우 로그 분석과 시스템 모니터링 데이터를 종합적으로 검토하여 근본 원인을 파악해야 합니다.


## 결론

Interactive Terminal Web 애플리케이션의 GCP 배포는 현대적인 웹 기술과 AI 기술을 결합한 혁신적인 플랫폼을 구축하는 과정입니다. 본 가이드에서 다룬 모든 단계들을 정확히 수행한다면, 안정적이고 보안이 강화된 프로덕션 환경을 구축할 수 있습니다.

### 핵심 성과 요약

이 배포 가이드를 통해 달성할 수 있는 주요 성과들은 다음과 같습니다:

**기술적 성과**: Manus AI와 통합된 실시간 대화형 터미널 환경을 구축함으로써, 사용자는 자연어로 명령을 요청하고 AI의 도움을 받아 복잡한 시스템 관리 작업을 수행할 수 있습니다. 이는 기존의 정적인 터미널 인터페이스를 넘어서는 혁신적인 사용자 경험을 제공합니다.

**운영적 성과**: 포괄적인 모니터링과 로깅 시스템을 통해 시스템 상태를 실시간으로 추적하고, 문제 발생 시 신속한 대응이 가능한 환경을 구축했습니다. 자동화된 백업과 복구 시스템은 데이터 손실 위험을 최소화하고 서비스 연속성을 보장합니다.

**보안적 성과**: 다층적인 보안 조치를 통해 터미널 명령어 실행이라는 고위험 기능을 안전하게 제공할 수 있는 환경을 구축했습니다. 명령어 화이트리스트, 사용자 권한 제한, 네트워크 보안 등의 조치들이 종합적으로 작용하여 보안 위험을 최소화합니다.

### 향후 개선 방향

Interactive Terminal Web 플랫폼은 지속적인 개선과 확장이 가능한 구조로 설계되었습니다. 향후 고려할 수 있는 개선 방향들은 다음과 같습니다:

**AI 기능 확장**: Manus AI의 기능을 더욱 활용하여 코드 생성, 시스템 진단, 자동화 스크립트 작성 등의 고급 기능을 추가할 수 있습니다. 또한 사용자의 작업 패턴을 학습하여 개인화된 추천 기능을 제공할 수도 있습니다.

**협업 기능 추가**: 다중 사용자 환경에서 팀원들이 동시에 작업할 수 있는 협업 기능을 추가할 수 있습니다. 실시간 화면 공유, 명령어 실행 권한 관리, 작업 히스토리 공유 등의 기능이 포함될 수 있습니다.

**컨테이너화 및 오케스트레이션**: Docker와 Kubernetes를 활용하여 애플리케이션을 컨테이너화하고, 자동 스케일링과 무중단 배포를 구현할 수 있습니다. 이는 더 높은 가용성과 확장성을 제공합니다.

**멀티 클라우드 지원**: GCP 외에도 AWS, Azure 등 다른 클라우드 플랫폼에서도 동일한 기능을 제공할 수 있도록 플랫폼 독립적인 구조로 발전시킬 수 있습니다.

### 운영 모범 사례

성공적인 운영을 위해 다음과 같은 모범 사례들을 지속적으로 적용해야 합니다:

**정기적인 보안 점검**: 월 단위로 보안 설정을 검토하고, 새로운 보안 위협에 대응하기 위한 업데이트를 적용해야 합니다. 특히 명령어 화이트리스트와 사용자 권한 설정은 정기적으로 재검토되어야 합니다.

**성능 최적화**: 사용자 증가와 함께 시스템 성능을 지속적으로 모니터링하고 최적화해야 합니다. 데이터베이스 쿼리 최적화, 캐싱 전략 개선, 리소스 할당 조정 등이 포함됩니다.

**사용자 피드백 수집**: 사용자들의 피드백을 적극적으로 수집하고 분석하여 사용자 경험을 개선해야 합니다. 특히 AI 응답의 정확성과 터미널 인터페이스의 사용성에 대한 피드백이 중요합니다.

**문서화 유지**: 시스템 변경사항, 설정 수정, 문제 해결 과정 등을 체계적으로 문서화하여 지식 관리를 효율화해야 합니다.

### 비즈니스 가치

Interactive Terminal Web 플랫폼은 단순한 기술적 도구를 넘어서 다음과 같은 비즈니스 가치를 제공합니다:

**생산성 향상**: AI 어시스턴트의 도움으로 복잡한 시스템 관리 작업을 더 빠르고 정확하게 수행할 수 있어, 개발팀과 운영팀의 생산성이 크게 향상됩니다.

**학습 곡선 단축**: 초보자도 AI의 가이드를 받아 고급 시스템 관리 작업을 수행할 수 있어, 팀원들의 기술 역량 향상 속도가 빨라집니다.

**운영 비용 절감**: 자동화된 모니터링과 AI 기반 문제 진단을 통해 시스템 장애 대응 시간이 단축되고, 전체적인 운영 비용이 절감됩니다.

**혁신적 차별화**: 시장에서 유일무이한 AI 통합 터미널 환경을 제공함으로써 경쟁 우위를 확보할 수 있습니다.

## 참고 자료

### 공식 문서

[1] Google Cloud Platform Documentation. "Compute Engine Documentation." Google Cloud. https://cloud.google.com/compute/docs

[2] Google Cloud Platform Documentation. "Cloud Monitoring Documentation." Google Cloud. https://cloud.google.com/monitoring/docs

[3] Google Cloud Platform Documentation. "Cloud Logging Documentation." Google Cloud. https://cloud.google.com/logging/docs

[4] Nginx Documentation. "Nginx HTTP Server Documentation." Nginx Inc. https://nginx.org/en/docs/

[5] Flask Documentation. "Flask Web Development Framework." Pallets Projects. https://flask.palletsprojects.com/

[6] React Documentation. "React JavaScript Library." Meta Platforms Inc. https://react.dev/

[7] Let's Encrypt Documentation. "Let's Encrypt Certificate Authority." Internet Security Research Group. https://letsencrypt.org/docs/

### 보안 가이드라인

[8] OWASP Foundation. "OWASP Top Ten Web Application Security Risks." OWASP. https://owasp.org/www-project-top-ten/

[9] NIST. "Cybersecurity Framework." National Institute of Standards and Technology. https://www.nist.gov/cyberframework

[10] CIS Controls. "Center for Internet Security Controls." Center for Internet Security. https://www.cisecurity.org/controls

### 기술 참고 자료

[11] Mozilla Developer Network. "HTTP Security Headers." Mozilla Foundation. https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers

[12] Ubuntu Documentation. "Ubuntu Server Guide." Canonical Ltd. https://ubuntu.com/server/docs

[13] Systemd Documentation. "systemd System and Service Manager." freedesktop.org. https://systemd.io/

[14] Gunicorn Documentation. "Python WSGI HTTP Server for UNIX." Gunicorn. https://gunicorn.org/

### 모니터링 및 로깅

[15] Prometheus Documentation. "Prometheus Monitoring System." Prometheus Authors. https://prometheus.io/docs/

[16] Grafana Documentation. "Grafana Analytics Platform." Grafana Labs. https://grafana.com/docs/

[17] ELK Stack Documentation. "Elasticsearch, Logstash, and Kibana." Elastic N.V. https://www.elastic.co/guide/

### AI 및 API 통합

[18] OpenAI API Documentation. "OpenAI API Reference." OpenAI. https://platform.openai.com/docs

[19] Manus AI Documentation. "Manus AI Platform Documentation." Manus Team. https://docs.manus.chat

### 클라우드 보안

[20] Google Cloud Security. "Google Cloud Security Best Practices." Google Cloud. https://cloud.google.com/security/best-practices

[21] Cloud Security Alliance. "Cloud Security Guidance." Cloud Security Alliance. https://cloudsecurityalliance.org/

### 성능 최적화

[22] Web.dev. "Web Performance Optimization." Google Developers. https://web.dev/performance/

[23] High Performance Browser Networking. "Network Performance Guide." O'Reilly Media. https://hpbn.co/

이러한 참고 자료들은 Interactive Terminal Web 플랫폼의 지속적인 개선과 운영에 필요한 심화 지식을 제공합니다. 각 자료는 특정 영역의 전문 지식을 담고 있으므로, 필요에 따라 해당 분야의 자료를 참조하여 더 깊이 있는 이해와 구현을 진행할 수 있습니다.

---

**문서 정보**
- 작성자: Manus AI
- 최종 수정일: 2025년 7월 16일
- 문서 버전: 1.0
- 라이선스: MIT License

본 문서는 Interactive Terminal Web 애플리케이션의 GCP 배포를 위한 포괄적인 가이드로, 실제 프로덕션 환경에서의 배포와 운영에 필요한 모든 정보를 담고 있습니다. 문서의 내용은 지속적으로 업데이트되며, 최신 버전은 프로젝트 저장소에서 확인할 수 있습니다.

