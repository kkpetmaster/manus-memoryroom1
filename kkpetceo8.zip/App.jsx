import { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Terminal, Bot, Server, Activity, Settings, FileText } from 'lucide-react'
import ManusChat from './components/ManusChat.jsx'
import TerminalInterface from './components/TerminalInterface.jsx'
import SystemMonitor from './components/SystemMonitor.jsx'
import './App.css'

const API_BASE_URL = 'https://5000-i8lhp9csz2zxj2rbx8xlc-030bfc10.manusvm.computer/api'

function App() {
  const [sessionId] = useState(() => `session_${Date.now()}`)
  const [manusStatus, setManusStatus] = useState('unknown')
  const [currentDirectory, setCurrentDirectory] = useState('~')

  useEffect(() => {
    checkManusStatus()
  }, [])

  const checkManusStatus = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/manus/status`)
      const data = await response.json()
      setManusStatus(data.manus_available ? 'connected' : 'disconnected')
    } catch (error) {
      setManusStatus('error')
    }
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto p-4 max-w-7xl">
        {/* 헤더 */}
        <header className="mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Terminal className="h-10 w-10 text-blue-400" />
                  <div className="absolute -top-1 -right-1 h-4 w-4 bg-green-500 rounded-full flex items-center justify-center">
                    <Bot className="h-2 w-2 text-white" />
                  </div>
                </div>
                <div>
                  <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                    Interactive Terminal Web
                  </h1>
                  <p className="text-gray-400 text-sm">Powered by Manus AI</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge 
                variant={manusStatus === 'connected' ? 'default' : 'destructive'}
                className="flex items-center space-x-1"
              >
                <Bot className="h-3 w-3" />
                <span>Manus AI: {manusStatus === 'connected' ? '연결됨' : '연결 안됨'}</span>
              </Badge>
              
              <Badge variant="outline" className="flex items-center space-x-1">
                <Server className="h-3 w-3" />
                <span>{currentDirectory}</span>
              </Badge>
              
              <Badge variant="secondary" className="flex items-center space-x-1">
                <Activity className="h-3 w-3" />
                <span>세션: {sessionId.slice(-8)}</span>
              </Badge>
            </div>
          </div>
        </header>

        {/* 메인 콘텐츠 */}
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 h-[calc(100vh-200px)]">
          {/* 메인 작업 영역 */}
          <div className="xl:col-span-3">
            <Tabs defaultValue="chat" className="h-full flex flex-col">
              <TabsList className="grid w-full grid-cols-3 mb-4">
                <TabsTrigger value="chat" className="flex items-center space-x-2">
                  <Bot className="h-4 w-4" />
                  <span>Manus AI</span>
                </TabsTrigger>
                <TabsTrigger value="terminal" className="flex items-center space-x-2">
                  <Terminal className="h-4 w-4" />
                  <span>Terminal</span>
                </TabsTrigger>
                <TabsTrigger value="files" className="flex items-center space-x-2">
                  <FileText className="h-4 w-4" />
                  <span>Files</span>
                </TabsTrigger>
              </TabsList>

              <div className="flex-1 bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
                <TabsContent value="chat" className="h-full m-0">
                  <ManusChat 
                    apiBaseUrl={API_BASE_URL} 
                    sessionId={sessionId}
                  />
                </TabsContent>

                <TabsContent value="terminal" className="h-full m-0">
                  <TerminalInterface 
                    apiBaseUrl={API_BASE_URL} 
                    sessionId={sessionId}
                    onDirectoryChange={setCurrentDirectory}
                  />
                </TabsContent>

                <TabsContent value="files" className="h-full m-0 p-6">
                  <div className="flex items-center justify-center h-full text-gray-400">
                    <div className="text-center">
                      <FileText className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <h3 className="text-lg font-semibold mb-2">파일 관리자</h3>
                      <p className="text-sm">파일 브라우저 기능이 곧 추가될 예정입니다.</p>
                    </div>
                  </div>
                </TabsContent>
              </div>
            </Tabs>
          </div>

          {/* 사이드바 - 시스템 모니터 */}
          <div className="xl:col-span-1">
            <div className="bg-gray-800 rounded-lg border border-gray-700 h-full overflow-y-auto">
              <div className="p-4 border-b border-gray-700">
                <h2 className="font-semibold flex items-center">
                  <Activity className="h-4 w-4 mr-2 text-blue-400" />
                  시스템 모니터
                </h2>
              </div>
              <div className="p-4">
                <SystemMonitor apiBaseUrl={API_BASE_URL} />
              </div>
            </div>
          </div>
        </div>

        {/* 푸터 */}
        <footer className="mt-6 text-center text-xs text-gray-500">
          <p>Interactive Terminal Web v1.0 - 실제 서버 환경에서 작동하는 AI 어시스턴트</p>
        </footer>
      </div>
    </div>
  )
}

export default App

