import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Avatar, AvatarFallback } from '@/components/ui/avatar.jsx'
import { Send, Bot, User, Loader2, Copy, ThumbsUp, ThumbsDown } from 'lucide-react'

const ManusChat = ({ apiBaseUrl, sessionId }) => {
  const [messages, setMessages] = useState([])
  const [inputMessage, setInputMessage] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [manusStatus, setManusStatus] = useState('unknown')
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    checkManusStatus()
    // 환영 메시지 추가
    setMessages([{
      id: 'welcome',
      type: 'ai',
      content: `안녕하세요! 저는 Manus AI입니다. 🤖

실제 서버 환경에서 작동하는 AI 어시스턴트로, 다음과 같은 작업을 도와드릴 수 있습니다:

• **터미널 명령어 실행 및 설명**
• **서버 설정 및 관리 지원**
• **코드 작성 및 디버깅**
• **시스템 모니터링 및 최적화**
• **보안 관련 가이드라인 제공**

무엇을 도와드릴까요?`,
      timestamp: new Date().toLocaleTimeString()
    }])
  }, [])

  const checkManusStatus = async () => {
    try {
      const response = await fetch(`${apiBaseUrl}/manus/status`)
      const data = await response.json()
      setManusStatus(data.manus_available ? 'connected' : 'disconnected')
    } catch (error) {
      setManusStatus('error')
    }
  }

  const sendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date().toLocaleTimeString()
    }

    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setIsLoading(true)

    try {
      const response = await fetch(`${apiBaseUrl}/manus/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: inputMessage,
          session_id: sessionId,
          include_system_info: true
        })
      })

      const data = await response.json()

      if (data.success) {
        const aiMessage = {
          id: Date.now() + 1,
          type: 'ai',
          content: data.response,
          timestamp: new Date().toLocaleTimeString()
        }
        setMessages(prev => [...prev, aiMessage])
      } else {
        const errorMessage = {
          id: Date.now() + 1,
          type: 'error',
          content: `오류: ${data.error}`,
          timestamp: new Date().toLocaleTimeString()
        }
        setMessages(prev => [...prev, errorMessage])
      }
    } catch (error) {
      const errorMessage = {
        id: Date.now() + 1,
        type: 'error',
        content: `네트워크 오류: ${error.message}`,
        timestamp: new Date().toLocaleTimeString()
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
  }

  const formatMessage = (content) => {
    // 코드 블록 처리
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g
    const inlineCodeRegex = /`([^`]+)`/g
    
    let formattedContent = content
      .replace(codeBlockRegex, (match, language, code) => {
        return `<div class="code-block bg-gray-800 rounded-lg p-4 my-2 overflow-x-auto">
          <div class="flex justify-between items-center mb-2">
            <span class="text-xs text-gray-400">${language || 'code'}</span>
            <button onclick="navigator.clipboard.writeText('${code.trim()}')" class="text-xs text-blue-400 hover:text-blue-300">Copy</button>
          </div>
          <pre class="text-sm"><code>${code.trim()}</code></pre>
        </div>`
      })
      .replace(inlineCodeRegex, '<code class="bg-gray-700 px-1 py-0.5 rounded text-sm">$1</code>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n/g, '<br>')

    return formattedContent
  }

  return (
    <div className="flex flex-col h-full">
      {/* 헤더 */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-blue-600">
              <Bot className="h-4 w-4" />
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-semibold">Manus AI</h3>
            <p className="text-xs text-gray-400">AI Assistant</p>
          </div>
        </div>
        <Badge variant={manusStatus === 'connected' ? 'default' : 'destructive'}>
          {manusStatus === 'connected' ? '연결됨' : '연결 안됨'}
        </Badge>
      </div>

      {/* 메시지 영역 */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`flex max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'} items-start space-x-2`}>
                <Avatar className="h-8 w-8 flex-shrink-0">
                  <AvatarFallback className={message.type === 'user' ? 'bg-green-600' : 'bg-blue-600'}>
                    {message.type === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                  </AvatarFallback>
                </Avatar>
                
                <div className={`rounded-lg p-3 ${
                  message.type === 'user' 
                    ? 'bg-green-600 text-white' 
                    : message.type === 'error'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-700 text-gray-100'
                }`}>
                  {message.type === 'ai' ? (
                    <div 
                      className="prose prose-invert max-w-none text-sm"
                      dangerouslySetInnerHTML={{ __html: formatMessage(message.content) }}
                    />
                  ) : (
                    <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                  )}
                  
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs opacity-70">{message.timestamp}</span>
                    {message.type === 'ai' && (
                      <div className="flex items-center space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 opacity-70 hover:opacity-100"
                          onClick={() => copyToClipboard(message.content)}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 opacity-70 hover:opacity-100"
                        >
                          <ThumbsUp className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 opacity-70 hover:opacity-100"
                        >
                          <ThumbsDown className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-blue-600">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-gray-700 rounded-lg p-3">
                  <div className="flex items-center space-x-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm">Manus AI가 응답 중...</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        <div ref={messagesEndRef} />
      </ScrollArea>

      {/* 입력 영역 */}
      <div className="p-4 border-t border-gray-700">
        <div className="flex space-x-2">
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Manus AI에게 질문하거나 명령을 요청하세요..."
            onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
            className="bg-gray-700 border-gray-600 text-white flex-1"
            disabled={isLoading}
          />
          <Button 
            onClick={sendMessage} 
            disabled={isLoading || !inputMessage.trim()}
            className="px-3"
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </div>
        
        <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
          <span>Shift + Enter로 줄바꿈</span>
          <span>{messages.length} 메시지</span>
        </div>
      </div>
    </div>
  )
}

export default ManusChat

