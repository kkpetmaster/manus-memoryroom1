from flask import Blueprint, request, jsonify, Response
from flask_cors import cross_origin
import subprocess
import os
import json
import time
import threading
import queue
import signal
import psutil
from datetime import datetime

terminal_bp = Blueprint('terminal', __name__)

# 활성 프로세스를 추적하기 위한 딕셔너리
active_processes = {}
session_histories = {}

class TerminalSession:
    def __init__(self, session_id):
        self.session_id = session_id
        self.current_directory = os.path.expanduser("~")
        self.environment = os.environ.copy()
        self.history = []
        
    def execute_command(self, command):
        """명령어를 실행하고 결과를 반환"""
        try:
            # cd 명령어 특별 처리
            if command.strip().startswith('cd '):
                path = command.strip()[3:].strip()
                if not path:
                    path = os.path.expanduser("~")
                elif path.startswith('~'):
                    path = os.path.expanduser(path)
                elif not os.path.isabs(path):
                    path = os.path.join(self.current_directory, path)
                
                if os.path.exists(path) and os.path.isdir(path):
                    self.current_directory = os.path.abspath(path)
                    result = {
                        'success': True,
                        'output': f"Changed directory to {self.current_directory}",
                        'error': '',
                        'directory': self.current_directory
                    }
                else:
                    result = {
                        'success': False,
                        'output': '',
                        'error': f"Directory not found: {path}",
                        'directory': self.current_directory
                    }
            else:
                # 일반 명령어 실행
                process = subprocess.Popen(
                    command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    cwd=self.current_directory,
                    env=self.environment
                )
                
                stdout, stderr = process.communicate(timeout=30)
                
                result = {
                    'success': process.returncode == 0,
                    'output': stdout,
                    'error': stderr,
                    'directory': self.current_directory,
                    'return_code': process.returncode
                }
            
            # 히스토리에 추가
            self.history.append({
                'timestamp': datetime.now().isoformat(),
                'command': command,
                'result': result
            })
            
            return result
            
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'output': '',
                'error': 'Command timed out after 30 seconds',
                'directory': self.current_directory
            }
        except Exception as e:
            return {
                'success': False,
                'output': '',
                'error': str(e),
                'directory': self.current_directory
            }

@terminal_bp.route('/execute', methods=['POST'])
@cross_origin()
def execute_command():
    """명령어 실행 API"""
    try:
        data = request.get_json()
        command = data.get('command', '').strip()
        session_id = data.get('session_id', 'default')
        
        if not command:
            return jsonify({
                'success': False,
                'error': 'No command provided'
            }), 400
        
        # 세션 가져오기 또는 생성
        if session_id not in session_histories:
            session_histories[session_id] = TerminalSession(session_id)
        
        session = session_histories[session_id]
        
        # 위험한 명령어 차단
        dangerous_commands = [
            'rm -rf /', 'rm -rf *', 'mkfs', 'dd if=', 'format',
            'shutdown', 'reboot', 'halt', 'poweroff',
            'passwd', 'su -', 'sudo su', 'userdel', 'useradd'
        ]
        
        for dangerous in dangerous_commands:
            if dangerous in command.lower():
                return jsonify({
                    'success': False,
                    'error': f'Dangerous command blocked: {dangerous}',
                    'directory': session.current_directory
                }), 403
        
        # 명령어 실행
        result = session.execute_command(command)
        
        return jsonify({
            'success': result['success'],
            'output': result['output'],
            'error': result['error'],
            'directory': result['directory'],
            'session_id': session_id,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@terminal_bp.route('/sessions/<session_id>/history', methods=['GET'])
@cross_origin()
def get_session_history(session_id):
    """세션 히스토리 조회"""
    if session_id not in session_histories:
        return jsonify({
            'success': False,
            'error': 'Session not found'
        }), 404
    
    session = session_histories[session_id]
    return jsonify({
        'success': True,
        'history': session.history,
        'current_directory': session.current_directory
    })

@terminal_bp.route('/sessions', methods=['GET'])
@cross_origin()
def list_sessions():
    """활성 세션 목록 조회"""
    sessions = []
    for session_id, session in session_histories.items():
        sessions.append({
            'session_id': session_id,
            'current_directory': session.current_directory,
            'command_count': len(session.history)
        })
    
    return jsonify({
        'success': True,
        'sessions': sessions
    })

@terminal_bp.route('/system/info', methods=['GET'])
@cross_origin()
def get_system_info():
    """시스템 정보 조회"""
    try:
        # CPU 정보
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        
        # 메모리 정보
        memory = psutil.virtual_memory()
        
        # 디스크 정보
        disk = psutil.disk_usage('/')
        
        # 네트워크 정보
        network = psutil.net_io_counters()
        
        return jsonify({
            'success': True,
            'system_info': {
                'cpu': {
                    'percent': cpu_percent,
                    'count': cpu_count
                },
                'memory': {
                    'total': memory.total,
                    'available': memory.available,
                    'percent': memory.percent,
                    'used': memory.used
                },
                'disk': {
                    'total': disk.total,
                    'used': disk.used,
                    'free': disk.free,
                    'percent': (disk.used / disk.total) * 100
                },
                'network': {
                    'bytes_sent': network.bytes_sent,
                    'bytes_recv': network.bytes_recv
                }
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

