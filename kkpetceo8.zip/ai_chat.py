from flask import Blueprint, request, jsonify, Response
from flask_cors import cross_origin
import requests
import os
import json
from datetime import datetime

ai_chat_bp = Blueprint('ai_chat', __name__)

# Manus API 설정
MANUS_API_URL = "https://api.manus.chat/v1/chat/completions"
MANUS_API_KEY = os.getenv('MANUS_API_KEY', 'your-manus-api-key-here')

# 대화 히스토리 저장
conversation_histories = {}

def get_system_prompt():
    """시스템 프롬프트 정의"""
    return """당신은 실제 서버 환경에서 작동하는 AI 어시스턴트입니다. 사용자가 서버 관리, 개발, 시스템 운영 등의 작업을 수행할 수 있도록 도와주는 역할을 합니다.

주요 역할:
1. 터미널 명령어 제안 및 설명
2. 서버 설정 및 관리 지원  
3. 코드 작성 및 디버깅 도움
4. 시스템 모니터링 및 최적화 조언
5. 보안 관련 가이드라인 제공
6. 실제 명령어 실행 및 결과 분석

특징:
- 실용적이고 구체적인 해결책 제시
- 위험한 명령어에 대한 경고
- 단계별 가이드 제공
- 한국어로 친근하게 대화
- 실제 서버 환경에서의 작업 수행

사용자의 질문에 대해 정확하고 도움이 되는 답변을 제공하고, 필요시 직접 명령어를 실행할 수 있습니다."""

@ai_chat_bp.route('/chat', methods=['POST'])
@cross_origin()
def chat_with_manus():
    """Manus AI와 채팅하는 API"""
    try:
        data = request.get_json()
        message = data.get('message', '').strip()
        session_id = data.get('session_id', 'default')
        
        if not message:
            return jsonify({
                'success': False,
                'error': 'No message provided'
            }), 400
        
        # 세션 히스토리 가져오기 또는 생성
        if session_id not in conversation_histories:
            conversation_histories[session_id] = [
                {"role": "system", "content": get_system_prompt()}
            ]
        
        # 사용자 메시지 추가
        conversation_histories[session_id].append({
            "role": "user", 
            "content": message
        })
        
        # Manus API 호출
        headers = {
            'Authorization': f'Bearer {MANUS_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            "model": "manus-1",
            "messages": conversation_histories[session_id],
            "max_tokens": 2000,
            "temperature": 0.7,
            "stream": False
        }
        
        response = requests.post(
            MANUS_API_URL,
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code == 200:
            response_data = response.json()
            ai_response = response_data['choices'][0]['message']['content']
            
            # AI 응답을 히스토리에 추가
            conversation_histories[session_id].append({
                "role": "assistant",
                "content": ai_response
            })
            
            # 히스토리가 너무 길어지면 시스템 메시지와 최근 10개만 유지
            if len(conversation_histories[session_id]) > 21:  # 시스템 + 10쌍의 대화
                system_msg = conversation_histories[session_id][0]
                recent_msgs = conversation_histories[session_id][-20:]
                conversation_histories[session_id] = [system_msg] + recent_msgs
            
            return jsonify({
                'success': True,
                'response': ai_response,
                'session_id': session_id,
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Manus API error: {response.status_code} - {response.text}'
            }), 500
        
    except requests.exceptions.RequestException as e:
        return jsonify({
            'success': False,
            'error': f'Network error: {str(e)}'
        }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ai_chat_bp.route('/analyze-command', methods=['POST'])
@cross_origin()
def analyze_command():
    """명령어 분석 및 제안 API (Manus 사용)"""
    try:
        data = request.get_json()
        command = data.get('command', '').strip()
        context = data.get('context', '')
        
        if not command:
            return jsonify({
                'success': False,
                'error': 'No command provided'
            }), 400
        
        analysis_prompt = f"""다음 명령어를 분석해주세요:

명령어: {command}
컨텍스트: {context}

다음 정보를 JSON 형태로 제공해주세요:
1. safety_level: "safe", "caution", "dangerous" 중 하나
2. description: 명령어가 하는 일에 대한 설명
3. potential_risks: 잠재적 위험 요소들
4. suggestions: 더 안전하거나 효율적인 대안 명령어
5. explanation: 상세한 설명

응답은 반드시 JSON 형태로만 해주세요."""
        
        headers = {
            'Authorization': f'Bearer {MANUS_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            "model": "manus-1",
            "messages": [
                {"role": "system", "content": "당신은 리눅스 시스템 관리 전문가입니다. 명령어를 분석하고 안전성을 평가해주세요."},
                {"role": "user", "content": analysis_prompt}
            ],
            "max_tokens": 1000,
            "temperature": 0.3
        }
        
        response = requests.post(
            MANUS_API_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            response_data = response.json()
            ai_response = response_data['choices'][0]['message']['content']
            
            try:
                analysis = json.loads(ai_response)
            except json.JSONDecodeError:
                # JSON 파싱 실패 시 기본 응답
                analysis = {
                    "safety_level": "caution",
                    "description": "명령어 분석 중 오류가 발생했습니다.",
                    "potential_risks": ["분석 불가"],
                    "suggestions": ["명령어를 다시 확인해주세요."],
                    "explanation": ai_response
                }
            
            return jsonify({
                'success': True,
                'analysis': analysis,
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Manus API error: {response.status_code}'
            }), 500
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ai_chat_bp.route('/generate-command', methods=['POST'])
@cross_origin()
def generate_command():
    """자연어 요청을 명령어로 변환하는 API (Manus 사용)"""
    try:
        data = request.get_json()
        request_text = data.get('request', '').strip()
        current_directory = data.get('current_directory', '~')
        
        if not request_text:
            return jsonify({
                'success': False,
                'error': 'No request provided'
            }), 400
        
        generation_prompt = f"""사용자의 자연어 요청을 적절한 리눅스 명령어로 변환해주세요.

사용자 요청: {request_text}
현재 디렉토리: {current_directory}

다음 정보를 JSON 형태로 제공해주세요:
1. commands: 실행할 명령어들의 배열
2. explanation: 각 명령어에 대한 설명
3. safety_warning: 주의사항이 있다면 포함
4. alternative_options: 다른 방법이 있다면 제안

응답은 반드시 JSON 형태로만 해주세요."""
        
        headers = {
            'Authorization': f'Bearer {MANUS_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            "model": "manus-1",
            "messages": [
                {"role": "system", "content": "당신은 리눅스 시스템 관리 전문가입니다. 사용자의 자연어 요청을 안전하고 효율적인 명령어로 변환해주세요."},
                {"role": "user", "content": generation_prompt}
            ],
            "max_tokens": 1000,
            "temperature": 0.3
        }
        
        response = requests.post(
            MANUS_API_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            response_data = response.json()
            ai_response = response_data['choices'][0]['message']['content']
            
            try:
                command_info = json.loads(ai_response)
            except json.JSONDecodeError:
                # JSON 파싱 실패 시 기본 응답
                command_info = {
                    "commands": [],
                    "explanation": "명령어 생성 중 오류가 발생했습니다.",
                    "safety_warning": "명령어를 직접 확인해주세요.",
                    "alternative_options": []
                }
            
            return jsonify({
                'success': True,
                'command_info': command_info,
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Manus API error: {response.status_code}'
            }), 500
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@ai_chat_bp.route('/sessions/<session_id>/history', methods=['GET'])
@cross_origin()
def get_chat_history(session_id):
    """채팅 히스토리 조회"""
    if session_id not in conversation_histories:
        return jsonify({
            'success': False,
            'error': 'Session not found'
        }), 404
    
    # 시스템 메시지 제외하고 반환
    history = conversation_histories[session_id][1:]  # 첫 번째는 시스템 메시지
    
    return jsonify({
        'success': True,
        'history': history
    })

@ai_chat_bp.route('/sessions/<session_id>/clear', methods=['POST'])
@cross_origin()
def clear_chat_history(session_id):
    """채팅 히스토리 초기화"""
    conversation_histories[session_id] = [
        {"role": "system", "content": get_system_prompt()}
    ]
    
    return jsonify({
        'success': True,
        'message': 'Chat history cleared'
    })

