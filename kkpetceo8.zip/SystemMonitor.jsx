import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  Activity, 
  Cpu, 
  HardDrive, 
  MemoryStick, 
  Network, 
  RefreshCw, 
  Server,
  Zap,
  Clock,
  Database
} from 'lucide-react'

const SystemMonitor = ({ apiBaseUrl }) => {
  const [systemInfo, setSystemInfo] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [lastUpdate, setLastUpdate] = useState(null)
  const [autoRefresh, setAutoRefresh] = useState(false)

  const fetchSystemInfo = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`${apiBaseUrl}/terminal/system/info`)
      const data = await response.json()
      if (data.success) {
        setSystemInfo(data.system_info)
        setLastUpdate(new Date())
      }
    } catch (error) {
      console.error('Failed to fetch system info:', error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchSystemInfo()
  }, [])

  useEffect(() => {
    let interval
    if (autoRefresh) {
      interval = setInterval(fetchSystemInfo, 5000) // 5초마다 업데이트
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [autoRefresh])

  const formatBytes = (bytes) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const getStatusColor = (percentage) => {
    if (percentage < 50) return 'text-green-400'
    if (percentage < 80) return 'text-yellow-400'
    return 'text-red-400'
  }

  const getProgressColor = (percentage) => {
    if (percentage < 50) return 'bg-green-500'
    if (percentage < 80) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  if (!systemInfo) {
    return (
      <div className="space-y-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
              <span className="ml-2">시스템 정보 로딩 중...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* 헤더 */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center text-lg">
              <Activity className="h-5 w-5 mr-2 text-blue-400" />
              System Monitor
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Badge 
                variant={autoRefresh ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setAutoRefresh(!autoRefresh)}
              >
                {autoRefresh ? 'Auto' : 'Manual'}
              </Badge>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={fetchSystemInfo}
                disabled={isLoading}
              >
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>
          {lastUpdate && (
            <p className="text-xs text-gray-400">
              마지막 업데이트: {lastUpdate.toLocaleTimeString()}
            </p>
          )}
        </CardHeader>
      </Card>

      {/* CPU 정보 */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-sm">
            <Cpu className="h-4 w-4 mr-2 text-blue-400" />
            CPU Usage
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Usage</span>
              <span className={`text-lg font-semibold ${getStatusColor(systemInfo.cpu.percent)}`}>
                {systemInfo.cpu.percent.toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={systemInfo.cpu.percent} 
              className="h-2"
            />
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>{systemInfo.cpu.count} cores</span>
              <span>Load Average</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 메모리 정보 */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-sm">
            <MemoryStick className="h-4 w-4 mr-2 text-green-400" />
            Memory Usage
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">RAM</span>
              <span className={`text-lg font-semibold ${getStatusColor(systemInfo.memory.percent)}`}>
                {systemInfo.memory.percent.toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={systemInfo.memory.percent} 
              className="h-2"
            />
            <div className="grid grid-cols-2 gap-2 text-xs text-gray-500">
              <div>Used: {formatBytes(systemInfo.memory.used)}</div>
              <div>Total: {formatBytes(systemInfo.memory.total)}</div>
              <div>Available: {formatBytes(systemInfo.memory.available)}</div>
              <div>Free: {formatBytes(systemInfo.memory.total - systemInfo.memory.used)}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 디스크 정보 */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-sm">
            <HardDrive className="h-4 w-4 mr-2 text-yellow-400" />
            Disk Usage
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Root (/)</span>
              <span className={`text-lg font-semibold ${getStatusColor(systemInfo.disk.percent)}`}>
                {systemInfo.disk.percent.toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={systemInfo.disk.percent} 
              className="h-2"
            />
            <div className="grid grid-cols-2 gap-2 text-xs text-gray-500">
              <div>Used: {formatBytes(systemInfo.disk.used)}</div>
              <div>Total: {formatBytes(systemInfo.disk.total)}</div>
              <div>Free: {formatBytes(systemInfo.disk.free)}</div>
              <div>Available: {formatBytes(systemInfo.disk.free)}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 네트워크 정보 */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-sm">
            <Network className="h-4 w-4 mr-2 text-purple-400" />
            Network I/O
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-xs text-gray-400 mb-1">Sent</div>
                <div className="text-sm font-semibold text-blue-400">
                  ↑ {formatBytes(systemInfo.network.bytes_sent)}
                </div>
              </div>
              <div className="text-center">
                <div className="text-xs text-gray-400 mb-1">Received</div>
                <div className="text-sm font-semibold text-green-400">
                  ↓ {formatBytes(systemInfo.network.bytes_recv)}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 시스템 상태 요약 */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-sm">
            <Server className="h-4 w-4 mr-2 text-gray-400" />
            System Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="flex items-center space-x-2">
              <Zap className="h-3 w-3 text-green-400" />
              <span className="text-gray-400">Status:</span>
              <Badge variant="default" className="text-xs">Online</Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-3 w-3 text-blue-400" />
              <span className="text-gray-400">Uptime:</span>
              <span className="text-white">Active</span>
            </div>
            <div className="flex items-center space-x-2">
              <Database className="h-3 w-3 text-yellow-400" />
              <span className="text-gray-400">Load:</span>
              <span className={getStatusColor((systemInfo.cpu.percent + systemInfo.memory.percent) / 2)}>
                {((systemInfo.cpu.percent + systemInfo.memory.percent) / 2).toFixed(1)}%
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Activity className="h-3 w-3 text-purple-400" />
              <span className="text-gray-400">Health:</span>
              <Badge 
                variant={systemInfo.cpu.percent < 80 && systemInfo.memory.percent < 80 ? "default" : "destructive"}
                className="text-xs"
              >
                {systemInfo.cpu.percent < 80 && systemInfo.memory.percent < 80 ? "Good" : "Warning"}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 빠른 액션 */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm" className="text-xs">
              <Activity className="h-3 w-3 mr-1" />
              Top Processes
            </Button>
            <Button variant="outline" size="sm" className="text-xs">
              <HardDrive className="h-3 w-3 mr-1" />
              Disk Usage
            </Button>
            <Button variant="outline" size="sm" className="text-xs">
              <Network className="h-3 w-3 mr-1" />
              Network Stats
            </Button>
            <Button variant="outline" size="sm" className="text-xs">
              <Cpu className="h-3 w-3 mr-1" />
              System Info
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default SystemMonitor

