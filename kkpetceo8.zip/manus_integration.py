from flask import Blueprint, request, jsonify, Response
from flask_cors import cross_origin
import requests
import os
import json
from datetime import datetime
import subprocess

manus_bp = Blueprint('manus', __name__)

# Manus API 설정 - 실제 Manus API 엔드포인트
MANUS_API_URL = "https://api.manus.chat/v1/chat/completions"
MANUS_API_KEY = os.getenv('MANUS_API_KEY', 'your-manus-api-key-here')

# 대화 히스토리 저장
conversation_histories = {}

def get_manus_system_prompt():
    """Manus AI를 위한 시스템 프롬프트"""
    return """당신은 실제 서버 환경에서 작동하는 Manus AI입니다. 사용자의 웹 인터페이스를 통해 실제 서버에서 명령을 실행하고 관리할 수 있습니다.

주요 기능:
1. 실제 터미널 명령어 실행 및 결과 분석
2. 서버 설정 및 관리 지원
3. 코드 작성, 편집, 실행
4. 시스템 모니터링 및 최적화
5. 보안 관련 가이드라인 제공
6. 파일 관리 및 편집
7. 네트워크 설정 및 진단

특징:
- 실제 서버 환경에서 직접 작업 수행
- 안전한 명령어 실행을 위한 검증
- 단계별 가이드 및 설명 제공
- 한국어로 친근하고 전문적인 대화
- 실시간 시스템 상태 모니터링

사용자와 대화하며 필요한 작업을 안전하고 효율적으로 수행해주세요."""

@manus_bp.route('/chat', methods=['POST'])
@cross_origin()
def chat_with_manus():
    """Manus AI와 직접 채팅"""
    try:
        data = request.get_json()
        message = data.get('message', '').strip()
        session_id = data.get('session_id', 'default')
        include_system_info = data.get('include_system_info', False)
        
        if not message:
            return jsonify({
                'success': False,
                'error': 'No message provided'
            }), 400
        
        # 세션 히스토리 가져오기 또는 생성
        if session_id not in conversation_histories:
            conversation_histories[session_id] = [
                {"role": "system", "content": get_manus_system_prompt()}
            ]
        
        # 시스템 정보 포함 요청 시
        system_context = ""
        if include_system_info:
            try:
                # 현재 디렉토리 정보
                current_dir = subprocess.check_output(['pwd'], text=True).strip()
                
                # 시스템 정보
                uptime = subprocess.check_output(['uptime'], text=True).strip()
                disk_usage = subprocess.check_output(['df', '-h', '/'], text=True).strip()
                
                system_context = f"""
현재 시스템 상태:
- 현재 디렉토리: {current_dir}
- 시스템 가동시간: {uptime}
- 디스크 사용량: {disk_usage}
"""
            except:
                system_context = "시스템 정보를 가져올 수 없습니다."
        
        # 사용자 메시지에 시스템 컨텍스트 추가
        full_message = message
        if system_context:
            full_message = f"{message}\n\n{system_context}"
        
        # 사용자 메시지 추가
        conversation_histories[session_id].append({
            "role": "user", 
            "content": full_message
        })
        
        # Manus API 호출
        headers = {
            'Authorization': f'Bearer {MANUS_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            "model": "manus-1",
            "messages": conversation_histories[session_id],
            "max_tokens": 3000,
            "temperature": 0.7,
            "stream": False
        }
        
        response = requests.post(
            MANUS_API_URL,
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code == 200:
            response_data = response.json()
            ai_response = response_data['choices'][0]['message']['content']
            
            # AI 응답을 히스토리에 추가
            conversation_histories[session_id].append({
                "role": "assistant",
                "content": ai_response
            })
            
            # 히스토리가 너무 길어지면 시스템 메시지와 최근 대화만 유지
            if len(conversation_histories[session_id]) > 25:
                system_msg = conversation_histories[session_id][0]
                recent_msgs = conversation_histories[session_id][-24:]
                conversation_histories[session_id] = [system_msg] + recent_msgs
            
            return jsonify({
                'success': True,
                'response': ai_response,
                'session_id': session_id,
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Manus API error: {response.status_code} - {response.text}'
            }), 500
        
    except requests.exceptions.RequestException as e:
        return jsonify({
            'success': False,
            'error': f'Network error: {str(e)}'
        }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@manus_bp.route('/execute-with-ai', methods=['POST'])
@cross_origin()
def execute_with_ai_guidance():
    """AI 가이드와 함께 명령어 실행"""
    try:
        data = request.get_json()
        user_request = data.get('request', '').strip()
        session_id = data.get('session_id', 'default')
        auto_execute = data.get('auto_execute', False)
        
        if not user_request:
            return jsonify({
                'success': False,
                'error': 'No request provided'
            }), 400
        
        # 1단계: AI에게 명령어 생성 요청
        command_generation_prompt = f"""사용자 요청: {user_request}

이 요청을 수행하기 위한 리눅스 명령어를 생성해주세요. 다음 형식으로 응답해주세요:

COMMANDS:
[실행할 명령어들을 한 줄씩]

EXPLANATION:
[각 명령어에 대한 설명]

SAFETY_WARNING:
[주의사항이 있다면 포함]

EXPECTED_RESULT:
[예상되는 실행 결과]"""
        
        headers = {
            'Authorization': f'Bearer {MANUS_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            "model": "manus-1",
            "messages": [
                {"role": "system", "content": "당신은 리눅스 시스템 관리 전문가입니다. 사용자의 요청을 안전하고 효율적인 명령어로 변환해주세요."},
                {"role": "user", "content": command_generation_prompt}
            ],
            "max_tokens": 1500,
            "temperature": 0.3
        }
        
        response = requests.post(
            MANUS_API_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code != 200:
            return jsonify({
                'success': False,
                'error': f'Manus API error: {response.status_code}'
            }), 500
        
        ai_guidance = response.json()['choices'][0]['message']['content']
        
        # 명령어 추출
        commands = []
        if "COMMANDS:" in ai_guidance:
            commands_section = ai_guidance.split("COMMANDS:")[1].split("EXPLANATION:")[0].strip()
            commands = [cmd.strip() for cmd in commands_section.split('\n') if cmd.strip()]
        
        result = {
            'success': True,
            'ai_guidance': ai_guidance,
            'suggested_commands': commands,
            'session_id': session_id,
            'timestamp': datetime.now().isoformat()
        }
        
        # 자동 실행이 요청된 경우
        if auto_execute and commands:
            execution_results = []
            for command in commands:
                try:
                    # 위험한 명령어 체크
                    dangerous_patterns = ['rm -rf', 'mkfs', 'dd if=', 'format', 'shutdown', 'reboot']
                    if any(pattern in command.lower() for pattern in dangerous_patterns):
                        execution_results.append({
                            'command': command,
                            'success': False,
                            'error': 'Dangerous command blocked for safety'
                        })
                        continue
                    
                    # 명령어 실행
                    process = subprocess.run(
                        command,
                        shell=True,
                        capture_output=True,
                        text=True,
                        timeout=30
                    )
                    
                    execution_results.append({
                        'command': command,
                        'success': process.returncode == 0,
                        'output': process.stdout,
                        'error': process.stderr,
                        'return_code': process.returncode
                    })
                    
                except subprocess.TimeoutExpired:
                    execution_results.append({
                        'command': command,
                        'success': False,
                        'error': 'Command timed out'
                    })
                except Exception as e:
                    execution_results.append({
                        'command': command,
                        'success': False,
                        'error': str(e)
                    })
            
            result['execution_results'] = execution_results
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@manus_bp.route('/sessions/<session_id>/history', methods=['GET'])
@cross_origin()
def get_manus_history(session_id):
    """Manus 채팅 히스토리 조회"""
    if session_id not in conversation_histories:
        return jsonify({
            'success': False,
            'error': 'Session not found'
        }), 404
    
    # 시스템 메시지 제외하고 반환
    history = conversation_histories[session_id][1:]
    
    return jsonify({
        'success': True,
        'history': history,
        'session_id': session_id
    })

@manus_bp.route('/sessions/<session_id>/clear', methods=['POST'])
@cross_origin()
def clear_manus_history(session_id):
    """Manus 채팅 히스토리 초기화"""
    conversation_histories[session_id] = [
        {"role": "system", "content": get_manus_system_prompt()}
    ]
    
    return jsonify({
        'success': True,
        'message': 'Manus chat history cleared',
        'session_id': session_id
    })

@manus_bp.route('/status', methods=['GET'])
@cross_origin()
def manus_status():
    """Manus AI 상태 확인"""
    try:
        # Manus API 연결 테스트
        headers = {
            'Authorization': f'Bearer {MANUS_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        test_payload = {
            "model": "manus-1",
            "messages": [{"role": "user", "content": "Hello"}],
            "max_tokens": 10
        }
        
        response = requests.post(
            MANUS_API_URL,
            headers=headers,
            json=test_payload,
            timeout=10
        )
        
        manus_available = response.status_code == 200
        
        return jsonify({
            'success': True,
            'manus_available': manus_available,
            'api_url': MANUS_API_URL,
            'active_sessions': len(conversation_histories),
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': True,
            'manus_available': False,
            'error': str(e),
            'active_sessions': len(conversation_histories),
            'timestamp': datetime.now().isoformat()
        })

