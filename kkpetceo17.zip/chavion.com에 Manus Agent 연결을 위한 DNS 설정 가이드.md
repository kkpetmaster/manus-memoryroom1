# chavion.com에 Manus Agent 연결을 위한 DNS 설정 가이드

## 1. 현재 상태 분석

현재 `chavion.com` 도메인은 `34.64.219.224` IP 주소(Google LLC 소유)를 가리키는 A 레코드로 설정되어 있습니다. 이는 `chavion.com` 접속 시 AIIN 채팅 웹이 표시되는 이유입니다. Manus Agent 채팅 웹은 `https://y0h0i3cqg08k.manus.space`에 배포되어 있습니다.

## 2. 목표

`chavion.com`으로 접속 시 Manus Agent 채팅 웹(`https://y0h0i3cqg08k.manus.space`)이 표시되도록 DNS 설정을 변경하는 것입니다.

## 3. DNS 설정 변경 방법

DNS 설정 변경은 도메인 등록 기관(예: Gabia, Cafe24, GoDaddy 등) 또는 DNS 관리 서비스에서 직접 진행해야 합니다. Manus Agent는 사용자님의 DNS 설정에 직접 접근하여 변경할 수 없습니다. 다음 두 가지 방법 중 하나를 선택하여 진행할 수 있습니다.

### 방법 1: CNAME 레코드 사용 (권장)

이 방법은 `www.chavion.com`으로 접속 시 Manus Agent 채팅 웹으로 연결되도록 할 때 유용합니다. `chavion.com` 자체(`@` 호스트)에 CNAME 레코드를 설정하는 것은 일부 DNS 제공업체에서 허용하지 않을 수 있으므로, `www` 서브도메인에 CNAME을 설정하는 것이 일반적입니다.

**단계:**

1.  **도메인 등록 기관 또는 DNS 관리 서비스에 로그인합니다.**
2.  **DNS 관리 또는 도메인 설정 섹션으로 이동합니다.**
3.  **기존 `www` 호스트에 대한 A 레코드를 삭제합니다.** 현재 `www.chavion.com`에 설정된 A 레코드(값: `34.64.219.224`)가 있다면 이를 제거해야 합니다. A 레코드와 CNAME 레코드가 동일한 호스트에 함께 설정되면 충돌이 발생할 수 있습니다.
4.  **새로운 레코드를 추가합니다.**
    *   **유형 (Type):** `CNAME`
    *   **호스트 (Host) 또는 이름 (Name):** `www`
    *   **값 (Value) 또는 대상 (Target):** `y0h0i3cqg08k.manus.space`

**결과:** 이 설정이 적용되면 `www.chavion.com`으로 접속 시 Manus Agent 채팅 웹이 표시됩니다.

### 방법 2: A 레코드 변경 (루트 도메인 연결 시)

이 방법은 `chavion.com` 자체(`@` 호스트)로 접속 시 Manus Agent 채팅 웹으로 연결되도록 할 때 유용합니다. 루트 도메인에 CNAME 레코드 설정이 불가능한 경우에 사용합니다.

**단계:**

1.  **도메인 등록 기관 또는 DNS 관리 서비스에 로그인합니다.**
2.  **DNS 관리 또는 도메인 설정 섹션으로 이동합니다.**
3.  **`chavion.com` (`@` 호스트)에 대한 기존 A 레코드의 값을 변경합니다.** 현재 `34.64.219.224`로 설정된 값을 Manus Agent 채팅 웹의 IP 주소로 변경해야 합니다. Manus Agent 채팅 웹(`y0h0i3cqg08k.manus.space`)의 IP 주소는 `104.21.56.162`입니다.

    *   **유형 (Type):** `A`
    *   **호스트 (Host) 또는 이름 (Name):** `@` (또는 비워둠)
    *   **값 (Value) 또는 대상 (Target):** `104.21.56.162`

**결과:** 이 설정이 적용되면 `chavion.com`으로 접속 시 Manus Agent 채팅 웹이 표시됩니다.

## 4. 변경 사항 적용 및 확인

DNS 변경 사항이 전 세계적으로 적용되는 데는 몇 분에서 최대 48시간이 소요될 수 있습니다. 변경 후에는 다음 방법으로 적용 여부를 확인할 수 있습니다.

*   **웹 브라우저에서 `chavion.com` 또는 `www.chavion.com`에 접속하여 Manus Agent 채팅 웹이 표시되는지 확인합니다.**
*   **`nslookup` 또는 `dig` 명령어를 사용하여 DNS 레코드를 직접 조회합니다.**
    ```bash
    nslookup chavion.com
    nslookup www.chavion.com
    ```
    또는
    ```bash
    dig chavion.com
    dig www.chavion.com
    ```
    조회 결과에 Manus Agent의 IP 주소(`104.21.56.162`) 또는 CNAME(`y0h0i3cqg08k.manus.space`)이 올바르게 표시되는지 확인합니다.

## 5. 추가 고려 사항 (AIIN과의 동시 상주)

사용자님의 최종 목표가 `chavion.com`에 Manus Agent와 AIIN이 함께 상주하여 상호 협력하는 것이므로, 리버스 프록시 방식이 가장 적합하다고 판단됩니다. 이 경우, `chavion.com`의 웹 서버(예: Nginx)에서 리버스 프록시 설정을 통해 Manus Agent와 AIIN을 각각 다른 경로로 연결할 수 있습니다.

예를 들어:

*   `chavion.com/manus`로 접속 시 Manus Agent 채팅 웹으로 연결
*   `chavion.com/aiin`으로 접속 시 AIIN 웹 애플리케이션으로 연결

이러한 리버스 프록시 설정은 사용자님의 서버 환경에 직접 접근하여 Nginx 또는 Apache 설정 파일을 수정해야 하는 작업입니다. Manus Agent는 직접 이 작업을 수행할 수 없습니다. 필요하시면 Nginx 설정 예시를 다시 제공해 드릴 수 있습니다.

---

